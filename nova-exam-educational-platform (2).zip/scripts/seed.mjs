/**
 * Initialise NOVA EXAM dans la base de données.
 * Usage : node scripts/seed.mjs
 *
 * Crée : les paramètres par défaut, les niveaux, séries, matières,
 * le compte super administrateur (hachage bcrypt), une annonce,
 * et un exemple d'examen blanc interactif (entraînement).
 */
import bcrypt from "bcryptjs";
import pg from "pg";

const ADMIN_EMAIL = process.env.ADMIN_EMAIL ?? "jurgensbeneche1@gmail.com";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD ?? "Bendy509";
const url = process.env.DATABASE_URL ?? "postgresql://postgres:postgres@127.0.0.1:5432/app_db";

const { Client } = pg;
const client = new Client({ connectionString: url });

const uuid = () => crypto.randomUUID();

async function main() {
  await client.connect();
  await client.query("begin");

  const rows = await client.query("select * from settings where key = $1", ["site_name"]);
  if (rows.rowCount === 0) {
    const settings = {
      site_name: "NOVA EXAM",
      site_slogan: "Prépare ton examen, construis ton avenir.",
      site_description:
        "Plateforme éducative gratuite pour les élèves de 9ème année fondamentale et de NS4 en Haïti : examens précédents, exercices, corrigés et examens blancs.",
      whatsapp_number: "",
      contact_email: "jurgensbeneche1@gmail.com",
      founder_name: "Beneche Jurgens",
      founder_title: "Fondateur de NOVA EXAM",
      founder_bio:
        "NOVA EXAM est une plateforme éducative créée par Beneche Jurgens dans le but d'aider les élèves haïtiens à mieux préparer leurs examens officiels. Son objectif est de faciliter l'accès aux examens précédents, aux exercices, aux corrections et aux ressources pédagogiques dans un environnement simple, moderne et accessible gratuitement.",
      founder_mission:
        "Offrir à chaque élève haïtien un accès gratuit, simple et moderne aux ressources de préparation des examens officiels, afin qu'il puisse construire son avenir sur des bases solides.",
      address: "Haïti",
      facebook_url: "",
      instagram_url: "",
      twitter_url: "",
      youtube_url: "",
    };
    for (const [key, value] of Object.entries(settings)) {
      await client.query("insert into settings (key, value) values ($1, $2) on conflict (key) do nothing", [key, value]);
    }
    console.log("[seed] paramètres par défaut créés");
  }

  const adminExists = await client.query("select id from users where email = $1", [ADMIN_EMAIL]);
  if (adminExists.rowCount === 0) {
    const hash = await bcrypt.hash(ADMIN_PASSWORD, 10);
    await client.query(
      "insert into users (id, email, password_hash, role, nom, is_active, email_verified, created_at) values ($1,$2,$3,'super_administrateur','Beneche Jurgens',true,true,now())",
      [uuid(), ADMIN_EMAIL, hash],
    );
    await client.query(
      "insert into activity_logs (id, user_id, action, detail, created_at) select $1, null, 'administrateur_creé', $2, now()",
      [uuid(), ADMIN_EMAIL],
    );
    console.log(`[seed] compte super administrateur créé : ${ADMIN_EMAIL}`);
  } else {
    console.log(`[seed] compte administrateur déjà présent : ${ADMIN_EMAIL}`);
  }

  const levelQuery = await client.query("select id, code from levels order by position");
  const findLevel = (code) => levelQuery.rows.find((l) => l.code === code);

  const insertLevel = async (code, name, description, position) => {
    const existing = findLevel(code);
    if (existing) return existing.id;
    const result = await client.query(
      "insert into levels (id, code, name, description, position, is_active) values ($1,$2,$3,$4,$5,true) returning id",
      [uuid(), code, name, description, position],
    );
    return result.rows[0].id;
  };

  const nineId = await insertLevel("9em", "9ème année fondamentale", "Programme de base pour la préparation du CFPE-9.", 1);
  const ns4Id = await insertLevel("ns4", "NS4 (New Secondary)", "Première année du cycle secondaire supérieur en Haïti.", 2);

  const insertSeries = async (code, name, levelId, position) => {
    const exists = await client.query("select id from series where code = $1 and level_id = $2", [code, levelId]);
    if (exists.rowCount > 0) return;
    await client.query(
      "insert into series (id, code, name, level_id, position, is_active) values ($1,$2,$3,$4,$5,true)",
      [uuid(), code, name, levelId, position],
    );
  };

  await insertSeries("9em", "9ème année fondamentale", nineId, 1);
  await insertSeries("sciences", "Sciences", ns4Id, 1);
  await insertSeries("lettres", "Lettres et sciences humaines", ns4Id, 2);
  await insertSeries("affaire", "Affaires et informatique", ns4Id, 3);

  const subjectIds = {};
  const insertSubject = async (code, name, icon, color, levelId, position) => {
    const exists = await client.query("select id from subjects where code = $1", [code]);
    if (exists.rowCount > 0) return exists.rows[0].id;
    const result = await client.query(
      "insert into subjects (id, code, name, icon, color, level_id, position, is_active) values ($1,$2,$3,$4,$5,$6,$7,true) returning id",
      [uuid(), code, name, icon, color, levelId, position],
    );
    return result.rows[0].id;
  };

  const nineSubjects = [
    ["francais", "Français", "📚", "#1e3a8a"],
    ["creole", "Créole haïtien", "🗣️", "#b45309"],
    ["math", "Mathématiques", "🔢", "#0f766e"],
    ["sci-exp", "Sciences expérimentales", "🔬", "#7c3aed"],
    ["sci-soc", "Sciences sociales", "🌍", "#be123c"],
    ["anglais", "Anglais", "🇬🇧", "#1d4ed8"],
    ["espagnol", "Espagnol", "🇪🇸", "#c2410c"],
  ];
  let i = 1;
  for (const [code, name, icon, color] of nineSubjects) {
    subjectIds[code] = await insertSubject(code, name, icon, color, nineId, i++);
  }

  const ns4Subjects = [
    ["ns4-francais", "Français", "📚", "#1e3a8a"],
    ["ns4-anglais", "Anglais", "🇬🇧", "#1d4ed8"],
    ["ns4-creole", "Créole haïtien", "🗣️", "#b45309"],
    ["ns4-math", "Mathématiques", "🔢", "#0f766e"],
    ["ns4-physique", "Physique", "⚡", "#7c3aed"],
    ["ns4-chimie", "Chimie", "🧪", "#0891b2"],
    ["ns4-biologie", "Biologie", "🧬", "#16a34a"],
    ["ns4-histoire", "Histoire", "🏛️", "#a16207"],
    ["ns4-geographie", "Géographie", "🗺️", "#15803d"],
    ["ns4-economie", "Économie", "💰", "#b91c1c"],
    ["ns4-philo", "Philosophie", "🤔", "#6d28d9"],
    ["ns4-info", "Informatique", "💻", "#2563eb"],
  ];
  i = 1;
  for (const [code, name, icon, color] of ns4Subjects) {
    subjectIds[code] = await insertSubject(code, name, icon, color, ns4Id, i++);
  }

  const ann = await client.query("select id from announcements limit 1");
  if (ann.rowCount === 0) {
    await client.query(
      "insert into announcements (id, title, content, published, created_at) values ($1,$2,$3,true,now())",
      [uuid(), "Bienvenue sur NOVA EXAM", "Toutes les ressources de NOVA EXAM — examens précédents, exercices, corrigés et examens blancs — sont gratuites. Commencez par créer votre compte et choisir votre niveau."],
    );
    console.log("[seed] annonce de bienvenue créée");
  }

  const existingExam = await client.query("select id from interactive_exams limit 1");
  if (existingExam.rowCount === 0) {
    const examResult = await client.query(
      `insert into interactive_exams (id, title, description, subject_id, level_id, duration_minutes, max_score, passing_score, is_white_paper, published, created_at)
       values ($1,$2,$3,$4,$5,15,100,60,true,true,now()) returning id`,
      [
        uuid(),
        "Examen blanc de démonstration — Mathématiques (9ème)",
        "Exemple d'examen blanc interactif. Les réponses et explications apparaissent après la soumission. Il s'agit d'un entraînement, pas d'un résultat officiel.",
        subjectIds.math,
        nineId,
      ],
    );

    const sample = [
      { prompt: "Calculez 12 × 8.", type: "mcq", options: ["84", "96", "108", "120"], correct: 1, explanation: "12 × 8 = 96.", points: 20 },
      { prompt: "Un rectangle a une longueur de 6 cm et une largeur de 4 cm. Quel est son aire ?", type: "mcq", options: ["10 cm", "24 cm²", "24 cm", "12 cm²"], correct: 1, explanation: "L'aire d'un rectangle = longueur × largeur = 6 × 4 = 24 cm².", points: 20 },
      { prompt: "Simplifiez la fraction 8/12.", type: "short", options: [], correct: null, answer: "2/3", explanation: "On divise le numérateur et le dénominateur par 4 : 8 ÷ 4 = 2 et 12 ÷ 4 = 3.", points: 20 },
      { prompt: "Quelle est la valeur de 3² ?", type: "mcq", options: ["6", "9", "12", "81"], correct: 1, explanation: "3² = 3 × 3 = 9.", points: 20 },
      { prompt: "Le périmètre d'un carré mesure 20 cm. Quelle est la longueur d'un côté ?", type: "short", options: [], correct: null, answer: "5 cm", explanation: "Le périmètre d'un carré = 4 × côté, donc côté = 20 ÷ 4 = 5 cm.", points: 20 },
    ];

    let order = 1;
    for (const q of sample) {
      await client.query(
        `insert into questions (id, exam_id, subject_id, prompt, question_type, options_json, correct_index, correct_answer, explanation, points, order_no, created_at)
         values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,now())`,
        [
          uuid(),
          examResult.rows[0].id,
          subjectIds.math,
          q.prompt,
          q.type,
          JSON.stringify(q.options.map((text) => ({ text }))),
          q.correct,
          q.answer ?? null,
          q.explanation,
          q.points,
          order++,
        ],
      );
    }
    console.log("[seed] exemple d'examen blanc interactif créé");
  }

  await client.query("commit");
  await client.end();
  console.log("[seed] terminé avec succès.");
}

main().catch(async (error) => {
  console.error("[seed] erreur :", error);
  await client.end().catch(() => {});
  process.exit(1);
});
