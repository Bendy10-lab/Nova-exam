import Link from "next/link";
import { LogoMark } from "@/components/brand";
import { getRealStats, getSettings, publicSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

const VALUES = [
  { icon: "🆓", title: "100 % gratuit", text: "Inscription, exercices, corrigés, examens blancs et téléchargements : rien n'est payant." },
  { icon: "🇭🇹", title: "Adapté à Haïti", text: "Matières et niveaux organisés selon les programmes applicables dans le pays." },
  { icon: "📱", title: "Accessible partout", text: "Utilisation simple depuis un téléphone Android, une tablette ou un ordinateur." },
  { icon: "🔒", title: "Données protégées", text: "Chaque élève accède uniquement à ses propres résultats et à son propre profil." },
];

export default async function AProposPage() {
  const settings = publicSettings(await getSettings());
  const stats = await getRealStats();

  return (
    <div className="animate-fade-up">
      <section className="gradient-navy text-white">
        <div className="nav-container grid gap-10 py-14 lg:grid-cols-2">
          <div className="space-y-5">
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-nova-gold-light">À propos de NOVA EXAM</p>
            <h1 className="text-3xl font-extrabold sm:text-4xl">
              Un espace simple pour mieux préparer les <span className="gold-text">examens officiels</span>
            </h1>
            <p className="text-sm text-white/75 sm:text-base">{settings.description}</p>
          </div>
          <div className="flex justify-center lg:justify-end">
            <div className="flex h-52 w-52 items-center justify-center rounded-3xl bg-white/10 ring-2 ring-nova-gold/40 sm:h-60 sm:w-60">
              <LogoMark className="h-28 w-28" />
            </div>
          </div>
        </div>
      </section>

      <section className="section bg-white">
        <div className="nav-container space-y-8">
          <div className="grid gap-10 lg:grid-cols-[0.85fr_1.15fr]">
            <div className="flex justify-center">
              <div className="flex h-56 w-56 items-center justify-center rounded-3xl gradient-navy shadow-xl sm:h-64 sm:w-64">
                <LogoMark className="h-28 w-28" />
              </div>
            </div>
            <div className="space-y-5">
              <div>
                <h2 className="text-2xl font-extrabold text-nova-navy">{settings.founderName}</h2>
                <p className="text-lg font-semibold text-slate-700">{settings.founderTitle}</p>
              </div>
              <p className="text-sm leading-relaxed text-slate-600">{settings.founderBio}</p>
              <div className="card border-nova-gold/30 bg-nova-gold/5 p-5">
                <h3 className="flex items-center gap-2 font-bold text-nova-navy">🎯 Mission éducative</h3>
                <p className="mt-2 text-sm text-slate-600">{settings.founderMission}</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="section bg-slate-50">
        <div className="nav-container space-y-8">
          <header className="text-center">
            <h2 className="text-2xl font-extrabold text-nova-navy sm:text-3xl">Les valeurs de la plateforme</h2>
            <p className="mx-auto mt-3 max-w-2xl text-sm text-slate-600">
              Une plateforme qui mise sur la simplicité, l'accès gratuit et la protection des données.
            </p>
          </header>
          <div className="grid-cards">
            {VALUES.map((v) => (
              <div key={v.title} className="card p-5">
                <div className="text-3xl">{v.icon}</div>
                <h3 className="mt-3 font-bold text-nova-navy">{v.title}</h3>
                <p className="mt-2 text-sm text-slate-600">{v.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section bg-white">
        <div className="nav-container space-y-8">
          <header className="text-center">
            <h2 className="text-2xl font-extrabold text-nova-navy sm:text-3xl">Chiffres réels de la plateforme</h2>
            <p className="mx-auto mt-3 max-w-2xl text-sm text-slate-600">
              Ces statistiques sont calculées à partir des données enregistrées dans la base de données.
            </p>
          </header>
          <div className="card grid grid-cols-2 gap-4 p-6 text-center sm:grid-cols-3 lg:grid-cols-4">
            <Stat value={stats.matieres} label="matières actives" />
            <Stat value={stats.examens} label="examens publiés" />
            <Stat value={stats.examensBlancs} label="examens blancs" />
            <Stat value={stats.ressources} label="ressources" />
            <Stat value={stats.eleves} label="élèves inscrits" />
            <Stat value={stats.tentatives} label="tentatives enregistrées" />
            <Stat value={stats.niveaux} label="niveaux" />
            <Stat value={stats.series} label="séries" />
          </div>
        </div>
      </section>

      <section className="section bg-slate-50">
        <div className="nav-container">
          <div className="card p-6 text-center">
            <h2 className="text-xl font-extrabold text-nova-navy">Vous souhaitez nous aider ?</h2>
            <p className="mx-auto mt-2 max-w-xl text-sm text-slate-600">
              Contactez-nous pour signaler une erreur, proposer une ressource ou demander une assistance.
            </p>
            <div className="mt-4 flex flex-wrap justify-center gap-3">
              <Link href="/contact" className="btn btn-navy">Contact & assistance</Link>
              <Link href="/inscription" className="btn btn-gold">Créer un compte</Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

function Stat({ value, label }: { value: number; label: string }) {
  return (
    <div>
      <div className="text-2xl font-extrabold text-nova-navy">{value}</div>
      <div className="text-xs text-slate-500">{label}</div>
    </div>
  );
}
