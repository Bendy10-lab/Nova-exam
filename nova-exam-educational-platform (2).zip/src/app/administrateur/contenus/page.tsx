import { AdminSection } from "@/components/admin/admin-common";
import { LevelForm, ResourceForm, SeriesForm, SubjectForm } from "@/components/admin/admin-forms-1";
import { db } from "@/db";
import { levels, resources, series, subjects } from "@/db/schema";
import { asc, desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function ContenusPage() {
  const [levelRows, seriesRows, subjectRows, resourceRows] = await Promise.all([
    db.select().from(levels).orderBy(asc(levels.position)),
    db.select().from(series).orderBy(asc(series.position)),
    db.select().from(subjects).orderBy(asc(subjects.position)),
    db.select().from(resources).orderBy(desc(resources.createdAt)).limit(200),
  ]);

  const subjectName = (id: string | null) => subjectRows.find((s) => s.id === id)?.name ?? "—";

  return (
    <div className="animate-fade-up space-y-6">
      <header>
        <h1 className="text-2xl font-extrabold text-nova-navy">Contenus pédagogiques</h1>
        <p className="text-sm text-slate-600">
          Gérez les niveaux, les séries, les matières et les ressources. Toutes les modifications sont enregistrées en base.
        </p>
      </header>

      <AdminSection title="Niveaux scolaires" description="Ajoutez, modifiez et organisez les niveaux.">
        <LevelForm levels={levelRows} />
      </AdminSection>

      <AdminSection title="Séries" description="Les séries sont associables à un niveau. Aucune liste fixe : vous adaptez librement.">
        <SeriesForm levels={levelRows} series={seriesRows} />
      </AdminSection>

      <AdminSection title="Matières" description="Ajoutez, modifiez, supprimez les matières pour chaque niveau.">
        <SubjectForm levels={levelRows} subjects={subjectRows} />
      </AdminSection>

      <AdminSection title="Ressources (fiches, résumés, corrigés, PDF)" description="Contenu gratuit publié sur la plateforme.">
        <ResourceForm subjects={subjectRows} />
      </AdminSection>

      <AdminSection title="Ressources enregistrées" description="Liste des ressources déjà publiées ou en brouillon.">
        {resourceRows.length === 0 ? (
          <p className="text-sm text-slate-500">Aucune ressource.</p>
        ) : (
          <ul className="divide-y divide-slate-100 text-sm">
            {resourceRows.map((r) => (
              <li key={r.id} className="flex items-center justify-between gap-3 py-2">
                <span className="font-semibold text-nova-navy">{r.title}</span>
                <span className="text-xs text-slate-500">
                  {subjectName(r.subjectId)} · {r.resourceType}
                  {r.filePath ? " · PDF" : ""} · {r.published ? "publié" : "brouillon"}
                </span>
              </li>
            ))}
          </ul>
        )}
      </AdminSection>
    </div>
  );
}
