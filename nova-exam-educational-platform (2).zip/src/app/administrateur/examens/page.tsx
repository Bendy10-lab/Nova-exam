import { AdminSection } from "@/components/admin/admin-common";
import { ExamForm, InteractiveExamForm, QuestionsEditor } from "@/components/admin/admin-forms-2";
import { db } from "@/db";
import { exams, interactiveExams, levels, questions, series, subjects } from "@/db/schema";
import { asc, desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function AdminExamensPage() {
  const [levelRows, seriesRows, subjectRows, libraryExams, examRows, questionRows] = await Promise.all([
    db.select().from(levels).orderBy(asc(levels.position)),
    db.select().from(series).orderBy(asc(series.position)),
    db.select().from(subjects).orderBy(asc(subjects.position)),
    db
      .select({
        id: exams.id,
        title: exams.title,
        subjectName: subjects.name,
        filePath: exams.filePath,
        correctionFilePath: exams.correctionFilePath,
        published: exams.published,
        isOfficial: exams.isOfficial,
        year: exams.year,
        examType: exams.examType,
      })
      .from(exams)
      .leftJoin(subjects, eq(exams.subjectId, subjects.id))
      .orderBy(desc(exams.createdAt)),
    db
      .select({
        id: interactiveExams.id,
        title: interactiveExams.title,
        durationMinutes: interactiveExams.durationMinutes,
        maxScore: interactiveExams.maxScore,
        passingScore: interactiveExams.passingScore,
        isWhitePaper: interactiveExams.isWhitePaper,
        published: interactiveExams.published,
        subjectName: subjects.name,
        levelName: levels.name,
      })
      .from(interactiveExams)
      .leftJoin(subjects, eq(interactiveExams.subjectId, subjects.id))
      .leftJoin(levels, eq(interactiveExams.levelId, levels.id))
      .orderBy(desc(interactiveExams.createdAt)),
    db.select().from(questions).orderBy(asc(questions.orderNo)),
  ]);

  const questionCounts = new Map<string, number>();
  for (const q of questionRows) {
    questionCounts.set(q.examId, (questionCounts.get(q.examId) ?? 0) + 1);
  }

  const enrichedInteractive = examRows.map((e) => ({ ...e, questionCount: questionCounts.get(e.id) ?? 0 }));
  const firstExamId = enrichedInteractive[0]?.id ?? "";
  const firstQuestions = questionRows.filter((q) => q.examId === firstExamId);

  return (
    <div className="animate-fade-up space-y-6">
      <header>
        <h1 className="text-2xl font-extrabold text-nova-navy">Examens, PDF & questions</h1>
        <p className="text-sm text-slate-600">
          Importez des examens précédents avec leurs corrigés, créez des examens blancs interactifs et configurez les
          questions.
        </p>
      </header>

      <AdminSection
        title="Bibliothèque d'examens (PDF)"
        description="Ajoutez un examen, importez le PDF et le corrigé depuis votre téléphone."
      >
        <ExamForm levels={levelRows} series={seriesRows} subjects={subjectRows} exams={libraryExams} />
      </AdminSection>

      <AdminSection
        title="Examens interactifs & blancs"
        description="Configurez la durée, la note maximale, le seuil de réussite et les questions."
      >
        <InteractiveExamForm
          levels={levelRows}
          series={seriesRows}
          subjects={subjectRows}
          exams={enrichedInteractive}
        />
      </AdminSection>

      {firstExamId ? (
        <AdminSection title={`Éditeur de questions — ${enrichedInteractive[0].title}`} description="Les réponses correctes sont masquées aux élèves jusqu'à la soumission.">
          <QuestionsEditor
            examId={firstExamId}
            initialQuestions={firstQuestions.map((q) => ({
              ...q,
              optionsJson: (q.optionsJson as { text: string }[] | null) ?? null,
            }))}
          />
        </AdminSection>
      ) : null}
    </div>
  );
}
