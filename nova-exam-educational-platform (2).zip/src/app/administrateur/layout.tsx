import Link from "next/link";
import { redirect } from "next/navigation";
import { Logo } from "@/components/brand";
import { requireAdmin } from "@/lib/auth";

export const dynamic = "force-dynamic";

const NAV = [
  { href: "/administrateur", label: "Tableau de bord", exact: true },
  { href: "/administrateur/contenus", label: "Niveaux · Séries · Matières · Ressources" },
  { href: "/administrateur/examens", label: "Examens & Questions" },
  { href: "/administrateur/promotions", label: "Gestion des promotions" },
  { href: "/administrateur/utilisateurs", label: "Utilisateurs" },
  { href: "/administrateur/parametres", label: "Paramètres & Annonces" },
  { href: "/administrateur/resultats", label: "Résultats & Journaux" },
];

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const user = await requireAdmin();

  return (
    <div className="section">
      <div className="nav-container grid gap-6 lg:grid-cols-[260px_1fr]">
        <aside className="space-y-4">
          <div className="card p-4">
            <Logo />
            <div className="mt-3 space-y-1 text-sm">
              <p className="font-semibold text-nova-navy">{user.nom}</p>
              <p className="text-xs text-slate-500">{user.email}</p>
              <span className="badge badge-gold mt-2">
                {user.role === "super_administrateur" ? "Super administrateur" : "Administrateur"}
              </span>
              <div className="mt-3 flex flex-wrap gap-2">
                <Link href="/espace" className="btn btn-outline btn-sm">Voir l'espace élève</Link>
                <Link href="/" className="btn btn-ghost btn-sm">Site public</Link>
              </div>
            </div>
          </div>
          <nav className="card space-y-1 p-3">
            {NAV.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="block rounded-lg px-3 py-2.5 text-sm font-medium text-slate-700 transition-colors hover:bg-nova-blue/8 hover:text-nova-navy"
              >
                {item.label}
              </Link>
            ))}
          </nav>
          <div className="card p-4 text-xs text-slate-500">
            <p>Les données de cette interface sont lues directement dans la base de données.</p>
            <p className="mt-2">Aucun paiement n'est activé sur cette plateforme.</p>
          </div>
        </aside>
        <div className="min-w-0">{children}</div>
      </div>
    </div>
  );
}
