import Link from "next/link";
import { getAdminStats, getRecentActivity } from "@/lib/content";
import { getSettings, publicSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

export default async function AdminDashboardPage() {
  const [stats, logs, settings] = await Promise.all([
    getAdminStats(),
    getRecentActivity(12),
    getSettings(),
  ]);
  const pub = publicSettings(settings);

  const cards = [
    { label: "Élèves", value: stats.eleves, href: "/administrateur/utilisateurs" },
    { label: "Tentatives", value: stats.tentatives, href: "/administrateur/resultats" },
    { label: "Examens", value: stats.examens, href: "/administrateur/examens" },
    { label: "Promotions", value: stats.promotions, href: "/administrateur/promotions" },
    { label: "Clics sur promotions", value: stats.clics, href: "/administrateur/promotions" },
    { label: "Activités récentes", value: logs.length, href: "/administrateur/resultats" },
  ];

  return (
    <div className="animate-fade-up space-y-6">
      <header>
        <h1 className="text-2xl font-extrabold text-nova-navy">Tableau de bord administrateur</h1>
        <p className="text-sm text-slate-600">
          Gérez la plateforme {pub.siteName} depuis votre téléphone ou votre ordinateur. Toutes les actions sont enregistrées.
        </p>
      </header>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
        {cards.map((c) => (
          <Link key={c.label} href={c.href} className="card card-hover p-4 text-center">
            <div className="text-2xl font-extrabold text-nova-navy">{c.value}</div>
            <div className="text-xs text-slate-500">{c.label}</div>
          </Link>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <section className="card space-y-4 p-6">
          <h2 className="font-bold text-nova-navy">🔍 Matières où les élèves rencontrent des difficultés</h2>
          {stats.matieresDifficiles.length === 0 ? (
            <p className="text-sm text-slate-500">Aucune tentative enregistrée pour l'instant.</p>
          ) : (
            <ul className="space-y-3">
              {stats.matieresDifficiles.map((m) => (
                <li key={m.subjectName}>
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-semibold text-nova-navy">{m.subjectName}</span>
                    <span className={`badge ${m.taux >= 50 ? "badge-green" : "badge-red"}`}>
                      {m.taux} % de réussite ({m.passed}/{m.total})
                    </span>
                  </div>
                  <div className="mt-1 h-2 w-full overflow-hidden rounded-full bg-slate-100">
                    <div className="h-full rounded-full" style={{ width: `${m.taux}%`, backgroundColor: m.taux >= 50 ? "#16a34a" : "#dc2626" }} />
                  </div>
                </li>
              ))}
            </ul>
          )}
          <div className="flex flex-wrap gap-2">
            <Link href="/administrateur/examens" className="btn btn-outline btn-sm">Créer un examen blanc</Link>
            <Link href="/administrateur/contenus" className="btn btn-outline btn-sm">Ajouter une matière</Link>
            <Link href="/administrateur/promotions" className="btn btn-outline btn-sm">Ajouter une promotion</Link>
          </div>
        </section>

        <section className="card space-y-3 p-6">
          <h2 className="font-bold text-nova-navy">📜 Dernières activités</h2>
          {logs.length === 0 ? (
            <p className="text-sm text-slate-500">Aucune activité enregistrée.</p>
          ) : (
            <ul className="space-y-2 text-sm">
              {logs.map((l) => (
                <li key={l.id} className="flex items-start justify-between gap-3 border-b border-slate-100 pb-2 last:border-0">
                  <div>
                    <p className="font-semibold text-nova-navy">{l.action}</p>
                    <p className="text-xs text-slate-500">{l.detail}</p>
                  </div>
                  <span className="shrink-0 text-xs text-slate-400">
                    {new Date(l.createdAt).toLocaleString("fr-FR")}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      <section className="card p-6">
        <h2 className="font-bold text-nova-navy">⚙️ Gestion rapide</h2>
        <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <Link href="/administrateur/contenus" className="rounded-xl bg-slate-50 p-4 hover:border-nova-gold">
            <p className="font-semibold text-nova-navy">Niveaux & séries</p>
            <p className="text-xs text-slate-500">Ajoutez et organisez les niveaux et les séries.</p>
          </Link>
          <Link href="/administrateur/contenus" className="rounded-xl bg-slate-50 p-4">
            <p className="font-semibold text-nova-navy">Matières</p>
            <p className="text-xs text-slate-500">Ajoutez, modifiez, supprimez les matières.</p>
          </Link>
          <Link href="/administrateur/examens" className="rounded-xl bg-slate-50 p-4">
            <p className="font-semibold text-nova-navy">PDF & corrigés</p>
            <p className="text-xs text-slate-500">Importez des examens depuis votre téléphone.</p>
          </Link>
          <Link href="/administrateur/parametres" className="rounded-xl bg-slate-50 p-4">
            <p className="font-semibold text-nova-navy">Fondateur & annonces</p>
            <p className="text-xs text-slate-500">Modifiez la présentation du site et les annonces.</p>
          </Link>
        </div>
      </section>
    </div>
  );
}
