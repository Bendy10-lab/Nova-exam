import { AdminSection } from "@/components/admin/admin-common";
import { AnnouncementForm, SettingsForm } from "@/components/admin/admin-forms-3";
import { db } from "@/db";
import { announcements, settings } from "@/db/schema";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function ParametresPage() {
  const [settingRows, announcementRows] = await Promise.all([
    db.select().from(settings),
    db.select().from(announcements).orderBy(desc(announcements.createdAt)),
  ]);

  const values: Record<string, string> = {};
  for (const row of settingRows) {
    if (row.value !== null) values[row.key] = row.value;
  }

  return (
    <div className="animate-fade-up space-y-6">
      <header>
        <h1 className="text-2xl font-extrabold text-nova-navy">Paramètres, fondateur & annonces</h1>
        <p className="text-sm text-slate-600">
          Modifiez les informations du site, la présentation du fondateur, le numéro WhatsApp et les annonces publiées.
        </p>
      </header>

      <AdminSection title="Informations du site" description="Ces valeurs sont affichées sur le site public.">
        <SettingsForm values={values} />
      </AdminSection>

      <AdminSection title="Annonces de la plateforme" description="Messages affichés aux élèves connectés et sur la page d'accueil.">
        <AnnouncementForm
          announcements={announcementRows.map((a) => ({
            id: a.id,
            title: a.title,
            content: a.content,
            published: a.published,
          }))}
        />
      </AdminSection>
    </div>
  );
}
