import { AdminSection } from "@/components/admin/admin-common";
import { PromotionForm, type PromotionRow } from "@/components/admin/admin-forms-3";
import { db } from "@/db";
import { promotionClicks, promotions } from "@/db/schema";
import { asc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function PromotionsPage() {
  const [rows, clickRows] = await Promise.all([
    db.select().from(promotions).orderBy(asc(promotions.position)),
    db.select().from(promotionClicks),
  ]);

  const clicksByPromotion = new Map<string, number>();
  for (const c of clickRows) clicksByPromotion.set(c.promotionId, (clicksByPromotion.get(c.promotionId) ?? 0) + 1);

  const promotionsWithClicks: PromotionRow[] = rows.map((p) => ({
    id: p.id,
    name: p.name,
    logoPath: p.logoPath,
    shortDescription: p.shortDescription,
    description: p.description,
    category: p.category,
    websiteUrl: p.websiteUrl,
    downloadUrl: p.downloadUrl,
    buttonText: p.buttonText ?? "Visiter",
    startsAt: p.startsAt ? p.startsAt.toISOString() : null,
    endsAt: p.endsAt ? p.endsAt.toISOString() : null,
    status: p.status,
    position: p.position,
    showOnHome: p.showOnHome,
    showInFooter: p.showInFooter,
    showInDashboard: p.showInDashboard,
    clicks: clicksByPromotion.get(p.id) ?? 0,
  }));

  return (
    <div className="animate-fade-up space-y-6">
      <header>
        <h1 className="text-2xl font-extrabold text-nova-navy">Gestion des promotions</h1>
        <p className="text-sm text-slate-600">
          Ajoutez, modifiez, désactivez ou supprimez les autres plateformes présentées sur NOVA EXAM. Les modifications
          sont instantanées sur les pages publiques.
        </p>
      </header>

      <AdminSection
        title="Ajouter une promotion"
        description="Nom, logo, description, liens, dates, statut et position d'affichage."
      >
        <PromotionForm promotions={promotionsWithClicks} />
      </AdminSection>

      <AdminSection title="Statistiques des clics" description="Clics réellement enregistrés depuis les pages publiques.">
        {promotionsWithClicks.length === 0 ? (
          <p className="text-sm text-slate-500">Aucune promotion.</p>
        ) : (
          <div className="space-y-3">
            {promotionsWithClicks
              .slice()
              .sort((a, b) => b.clicks - a.clicks)
              .map((p) => (
                <div key={p.id} className="flex items-center justify-between gap-3 rounded-xl bg-slate-50 p-3 text-sm">
                  <span className="font-semibold text-nova-navy">{p.name}</span>
                  <span className="badge badge-navy">{p.clicks} clic(s)</span>
                </div>
              ))}
            <p className="text-xs text-slate-500">
              Total des clics enregistrés : {promotionsWithClicks.reduce((sum, p) => sum + p.clicks, 0)}
            </p>
          </div>
        )}
      </AdminSection>

      <AdminSection title="Publication publique" description="Seules les promotions publiées et actives apparaissent.">
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="rounded-xl bg-slate-50 p-4 text-sm">
            <p className="font-semibold text-nova-navy">Page d'accueil</p>
            <p className="text-xs text-slate-500">Promotions avec « Page d'accueil » activé.</p>
          </div>
          <div className="rounded-xl bg-slate-50 p-4 text-sm">
            <p className="font-semibold text-nova-navy">Pied de page</p>
            <p className="text-xs text-slate-500">Promotions avec « Pied de page » activé.</p>
          </div>
          <div className="rounded-xl bg-slate-50 p-4 text-sm">
            <p className="font-semibold text-nova-navy">Tableau de bord élève</p>
            <p className="text-xs text-slate-500">Promotions avec « Tableau de bord élève » activé.</p>
          </div>
          <div className="rounded-xl bg-slate-50 p-4 text-sm">
            <p className="font-semibold text-nova-navy">Page /plateformes</p>
            <p className="text-xs text-slate-500">Toutes les promotions publiées et actives.</p>
          </div>
        </div>
      </AdminSection>
    </div>
  );
}
