import { AdminSection } from "@/components/admin/admin-common";
import { db } from "@/db";
import { attempts, interactiveExams, promotionClicks, promotions, subjects } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function ResultatsPage() {
  const [attemptRows, clickRows, promoRows] = await Promise.all([
    db
      .select({
        id: attempts.id,
        examTitle: attempts.examTitle,
        percent: attempts.percent,
        score: attempts.score,
        maxScore: attempts.maxScore,
        passed: attempts.passed,
        submittedAt: attempts.submittedAt,
        subjectName: subjects.name,
      })
      .from(attempts)
      .leftJoin(interactiveExams, eq(attempts.examId, interactiveExams.id))
      .leftJoin(subjects, eq(interactiveExams.subjectId, subjects.id))
      .orderBy(desc(attempts.submittedAt ?? attempts.createdAt))
      .limit(50),
    db.select().from(promotionClicks).orderBy(desc(promotionClicks.createdAt)).limit(200),
    db.select({ id: promotions.id, name: promotions.name }).from(promotions),
  ]);

  const clicksByPromotion = new Map<string, number>();
  for (const c of clickRows) clicksByPromotion.set(c.promotionId, (clicksByPromotion.get(c.promotionId) ?? 0) + 1);

  const totalClicks = clickRows.length;
  const totalAttempts = attemptRows.length;
  const passedCount = attemptRows.filter((a) => a.passed).length;

  return (
    <div className="animate-fade-up space-y-6">
      <header>
        <h1 className="text-2xl font-extrabold text-nova-navy">Résultats & journaux</h1>
        <p className="text-sm text-slate-600">
          Statistiques réelles issues de la base de données. Aucune donnée privée d'élève n'est exposée au-delà de ce
          tableau.
        </p>
      </header>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Stat value={totalAttempts} label="Tentatives" />
        <Stat value={passedCount} label="Tentatives réussies" />
        <Stat value={totalClicks} label="Clics sur promotions" />
        <Stat value={attemptRows.length > 0 ? Math.round((passedCount / totalAttempts) * 100) : 0} label="Taux de réussite %" />
      </div>

      <AdminSection title="Derniers résultats" description="Dernières tentatives soumises par les élèves.">
        {attemptRows.length === 0 ? (
          <p className="text-sm text-slate-500">Aucune tentative enregistrée.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-slate-500">
                  <th className="py-2 pr-3">Examen</th>
                  <th className="py-2 pr-3">Matière</th>
                  <th className="py-2 pr-3">Note</th>
                  <th className="py-2 pr-3">Résultat</th>
                  <th className="py-2">Date</th>
                </tr>
              </thead>
              <tbody>
                {attemptRows.map((a) => (
                  <tr key={a.id} className="border-t border-slate-100">
                    <td className="py-2 pr-3 font-semibold text-nova-navy">{a.examTitle}</td>
                    <td className="py-2 pr-3 text-slate-600">{a.subjectName ?? "—"}</td>
                    <td className="py-2 pr-3 text-slate-600">{a.score}/{a.maxScore}</td>
                    <td className="py-2 pr-3">
                      <span className={`badge ${a.passed ? "badge-green" : "badge-red"}`}>{a.percent} %</span>
                    </td>
                    <td className="py-2 text-slate-600">
                      {a.submittedAt ? a.submittedAt.toLocaleString("fr-FR") : "En cours"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </AdminSection>

      <AdminSection title="Clics sur les promotions" description="Clics réellement enregistrés par les visiteurs.">
        {promoRows.length === 0 ? (
          <p className="text-sm text-slate-500">Aucune promotion.</p>
        ) : (
          <ul className="space-y-2 text-sm">
            {promoRows.map((p) => (
              <li key={p.id} className="flex items-center justify-between gap-3 rounded-xl bg-slate-50 p-3">
                <span className="font-semibold text-nova-navy">{p.name}</span>
                <span className="badge badge-navy">{clicksByPromotion.get(p.id) ?? 0} clic(s)</span>
              </li>
            ))}
          </ul>
        )}
      </AdminSection>
    </div>
  );
}

function Stat({ value, label }: { value: number; label: string }) {
  return (
    <div className="card p-4 text-center">
      <div className="text-2xl font-extrabold text-nova-navy">{value}</div>
      <div className="text-xs text-slate-500">{label}</div>
    </div>
  );
}
