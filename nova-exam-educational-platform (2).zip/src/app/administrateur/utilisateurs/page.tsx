import { AdminSection } from "@/components/admin/admin-common";
import { UserActions } from "@/components/admin/admin-forms-3";
import { db } from "@/db";
import { activityLogs, users } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function UtilisateursPage() {
  const userRows = await db
    .select({
      id: users.id,
      nom: users.nom,
      email: users.email,
      role: users.role,
      isActive: users.isActive,
      niveau: users.niveau,
      serie: users.serie,
      lastLoginAt: users.lastLoginAt,
      createdAt: users.createdAt,
    })
    .from(users)
    .orderBy(desc(users.createdAt));

  const counts = await Promise.all(
    userRows.map(async (u) => ({
      id: u.id,
      count: await db
        .select({ c: activityLogs.id })
        .from(activityLogs)
        .where(eq(activityLogs.userId, u.id))
        .then((r) => r.length),
    })),
  );
  const countMap = new Map(counts.map((c) => [c.id, c.count]));

  const rows = userRows.map((u) => ({
    ...u,
    activityCount: countMap.get(u.id) ?? 0,
    lastLoginAt: u.lastLoginAt ? u.lastLoginAt.toISOString() : null,
    createdAt: u.createdAt.toISOString(),
  }));

  return (
    <div className="animate-fade-up space-y-6">
      <header>
        <h1 className="text-2xl font-extrabold text-nova-navy">Utilisateurs</h1>
        <p className="text-sm text-slate-600">
          Consultez les comptes élèves, recherchez, gérez les rôles, suspendez ou réactivez un compte. Aucun mot de
          passe n'est affiché.
        </p>
      </header>

      <AdminSection title="Comptes" description={`${rows.length} compte(s) enregistré(s)`}>
        <UserActions users={rows} />
      </AdminSection>

      <AdminSection title="Rôles" description="Seuls les administrateurs validés peuvent accéder au panneau.">
        <ul className="space-y-2 text-sm">
          <li className="rounded-xl bg-slate-50 p-3">
            <span className="font-semibold text-nova-navy">Élève</span> — accès à l'espace personnel, aux examens et aux résultats.
          </li>
          <li className="rounded-xl bg-slate-50 p-3">
            <span className="font-semibold text-nova-navy">Administrateur</span> — gestion de la plateforme.
          </li>
          <li className="rounded-xl bg-slate-50 p-3">
            <span className="font-semibold text-nova-navy">Super administrateur</span> — droits complets.
          </li>
        </ul>
        <p className="text-xs text-slate-500">
          La vérification des rôles est effectuée côté serveur sur chaque requête administrative.
        </p>
      </AdminSection>
    </div>
  );
}
