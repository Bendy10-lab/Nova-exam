import { NextRequest, NextResponse } from "next/server";
import { and, eq, ilike, or } from "drizzle-orm";
import { db } from "@/db";
import {
  activityLogs,
  announcements,
  exams,
  interactiveExams,
  levels,
  promotionClicks,
  promotions,
  questions,
  resources,
  series,
  settings,
  subjects,
  users,
} from "@/db/schema";
import { hashPassword, logActivity, requireAdminApi } from "@/lib/auth";
import { resetSettingsCache } from "@/lib/settings";
import { MAX_FILE_BYTES, saveUploadedFile } from "@/lib/upload";
import { resetContent } from "@/lib/seed";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type FormDataMap = Record<string, string>;

async function readBody(req: NextRequest) {
  const contentType = req.headers.get("content-type") ?? "";
  const data: FormDataMap = {};
  const files: Record<string, File> = {};
  if (contentType.includes("multipart/form-data")) {
    const form = await req.formData();
    for (const [key, value] of form.entries()) {
      if (value instanceof File) {
        if (value.size > 0) files[key] = value;
      } else if (value !== null && value !== undefined) {
        data[key] = String(value);
      }
    }
  } else {
    const json = await req.json().catch(() => ({}));
    for (const [key, value] of Object.entries(json ?? {})) {
      data[key] = value === null || value === undefined ? "" : String(value);
    }
  }
  return { data, files };
}

function asBool(value: string | undefined, fallback = false) {
  if (value === undefined || value === "") return fallback;
  return value === "1" || value === "true" || value === "on" || value === "yes";
}

function asInt(value: string | undefined, fallback: number) {
  const n = Number.parseInt(value ?? "", 10);
  return Number.isFinite(n) ? n : fallback;
}

function asIntOrNull(value: string | undefined) {
  if (!value) return null;
  const n = Number.parseInt(value, 10);
  return Number.isFinite(n) ? n : null;
}

function asFloat(value: string | undefined, fallback: number) {
  const n = Number.parseFloat(value ?? "");
  return Number.isFinite(n) ? n : fallback;
}

async function uploadIfPresent(files: Record<string, File>, key: string, folder: string, prefix: string) {
  const file = files[key];
  if (!file) return null;
  if (file.size > MAX_FILE_BYTES) {
    throw new Error(`Le fichier ${key} dépasse 25 Mo.`);
  }
  const saved = await saveUploadedFile(file, folder, prefix);
  return saved.url;
}

export async function POST(req: NextRequest) {
  const auth = await requireAdminApi(req);
  if (!auth.ok) {
    return NextResponse.json({ ok: false, error: "Non autorisé : authentification requise." }, { status: 401 });
  }
  const admin = auth.user!;

  try {
    const { data, files } = await readBody(req);
    const action = data.action ?? "";

    switch (action) {
      // ------------------------------------------------------------------
      // Niveaux
      // ------------------------------------------------------------------
      case "createLevel": {
        const [row] = await db
          .insert(levels)
          .values({
            code: (data.code ?? "").trim(),
            name: (data.name ?? "").trim(),
            description: data.description?.trim() || null,
            position: asInt(data.position, 99),
          })
          .returning();
        await logActivity(admin.id, "niveau_cree", `${row.name} (${row.code})`);
        return NextResponse.json({ ok: true, id: row.id });
      }
      case "updateLevel": {
        const [row] = await db
          .update(levels)
          .set({
            code: (data.code ?? "").trim(),
            name: (data.name ?? "").trim(),
            description: data.description?.trim() || null,
            position: asInt(data.position, 99),
            isActive: asBool(data.isActive, true),
          })
          .where(eq(levels.id, data.id))
          .returning();
        await logActivity(admin.id, "niveau_modifie", `${row.name}`);
        return NextResponse.json({ ok: true });
      }
      case "deleteLevel": {
        const existing = await db.select().from(subjects).where(eq(subjects.levelId, data.id));
        if (existing.length > 0) return fail("Impossible : des matières sont encore liées à ce niveau.");
        await db.delete(levels).where(eq(levels.id, data.id));
        await logActivity(admin.id, "niveau_supprime", data.id);
        return NextResponse.json({ ok: true });
      }

      // ------------------------------------------------------------------
      // Séries
      // ------------------------------------------------------------------
      case "createSeries": {
        const [row] = await db
          .insert(series)
          .values({
            code: (data.code ?? "").trim(),
            name: (data.name ?? "").trim(),
            levelId: data.levelId || null,
            position: asInt(data.position, 99),
          })
          .returning();
        await logActivity(admin.id, "serie_cree", `${row.name}`);
        return NextResponse.json({ ok: true, id: row.id });
      }
      case "updateSeries": {
        await db
          .update(series)
          .set({
            code: (data.code ?? "").trim(),
            name: (data.name ?? "").trim(),
            levelId: data.levelId || null,
            position: asInt(data.position, 99),
            isActive: asBool(data.isActive, true),
          })
          .where(eq(series.id, data.id));
        await logActivity(admin.id, "serie_modifie", data.id);
        return NextResponse.json({ ok: true });
      }
      case "deleteSeries": {
        await db.delete(series).where(eq(series.id, data.id));
        await logActivity(admin.id, "serie_supprime", data.id);
        return NextResponse.json({ ok: true });
      }

      // ------------------------------------------------------------------
      // Matières
      // ------------------------------------------------------------------
      case "createSubject": {
        const [row] = await db
          .insert(subjects)
          .values({
            code: (data.code ?? "").trim(),
            name: (data.name ?? "").trim(),
            description: data.description?.trim() || null,
            levelId: data.levelId || null,
            color: data.color || "#1e3a8a",
            icon: data.icon || null,
            position: asInt(data.position, 99),
          })
          .returning();
        await logActivity(admin.id, "matiere_cree", `${row.name}`);
        return NextResponse.json({ ok: true, id: row.id });
      }
      case "updateSubject": {
        const update: Record<string, unknown> = {
          code: (data.code ?? "").trim(),
          name: (data.name ?? "").trim(),
          description: data.description?.trim() || null,
          levelId: data.levelId || null,
          color: data.color || "#1e3a8a",
          icon: data.icon || null,
          position: asInt(data.position, 99),
          isActive: asBool(data.isActive, true),
        };
        if (files.avatar) update.icon = null;
        await db.update(subjects).set(update).where(eq(subjects.id, data.id));
        await logActivity(admin.id, "matiere_modifie", `${update.name}`);
        return NextResponse.json({ ok: true });
      }
      case "deleteSubject": {
        const [examCount] = await db
          .select({ c: exams.id })
          .from(exams)
          .where(eq(exams.subjectId, data.id))
          .limit(1);
        if (examCount) return fail("Impossible : des examens utilisent encore cette matière.");
        await db.delete(subjects).where(eq(subjects.id, data.id));
        await logActivity(admin.id, "matiere_supprime", data.id);
        return NextResponse.json({ ok: true });
      }

      // ------------------------------------------------------------------
      // Ressources pédagogiques (fiches, résumés, corrigés, PDF)
      // ------------------------------------------------------------------
      case "createResource": {
        const [row] = await db
          .insert(resources)
          .values({
            subjectId: data.subjectId,
            levelId: data.levelId || null,
            title: (data.title ?? "").trim(),
            summary: data.summary?.trim() || null,
            content: data.content?.trim() || null,
            resourceType: data.resourceType || "fiche",
            published: asBool(data.published, true),
          })
          .returning();
        const filePath = await uploadIfPresent(files, "file", "resources", "doc");
        if (filePath) {
          await db.update(resources).set({ filePath }).where(eq(resources.id, row.id));
        }
        await logActivity(admin.id, "ressource_cree", `${row.title}`);
        return NextResponse.json({ ok: true, id: row.id });
      }
      case "updateResource": {
        const updates: Record<string, unknown> = {
          subjectId: data.subjectId || null,
          levelId: data.levelId || null,
          title: (data.title ?? "").trim(),
          summary: data.summary?.trim() || null,
          content: data.content?.trim() || null,
          resourceType: data.resourceType || "fiche",
          published: asBool(data.published, true),
        };
        await db.update(resources).set(updates).where(eq(resources.id, data.id));
        const filePath = await uploadIfPresent(files, "file", "resources", "doc");
        if (filePath) await db.update(resources).set({ filePath }).where(eq(resources.id, data.id));
        await logActivity(admin.id, "ressource_modifie", `${updates.title}`);
        return NextResponse.json({ ok: true });
      }
      case "deleteResource": {
        await db.delete(resources).where(eq(resources.id, data.id));
        await logActivity(admin.id, "ressource_supprime", data.id);
        return NextResponse.json({ ok: true });
      }

      // ------------------------------------------------------------------
      // Bibliothèque d'examens
      // ------------------------------------------------------------------
      case "createExam": {
        const [row] = await db
          .insert(exams)
          .values({
            title: (data.title ?? "").trim(),
            description: data.description?.trim() || null,
            levelId: data.levelId || null,
            serieId: data.serieId || null,
            subjectId: data.subjectId || null,
            year: asIntOrNull(data.year),
            examType: data.examType === "blanc" ? "blanc" : "precedent",
            hasCorrection: asBool(data.hasCorrection, false),
            isOfficial: asBool(data.isOfficial, false),
            published: asBool(data.published, true),
          })
          .returning();
        const filePath = await uploadIfPresent(files, "file", "exams", "paper");
        if (filePath) {
          await db.update(exams).set({ filePath }).where(eq(exams.id, row.id));
        }
        const correctionFilePath = await uploadIfPresent(files, "correction", "exams", "correction");
        if (correctionFilePath) {
          await db
            .update(exams)
            .set({ correctionFilePath, hasCorrection: true })
            .where(eq(exams.id, row.id));
        }
        await logActivity(admin.id, "examen_cree", `${row.title}`);
        return NextResponse.json({ ok: true, id: row.id });
      }
      case "updateExam": {
        const updates: Record<string, unknown> = {
          title: (data.title ?? "").trim(),
          description: data.description?.trim() || null,
          levelId: data.levelId || null,
          serieId: data.serieId || null,
          subjectId: data.subjectId || null,
          year: asIntOrNull(data.year),
          examType: data.examType === "blanc" ? "blanc" : "precedent",
          hasCorrection: asBool(data.hasCorrection, false),
          isOfficial: asBool(data.isOfficial, false),
          published: asBool(data.published, true),
        };
        await db.update(exams).set(updates).where(eq(exams.id, data.id));
        const filePath = await uploadIfPresent(files, "file", "exams", "paper");
        if (filePath) await db.update(exams).set({ filePath }).where(eq(exams.id, data.id));
        const correctionFilePath = await uploadIfPresent(files, "correction", "exams", "correction");
        if (correctionFilePath) {
          await db
            .update(exams)
            .set({ correctionFilePath, hasCorrection: true })
            .where(eq(exams.id, data.id));
        }
        await logActivity(admin.id, "examen_modifie", `${updates.title}`);
        return NextResponse.json({ ok: true });
      }
      case "deleteExam": {
        await db.delete(exams).where(eq(exams.id, data.id));
        await logActivity(admin.id, "examen_supprime", data.id);
        return NextResponse.json({ ok: true });
      }

      // ------------------------------------------------------------------
      // Examens interactifs / blancs
      // ------------------------------------------------------------------
      case "createInteractiveExam": {
        const [row] = await db
          .insert(interactiveExams)
          .values({
            title: (data.title ?? "").trim(),
            description: data.description?.trim() || null,
            subjectId: data.subjectId || null,
            levelId: data.levelId || null,
            serieId: data.serieId || null,
            durationMinutes: asInt(data.durationMinutes, 30),
            maxScore: asFloat(data.maxScore, 100),
            passingScore: asFloat(data.passingScore, 50),
            isWhitePaper: asBool(data.isWhitePaper, true),
            published: asBool(data.published, true),
          })
          .returning();
        await logActivity(admin.id, "examen_interactif_cree", `${row.title}`);
        return NextResponse.json({ ok: true, id: row.id });
      }
      case "updateInteractiveExam": {
        await db
          .update(interactiveExams)
          .set({
            title: (data.title ?? "").trim(),
            description: data.description?.trim() || null,
            subjectId: data.subjectId || null,
            levelId: data.levelId || null,
            serieId: data.serieId || null,
            durationMinutes: asInt(data.durationMinutes, 30),
            maxScore: asFloat(data.maxScore, 100),
            passingScore: asFloat(data.passingScore, 50),
            isWhitePaper: asBool(data.isWhitePaper, true),
            published: asBool(data.published, true),
          })
          .where(eq(interactiveExams.id, data.id));
        await logActivity(admin.id, "examen_interactif_modifie", data.id);
        return NextResponse.json({ ok: true });
      }
      case "deleteInteractiveExam": {
        await db.delete(interactiveExams).where(eq(interactiveExams.id, data.id));
        await logActivity(admin.id, "examen_interactif_supprime", data.id);
        return NextResponse.json({ ok: true });
      }
      case "saveQuestions": {
        const examId = data.id;
        const raw = data.questions ?? "[]";
        let parsed: Array<Record<string, unknown>>;
        try {
          parsed = JSON.parse(raw);
        } catch {
          return fail("Le format des questions est invalide.");
        }
        if (!Array.isArray(parsed)) return fail("Les questions doivent être une liste.");
        await db.delete(questions).where(eq(questions.examId, examId));
        for (let i = 0; i < parsed.length; i++) {
          const q = parsed[i];
          const options = Array.isArray(q.options) ? q.options : [];
          await db.insert(questions).values({
            examId,
            subjectId: (q.subjectId as string) || data.subjectId || null,
            prompt: String(q.prompt ?? "").trim(),
            questionType: (q.type as string) || "mcq",
            optionsJson: options as unknown as object,
            correctIndex: typeof q.correctIndex === "number" ? q.correctIndex : null,
            correctAnswer: (q.correctAnswer as string) || null,
            explanation: (q.explanation as string) || null,
            imagePath: (q.image as string) || null,
            points: asInt(String(q.points ?? "1"), 1),
            orderNo: i + 1,
          });
        }
        await logActivity(admin.id, "questions_sauvees", `${parsed.length} questions pour ${examId}`);
        return NextResponse.json({ ok: true, count: parsed.length });
      }
      case "deleteQuestion": {
        await db.delete(questions).where(eq(questions.id, data.id));
        return NextResponse.json({ ok: true });
      }

      // ------------------------------------------------------------------
      // Annonces
      // ------------------------------------------------------------------
      case "createAnnouncement": {
        await db.insert(announcements).values({
          title: (data.title ?? "").trim(),
          content: (data.content ?? "").trim(),
          published: asBool(data.published, true),
        });
        await logActivity(admin.id, "annonce_cree", `${data.title}`);
        return NextResponse.json({ ok: true });
      }
      case "updateAnnouncement": {
        await db
          .update(announcements)
          .set({
            title: (data.title ?? "").trim(),
            content: (data.content ?? "").trim(),
            published: asBool(data.published, true),
          })
          .where(eq(announcements.id, data.id));
        await logActivity(admin.id, "annonce_modifie", data.id);
        return NextResponse.json({ ok: true });
      }
      case "deleteAnnouncement": {
        await db.delete(announcements).where(eq(announcements.id, data.id));
        return NextResponse.json({ ok: true });
      }

      // ------------------------------------------------------------------
      // Promotions des autres plateformes
      // ------------------------------------------------------------------
      case "createPromotion": {
        const logoPath = await uploadIfPresent(files, "logo", "promotions", "logo");
        const imagePath = await uploadIfPresent(files, "image", "promotions", "image");
        const [row] = await db
          .insert(promotions)
          .values({
            name: (data.name ?? "").trim(),
            logoPath: logoPath ?? imagePath ?? null,
            shortDescription: data.shortDescription?.trim() || null,
            description: data.description?.trim() || null,
            category: data.category?.trim() || null,
            websiteUrl: data.websiteUrl?.trim() || null,
            downloadUrl: data.downloadUrl?.trim() || null,
            buttonText: data.buttonText?.trim() || "Visiter",
            startsAt: data.startsAt ? new Date(data.startsAt) : null,
            endsAt: data.endsAt ? new Date(data.endsAt) : null,
            status: (data.status as string) || "brouillon",
            position: asInt(data.position, 99),
            showOnHome: asBool(data.showOnHome, true),
            showInFooter: asBool(data.showInFooter, false),
            showInDashboard: asBool(data.showInDashboard, false),
          })
          .returning();
        await logActivity(admin.id, "promotion_cree", `${row.name}`);
        return NextResponse.json({ ok: true, id: row.id });
      }
      case "updatePromotion": {
        const updates: Record<string, unknown> = {
          name: (data.name ?? "").trim(),
          shortDescription: data.shortDescription?.trim() || null,
          description: data.description?.trim() || null,
          category: data.category?.trim() || null,
          websiteUrl: data.websiteUrl?.trim() || null,
          downloadUrl: data.downloadUrl?.trim() || null,
          buttonText: data.buttonText?.trim() || "Visiter",
          startsAt: data.startsAt ? new Date(data.startsAt) : null,
          endsAt: data.endsAt ? new Date(data.endsAt) : null,
          status: (data.status as string) || "brouillon",
          position: asInt(data.position, 99),
          showOnHome: asBool(data.showOnHome, true),
          showInFooter: asBool(data.showInFooter, false),
          showInDashboard: asBool(data.showInDashboard, false),
        };
        await db.update(promotions).set(updates).where(eq(promotions.id, data.id));
        const logoPath = await uploadIfPresent(files, "logo", "promotions", "logo");
        if (logoPath) await db.update(promotions).set({ logoPath }).where(eq(promotions.id, data.id));
        await logActivity(admin.id, "promotion_modifie", `${updates.name}`);
        return NextResponse.json({ ok: true });
      }
      case "deletePromotion": {
        await db.delete(promotions).where(eq(promotions.id, data.id));
        await db.delete(promotionClicks).where(eq(promotionClicks.promotionId, data.id));
        await logActivity(admin.id, "promotion_supprime", data.id);
        return NextResponse.json({ ok: true });
      }

      // ------------------------------------------------------------------
      // Paramètres du site & présentation du fondateur
      // ------------------------------------------------------------------
      case "updateSettings": {
        const raw = data.values ?? "{}";
        let values: Record<string, string>;
        try {
          values = JSON.parse(raw);
        } catch {
          return fail("Format des paramètres invalide.");
        }
        for (const [key, value] of Object.entries(values)) {
          if (key.startsWith("_") || key.length === 0) continue;
          await db
            .insert(settings)
            .values({ key, value: String(value) })
            .onConflictDoUpdate({ target: settings.key, set: { value: String(value), updatedAt: new Date() } });
        }
        resetSettingsCache();
        await logActivity(admin.id, "parametres_modifies", `${Object.keys(values).length} paramètres`);
        return NextResponse.json({ ok: true });
      }

      // ------------------------------------------------------------------
      // Utilisateurs
      // ------------------------------------------------------------------
      case "updateUserStatus": {
        const isActive = asBool(data.isActive, true);
        await db.update(users).set({ isActive }).where(eq(users.id, data.id));
        await logActivity(admin.id, isActive ? "utilisateur_reactivé" : "utilisateur_suspendu", data.id);
        return NextResponse.json({ ok: true });
      }
      case "updateUserRole": {
        const role = data.role as "eleve" | "administrateur" | "super_administrateur";
        if (!["eleve", "administrateur", "super_administrateur"].includes(role)) {
          return fail("Rôle invalide.");
        }
        if (role !== "super_administrateur" && data.id === admin.id) {
          return fail("Vous ne pouvez pas vous retirer vos propres droits super administrateur.");
        }
        await db.update(users).set({ role }).where(eq(users.id, data.id));
        await logActivity(admin.id, "role_modifie", `${data.id} -> ${role}`);
        return NextResponse.json({ ok: true });
      }
      case "resetUserPassword": {
        const password = (data.password ?? "").trim();
        if (password.length < 8) return fail("Le mot de passe doit contenir au moins 8 caractères.");
        await db
          .update(users)
          .set({ passwordHash: await hashPassword(password), resetToken: null, resetExpires: null })
          .where(eq(users.id, data.id));
        await logActivity(admin.id, "mot_de_passe_reinitialise", data.id);
        return NextResponse.json({ ok: true });
      }

      // ------------------------------------------------------------------
      // Utilitaires
      // ------------------------------------------------------------------
      case "uploadFile": {
        const folder = (data.folder || "general").replace(/[^a-z0-9-_]/gi, "");
        const prefix = (data.prefix || "file").replace(/[^a-z0-9-_]/gi, "");
        const file = files.file ?? files.logo ?? files.image ?? files.correction;
        if (!file) return fail("Aucun fichier sélectionné.");
        const saved = await saveUploadedFile(file, folder, prefix);
        return NextResponse.json({ ok: true, url: saved.url, path: saved.path });
      }
      case "resetDemoContent": {
        await resetContent();
        await logActivity(admin.id, "contenu_demonstration_reinitialise", "ressources & examens blancs démo");
        return NextResponse.json({ ok: true });
      }
      case "ping":
        return NextResponse.json({ ok: true, role: admin.role });

      default:
        return fail(`Action inconnue : ${action}`, 400);
    }
  } catch (error) {
    console.error("[admin] erreur", error);
    return fail("Erreur serveur. Vérifiez que la base de données est accessible.", 500);
  }
}

function fail(message: string, status = 400) {
  return NextResponse.json({ ok: false, error: message }, { status });
}

export async function GET(req: NextRequest) {
  const auth = await requireAdminApi(req);
  if (!auth.ok) return fail("Non autorisé.", 401);
  const url = new URL(req.url);
  const q = url.searchParams.get("q") ?? "";
  const page = Math.max(1, Number.parseInt(url.searchParams.get("page") ?? "1", 10));
  const perPage = Math.min(50, Math.max(5, Number.parseInt(url.searchParams.get("perPage") ?? "10", 10)));

  if (url.searchParams.get("entity") === "users") {
    const conditions = q ? [likeUsers(q)] : [];
    const rows = await db
      .select({
        id: users.id,
        email: users.email,
        nom: users.nom,
        role: users.role,
        isActive: users.isActive,
        niveau: users.niveau,
        serie: users.serie,
        createdAt: users.createdAt,
        lastLoginAt: users.lastLoginAt,
      })
      .from(users)
      .where(and(...conditions))
      .orderBy(users.createdAt)
      .limit(perPage)
      .offset((page - 1) * perPage);
    const enriched = await Promise.all(
      rows.map(async (r) => {
        const attempts = await db
          .select({ c: users.id })
          .from(activityLogs)
          .where(eq(activityLogs.userId, r.id))
          .then((x) => x.length);
        return { ...r, activityCount: attempts };
      }),
    );
    const [totalRow] = await db
      .select({ c: users.id })
      .from(users)
      .where(q ? likeUsers(q) : eq(users.role, "eleve"))
      .limit(1);
    return NextResponse.json({ ok: true, users: enriched, total: totalRow ? totalRow.c : 0 });
  }

  if (url.searchParams.get("entity") === "attempts") {
    const rows = await db
      .select({
        id: activityLogs.id,
        action: activityLogs.action,
        detail: activityLogs.detail,
        createdAt: activityLogs.createdAt,
        userName: users.nom,
      })
      .from(activityLogs)
      .leftJoin(users, eq(activityLogs.userId, users.id))
      .orderBy(activityLogs.createdAt)
      .limit(perPage)
      .offset((page - 1) * perPage);
    return NextResponse.json({ ok: true, logs: rows });
  }

  if (url.searchParams.get("entity") === "promotionClicks") {
    const rows = await db
      .select({ promotionId: promotionClicks.promotionId, createdAt: promotionClicks.createdAt })
      .from(promotionClicks)
      .orderBy(promotionClicks.createdAt);
    const byPromotion = new Map<string, number>();
    for (const r of rows) byPromotion.set(r.promotionId, (byPromotion.get(r.promotionId) ?? 0) + 1);
    const promos = await db.select({ id: promotions.id, name: promotions.name, clicks: promotions.clicks }).from(promotions);
    const detail = promos.map((p) => ({
      id: p.id,
      name: p.name,
      registeredClicks: byPromotion.get(p.id) ?? 0,
      reportedClicks: p.clicks,
    }));
    detail.sort((a, b) => b.registeredClicks - a.registeredClicks);
    return NextResponse.json({ ok: true, clicks: detail, total: rows.length });
  }

  if (url.searchParams.get("entity") === "subjects") {
    return NextResponse.json({ ok: true, subjects: await db.select().from(subjects) });
  }
  if (url.searchParams.get("entity") === "levels") {
    return NextResponse.json({ ok: true, levels: await db.select().from(levels) });
  }

  const [promotionsRows, announcementsRows, usersRows, examsCount, interactiveCount, resourcesCount, attemptsCount, clicksCount] =
    await Promise.all([
      db.select().from(promotions).orderBy(promotions.position),
      db.select().from(announcements).orderBy(announcements.createdAt),
      db.select({ id: users.id, email: users.email, nom: users.nom, role: users.role, isActive: users.isActive }).from(users),
      db.select({ c: exams.id }).from(exams),
      db.select({ c: interactiveExams.id }).from(interactiveExams),
      db.select({ c: resources.id }).from(resources),
      db.select({ c: activityLogs.id }).from(activityLogs),
      db.select({ c: promotionClicks.id }).from(promotionClicks),
    ]);
  return NextResponse.json({
    ok: true,
    stats: {
      promotions: promotionsRows.length,
      annonces: announcementsRows.length,
      eleves: usersRows.filter((u) => u.role === "eleve").length,
      examens: examsCount.length,
      examensInteractifs: interactiveCount.length,
      ressources: resourcesCount.length,
      journaux: attemptsCount.length,
      clics: clicksCount.length,
    },
    promotions: promotionsRows,
    annonces: announcementsRows,
    users: usersRows,
  });
}

function likeUsers(q: string) {
  const term = `%${q}%`;
  return or(ilike(users.nom, term), ilike(users.email, term));
}
