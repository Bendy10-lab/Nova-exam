import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { profiles, users } from "@/db/schema";
import {
  clearSessionCookie,
  getSession,
  hashPassword,
  logActivity,
  setSessionCookie,
  toSafeUser,
  verifyPassword,
} from "@/lib/auth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const PASSWORD_MIN = 8;

const registerSchema = z.object({
  nom: z.string().min(2).max(120),
  email: z.string().email().max(160).toLowerCase(),
  password: z.string().min(PASSWORD_MIN, `Le mot de passe doit contenir au moins ${PASSWORD_MIN} caractères.`),
  niveau: z.string().max(40).optional().nullable(),
  serie: z.string().max(40).optional().nullable(),
});

const loginSchema = z.object({
  email: z.string().email().toLowerCase(),
  password: z.string().min(1),
});

const forgotSchema = z.object({ email: z.string().email().toLowerCase() });

const resetSchema = z.object({
  token: z.string().min(6),
  password: z.string().min(PASSWORD_MIN, `Le mot de passe doit contenir au moins ${PASSWORD_MIN} caractères.`),
});

const profileSchema = z.object({
  nom: z.string().min(2).max(120),
  niveau: z.string().max(40).optional().nullable(),
  serie: z.string().max(40).optional().nullable(),
});

const passwordSchema = z.object({
  current: z.string().min(1),
  next: z.string().min(PASSWORD_MIN, `Le mot de passe doit contenir au moins ${PASSWORD_MIN} caractères.`),
});

function fail(message: string, status = 400) {
  return NextResponse.json({ ok: false, error: message }, { status });
}

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const action = typeof body.action === "string" ? body.action : "";

  try {
    switch (action) {
      case "register": {
        const parsed = registerSchema.safeParse(body);
        if (!parsed.success) return fail(parsed.error.issues[0]?.message ?? "Champs invalides.");
        const { nom, email, password, niveau, serie } = parsed.data;
        const [existing] = await db.select().from(users).where(eq(users.email, email)).limit(1);
        if (existing) return fail("Un compte existe déjà avec cet e-mail.", 409);

        const passwordHash = await hashPassword(password);
        const [created] = await db
          .insert(users)
          .values({
            email,
            passwordHash,
            nom,
            niveau,
            serie,
            role: "eleve",
            emailVerified: false,
          })
          .returning();
        await db.insert(profiles).values({ userId: created.id });
        await logActivity(created.id, "inscription", `Nouveau compte élève : ${created.nom}`);

        const token = await signTokenFor(created.id, created.email, created.role);
        await setSessionCookie(token);
        return NextResponse.json({ ok: true, user: toSafeUser(created) });
      }

      case "login": {
        const parsed = loginSchema.safeParse(body);
        if (!parsed.success) return fail(parsed.error.issues[0]?.message ?? "Champs invalides.");
        const [user] = await db.select().from(users).where(eq(users.email, parsed.data.email)).limit(1);
        if (!user) return fail("E-mail ou mot de passe incorrect.", 401);
        if (!user.isActive) return fail("Ce compte est suspendu. Contactez le support.", 403);
        const ok = await verifyPassword(parsed.data.password, user.passwordHash);
        if (!ok) return fail("E-mail ou mot de passe incorrect.", 401);

        await db.update(users).set({ lastLoginAt: new Date() }).where(eq(users.id, user.id));
        await logActivity(user.id, "connexion", `Connexion réussie : ${user.email}`);

        const token = await signTokenFor(user.id, user.email, user.role);
        await setSessionCookie(token);
        const [fresh] = await db.select().from(users).where(eq(users.id, user.id)).limit(1);
        return NextResponse.json({ ok: true, user: toSafeUser(fresh!) });
      }

      case "logout": {
        await clearSessionCookie();
        return NextResponse.json({ ok: true });
      }

      case "forgot": {
        const parsed = forgotSchema.safeParse(body);
        if (!parsed.success) return fail(parsed.error.issues[0]?.message ?? "E-mail invalide.");
        const [user] = await db.select().from(users).where(eq(users.email, parsed.data.email)).limit(1);
        if (!user) return NextResponse.json({ ok: true, message: "Si ce compte existe, un lien de réinitialisation a été généré." });
        const token = Array.from(globalThis.crypto.getRandomValues(new Uint8Array(24)))
          .map((b) => b.toString(16).padStart(2, "0"))
          .join("");
        const expires = new Date(Date.now() + 60 * 60 * 1000);
        await db
          .update(users)
          .set({ resetToken: token, resetExpires: expires })
          .where(eq(users.id, user.id));
        await logActivity(user.id, "mot_de_passe_oublie", "Demande de réinitialisation de mot de passe");
        const base = process.env.NEXT_PUBLIC_BASE_URL ?? "http://localhost:3000";
        const resetUrl = `${base}/reinitialisation?token=${token}`;
        // Aucun service SMTP configuré : le lien est renvoyé une fois pour permettre
        // la récupération. En production, le transmettre par e-mail.
        return NextResponse.json({ ok: true, resetUrl, message: resetUrl });
      }

      case "reset": {
        const parsed = resetSchema.safeParse(body);
        if (!parsed.success) return fail(parsed.error.issues[0]?.message ?? "Champs invalides.");
        const [user] = await db
          .select()
          .from(users)
          .where(and(eq(users.resetToken, parsed.data.token)))
          .limit(1);
        if (!user?.resetToken) return fail("Lien de réinitialisation invalide.", 400);
        if (!user.resetExpires || user.resetExpires < new Date()) {
          await db.update(users).set({ resetToken: null, resetExpires: null }).where(eq(users.id, user.id));
          return fail("Ce lien de réinitialisation a expiré. Nouvelle demande requise.", 400);
        }
        await db
          .update(users)
          .set({
            passwordHash: await hashPassword(parsed.data.password),
            resetToken: null,
            resetExpires: null,
          })
          .where(eq(users.id, user.id));
        await logActivity(user.id, "mot_de_passe_modifie", "Mot de passe réinitialisé via le lien de récupération");
        return NextResponse.json({ ok: true, message: "Votre mot de passe a été réinitialisé." });
      }

      case "updateProfile": {
        const session = await getSession();
        if (!session) return fail("Non connecté.", 401);
        const parsed = profileSchema.safeParse(body);
        if (!parsed.success) return fail(parsed.error.issues[0]?.message ?? "Champs invalides.");
        const [updated] = await db
          .update(users)
          .set({ nom: parsed.data.nom, niveau: parsed.data.niveau, serie: parsed.data.serie })
          .where(eq(users.id, session.user.id))
          .returning();
        await logActivity(session.user.id, "profil_modifie", `Profil mis à jour : ${updated.nom}`);
        return NextResponse.json({ ok: true, user: toSafeUser(updated) });
      }

      case "changePassword": {
        const session = await getSession();
        if (!session) return fail("Non connecté.", 401);
        const parsed = passwordSchema.safeParse(body);
        if (!parsed.success) return fail(parsed.error.issues[0]?.message ?? "Champs invalides.");
        const [user] = await db.select().from(users).where(eq(users.id, session.user.id)).limit(1);
        if (!user) return fail("Utilisateur introuvable.", 404);
        const ok = await verifyPassword(parsed.data.current, user.passwordHash);
        if (!ok) return fail("Mot de passe actuel incorrect.", 401);
        await db
          .update(users)
          .set({ passwordHash: await hashPassword(parsed.data.next) })
          .where(eq(users.id, user.id));
        await logActivity(user.id, "mot_de_passe_modifie", "Mot de passe modifié depuis l'espace élève");
        return NextResponse.json({ ok: true, message: "Mot de passe modifié." });
      }

      default:
        return fail("Action inconnue.", 400);
    }
  } catch (error) {
    console.error("[auth] erreur", error);
    return fail("Une erreur est survenue. Réessayez.", 500);
  }
}

export async function GET() {
  const session = await getSession();
  return NextResponse.json({
    ok: true,
    user: session?.user ?? null,
  });
}

async function signTokenFor(id: string, email: string, role: string) {
  const { signSessionToken } = await import("@/lib/auth");
  return signSessionToken({ id, email, role: role as "eleve" | "administrateur" | "super_administrateur" });
}
