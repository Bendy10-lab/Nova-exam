import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { activityLogs } from "@/db/schema";
import { logActivity } from "@/lib/auth";
import { getSettings } from "@/lib/settings";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const action = typeof body.action === "string" ? body.action : "message";
  const message = String(body.message ?? "").trim();
  const email = String(body.email ?? "").trim();
  const sujet = String(body.sujet ?? "").trim();

  if (!message) return NextResponse.json({ ok: false, error: "Le message est obligatoire." }, { status: 400 });
  if (message.length > 4000) return NextResponse.json({ ok: false, error: "Message trop long." }, { status: 400 });

  const settings = await getSettings();
  await db.insert(activityLogs).values({
    action: action === "report" ? "erreur_signalee" : "message_contact",
    detail: `${sujet || "Message"} — ${email || "匿名"} — ${message.slice(0, 200)}`,
  });

  return NextResponse.json({
    ok: true,
    message:
      action === "report"
        ? "Merci. Votre signalement a été enregistré et sera examiné par l'administrateur."
        : `Merci. Votre message a été enregistré. Répondez à ${settings.contact_email ?? "l'adresse de contact"} pour une suite rapide.`,
  });
}
