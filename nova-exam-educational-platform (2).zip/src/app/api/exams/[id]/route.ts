import { NextRequest, NextResponse } from "next/server";
import { and, desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { attempts, interactiveExams, progress, questions, subjects } from "@/db/schema";
import { getSession, logActivity } from "@/lib/auth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type SafeQuestion = {
  id: string;
  orderNo: number;
  prompt: string;
  questionType: string;
  options: { text: string }[];
  points: number;
  imagePath: string | null;
};

/** Retire les réponses correctes pour ne pas les exposer avant la soumission. */
function toSafeQuestions(rows: Awaited<ReturnType<typeof loadQuestions>>): SafeQuestion[] {
  return rows.map((q) => ({
    id: q.id,
    orderNo: q.orderNo,
    prompt: q.prompt,
    questionType: q.questionType,
    options: (q.optionsJson as { text: string }[] | null)?.map((o) => ({ text: String(o.text) })) ?? [],
    points: q.points,
    imagePath: q.imagePath,
  }));
}

async function loadQuestions(examId: string) {
  return db.select().from(questions).where(eq(questions.examId, examId)).orderBy(questions.orderNo);
}

function normalize(value: string) {
  return value
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[.,;:!?()[\]{}"'`]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function scoreAnswers(
  rows: Awaited<ReturnType<typeof loadQuestions>>,
  answers: Record<string, string | number>,
) {
  let maxPoints = 0;
  let earned = 0;
  let correctCount = 0;
  const details: Array<{
    id: string;
    prompt: string;
    correct: boolean;
    points: number;
    earned: number;
    explanation: string | null;
    correctAnswer: string | null;
    userAnswer: string | null;
    questionType: string;
  }> = [];

  for (const q of rows) {
    const max = q.points ?? 1;
    maxPoints += max;
    const raw = answers[q.id];
    const userValue = raw === undefined || raw === null ? "" : String(raw);
    let correct = false;

    if (q.questionType === "mcq") {
      const index = Number.parseInt(userValue, 10);
      correct = Number.isFinite(index) && q.correctIndex !== null && index === q.correctIndex;
    } else {
      if (normalize(userValue) === "") correct = false;
      else {
        const expected = q.correctAnswer ?? "";
        const a = normalize(userValue);
        const b = normalize(expected);
        if (a === b) {
          correct = true;
        } else {
          const tokensA = a.split(" ").filter(Boolean);
          const tokensB = b.split(" ").filter(Boolean);
          const common = tokensA.filter((t) => tokensB.includes(t)).length;
          const ratio = tokensB.length > 0 ? common / tokensB.length : 0;
          correct = ratio >= 0.8;
        }
      }
    }

    if (correct) {
      correctCount += 1;
      earned += max;
    }

    details.push({
      id: q.id,
      prompt: q.prompt,
      correct,
      points: max,
      earned: correct ? max : 0,
      explanation: q.explanation ?? null,
      correctAnswer:
        q.questionType === "mcq"
          ? ((q.optionsJson as { text: string }[] | null)?.[q.correctIndex ?? -1]?.text ?? null)
          : q.correctAnswer,
      userAnswer: userValue || null,
      questionType: q.questionType,
    });
  }

  return { maxPoints: maxPoints || 1, earned, correctCount, details };
}

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const [exam] = await db
    .select({
      id: interactiveExams.id,
      title: interactiveExams.title,
      description: interactiveExams.description,
      durationMinutes: interactiveExams.durationMinutes,
      maxScore: interactiveExams.maxScore,
      passingScore: interactiveExams.passingScore,
      isWhitePaper: interactiveExams.isWhitePaper,
      subjectId: interactiveExams.subjectId,
      published: interactiveExams.published,
      subjectName: subjects.name,
    })
    .from(interactiveExams)
    .leftJoin(subjects, eq(interactiveExams.subjectId, subjects.id))
    .where(eq(interactiveExams.id, id))
    .limit(1);

  if (!exam || !exam.published) {
    return NextResponse.json({ ok: false, error: "Examen introuvable." }, { status: 404 });
  }

  const session = await getSession();
  const rows = await loadQuestions(id);
  if (!session) {
    return NextResponse.json({
      ok: true,
      exam: { ...exam, questionCount: rows.length },
      questions: [],
      requiresLogin: true,
    });
  }

  const [pending] = await db
    .select()
    .from(attempts)
    .where(and(eq(attempts.userId, session.user.id), eq(attempts.examId, id), sql`${attempts.submittedAt} is null`))
    .orderBy(desc(attempts.startedAt))
    .limit(1);

  return NextResponse.json({
    ok: true,
    exam: { ...exam, questionCount: rows.length },
    questions: toSafeQuestions(rows),
    requiresLogin: false,
    attemptId: pending?.id ?? null,
    resumedAt: pending?.startedAt ?? null,
  });
}

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ ok: false, error: "Connectez-vous pour passer cet examen." }, { status: 401 });
  }

  const [exam] = await db
    .select({
      id: interactiveExams.id,
      title: interactiveExams.title,
      subjectId: interactiveExams.subjectId,
      durationMinutes: interactiveExams.durationMinutes,
      maxScore: interactiveExams.maxScore,
      passingScore: interactiveExams.passingScore,
      isWhitePaper: interactiveExams.isWhitePaper,
      published: interactiveExams.published,
    })
    .from(interactiveExams)
    .where(eq(interactiveExams.id, id))
    .limit(1);

  if (!exam || !exam.published) {
    return NextResponse.json({ ok: false, error: "Examen introuvable." }, { status: 404 });
  }

  const body = await req.json().catch(() => ({}));
  const action = body.action ?? "submit";
  const answers = (body.answers ?? {}) as Record<string, string | number>;

  if (action === "start") {
    const [attempt] = await db
      .insert(attempts)
      .values({
        userId: session.user.id,
        examId: exam.id,
        examTitle: exam.title,
        subjectId: exam.subjectId,
        maxScore: exam.maxScore,
        startedAt: new Date(),
      })
      .returning();
    await logActivity(session.user.id, "examen_commencé", `${exam.title}`);
    return NextResponse.json({ ok: true, attemptId: attempt.id });
  }

  const rows = await loadQuestions(id);
  if (rows.length === 0) {
    return NextResponse.json({ ok: false, error: "Aucune question disponible pour cet examen." }, { status: 400 });
  }

  const result = scoreAnswers(rows, answers);
  const percent = Math.round((result.earned / result.maxPoints) * 1000) / 10;
  const score = Math.round((result.earned / result.maxPoints) * exam.maxScore * 10) / 10;
  const passed = percent >= exam.passingScore;

  const feedback =
    percent >= 80
      ? "Excellent travail ! Vous maîtrisez bien cette matière."
      : percent >= exam.passingScore
        ? "Passable. Revoyez les points incorrects avant l'examen officiel."
        : "À retravailler sérieusement. Refaites cet examen après révision des notions concernées.";

  const [attempt] = await db
    .insert(attempts)
    .values({
      userId: session.user.id,
      examId: exam.id,
      examTitle: exam.title,
      subjectId: exam.subjectId,
      maxScore: exam.maxScore,
      score,
      percent,
      passed,
      submittedAt: new Date(),
      durationSeconds:
        typeof body.durationSeconds === "number" ? body.durationSeconds : null,
      answersJson: result.details as unknown as object,
      feedback,
    })
    .returning();

  if (exam.subjectId) {
    await db
      .insert(progress)
      .values({
        userId: session.user.id,
        subjectId: exam.subjectId,
        questionsAnswered: rows.length,
        correctAnswers: result.correctCount,
        lastActivityAt: new Date(),
      })
      .onConflictDoUpdate({
        target: [progress.userId, progress.subjectId],
        set: {
          questionsAnswered: sql`${progress.questionsAnswered} + ${rows.length}`,
          correctAnswers: sql`${progress.correctAnswers} + ${result.correctCount}`,
          lastActivityAt: new Date(),
        },
      });
  }

  await logActivity(
    session.user.id,
    "examen_soumis",
    `${exam.title} — ${percent}% ${passed ? "(réussi)" : "(à retravailler)"}`,
  );

  return NextResponse.json({
    ok: true,
    attemptId: attempt.id,
    score,
    percent,
    passed,
    maxScore: exam.maxScore,
    passingScore: exam.passingScore,
    feedback,
    details: result.details,
    whitePaperNotice: exam.isWhitePaper
      ? "Examen blanc d'entraînement : ce résultat ne constitue pas un résultat officiel."
      : null,
  });
}

export { toSafeQuestions };
