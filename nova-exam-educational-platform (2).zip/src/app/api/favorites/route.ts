import { NextRequest, NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { favorites } from "@/db/schema";
import { getSession } from "@/lib/auth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ ok: false, error: "Connectez-vous." }, { status: 401 });
  }
  const body = await req.json().catch(() => ({}));
  const examId = typeof body.examId === "string" ? body.examId : "";
  if (!examId) return NextResponse.json({ ok: false, error: "Identifiant d'examen requis." }, { status: 400 });

  const [existing] = await db
    .select()
    .from(favorites)
    .where(and(eq(favorites.userId, session.user.id), eq(favorites.examId, examId)))
    .limit(1);

  if (existing) {
    await db.delete(favorites).where(eq(favorites.id, existing.id));
    return NextResponse.json({ ok: true, favorite: false });
  }
  await db.insert(favorites).values({ userId: session.user.id, examId });
  return NextResponse.json({ ok: true, favorite: true });
}
