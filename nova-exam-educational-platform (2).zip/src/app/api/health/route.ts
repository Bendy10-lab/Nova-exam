import { NextResponse } from "next/server";
import { db } from "@/db";
import { sql } from "drizzle-orm";
import { getSettings } from "@/lib/settings";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await db.execute(sql`select 1`);
    const settings = await getSettings();
    return NextResponse.json({
      ok: true,
      status: "healthy",
      app: settings.site_name ?? "NOVA EXAM",
      database: "connected",
    });
  } catch (error) {
    return NextResponse.json(
      { ok: false, status: "unhealthy", database: "unavailable", error: String(error) },
      { status: 503 },
    );
  }
}
