import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { promotions } from "@/db/schema";
import { recordPromotionClick } from "@/lib/content";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** Compte un clic sur une promotion (sans collecte de données personnelles). */
export async function POST(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const [promotion] = await db
    .select({ id: promotions.id, status: promotions.status })
    .from(promotions)
    .where(eq(promotions.id, id))
    .limit(1);
  if (!promotion || promotion.status !== "publiee") {
    return NextResponse.json({ ok: false, error: "Promotion introuvable." }, { status: 404 });
  }
  await recordPromotionClick(id);
  return NextResponse.json({ ok: true });
}
