import { redirect } from "next/navigation";
import { LoginForm } from "@/components/auth-forms";
import { getSession } from "@/lib/auth";

export const dynamic = "force-dynamic";

export default async function ConnexionPage() {
  const session = await getSession();
  if (session) redirect(session.user.role === "eleve" ? "/espace" : "/administrateur");

  return (
    <div className="section">
      <div className="nav-container mx-auto max-w-xl">
        <LoginForm />
      </div>
    </div>
  );
}
