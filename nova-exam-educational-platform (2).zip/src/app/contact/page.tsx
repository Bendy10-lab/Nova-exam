import { ContactForm, FAQ_ITEMS, ReportForm, WhatsAppButton } from "@/components/contact-forms";
import { getSettings, publicSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

export default async function ContactPage() {
  const settings = publicSettings(await getSettings());

  return (
    <div className="animate-fade-up section">
      <div className="nav-container space-y-10">
        <header className="text-center">
          <p className="text-xs font-semibold uppercase tracking-[0.2em] gold-text">Contact & assistance</p>
          <h1 className="mt-2 text-3xl font-extrabold text-nova-navy sm:text-4xl">Nous sommes là pour vous aider</h1>
          <p className="mx-auto mt-3 max-w-2xl text-sm text-slate-600">
            Question, bug, erreur dans un examen ou demande d'assistance : écrivez-nous ou discutez avec nous sur WhatsApp.
          </p>
          {settings.whatsapp ? <div className="mt-4 flex justify-center"><WhatsAppButton whatsapp={settings.whatsapp} /></div> : null}
        </header>

        <div className="grid gap-6 lg:grid-cols-2">
          <ContactForm whatsapp={settings.whatsapp} contactEmail={settings.contactEmail} />
          <ReportForm />
        </div>

        <section className="space-y-6">
          <h2 className="text-2xl font-extrabold text-nova-navy">Questions fréquentes</h2>
          <div className="grid gap-4 md:grid-cols-2">
            {FAQ_ITEMS.map((item) => (
              <details key={item.q} className="card group p-5">
                <summary className="flex cursor-pointer items-center justify-between font-bold text-nova-navy">
                  {item.q}
                  <span className="text-nova-gold transition-transform group-open:rotate-45">+</span>
                </summary>
                <p className="mt-3 text-sm leading-relaxed text-slate-600">{item.a}</p>
              </details>
            ))}
          </div>
        </section>

        <section className="card p-6">
          <h2 className="text-xl font-bold text-nova-navy">Section d'aide</h2>
          <div className="mt-4 grid gap-4 sm:grid-cols-3">
            <div className="rounded-xl bg-slate-50 p-4">
              <p className="text-2xl">📚</p>
              <h3 className="mt-2 font-semibold text-nova-navy">Réviser</h3>
              <p className="text-sm text-slate-600">Consultez les fiches, les résumés et les corrigés gratuits.</p>
            </div>
            <div className="rounded-xl bg-slate-50 p-4">
              <p className="text-2xl">✍️</p>
              <h3 className="mt-2 font-semibold text-nova-navy">S'entraîner</h3>
              <p className="text-sm text-slate-600">Passez un examen blanc et vérifiez vos réponses.</p>
            </div>
            <div className="rounded-xl bg-slate-50 p-4">
              <p className="text-2xl">🧭</p>
              <h3 className="mt-2 font-semibold text-nova-navy">Mon compte</h3>
              <p className="text-sm text-slate-600">Gérez votre profil et votre mot de passe depuis votre espace.</p>
            </div>
          </div>
          <p className="mt-5 text-xs text-slate-500">
            Numéro WhatsApp configurable depuis le panneau d'administration. Aucun numéro n'est inventé : il est défini par l'administrateur.
          </p>
        </section>
      </div>
    </div>
  );
}
