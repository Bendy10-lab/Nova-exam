import Link from "next/link";
import { redirect } from "next/navigation";
import { LogoMark } from "@/components/brand";
import PromotionList from "@/components/promotion-card";
import {
  getPendingAttempts,
  getPublishedAnnouncements,
  getPublishedInteractiveExams,
  getPublicPromotions,
  getRecentExams,
  getStudentFavorites,
  getStudentStats,
  getSubjectsForLevel,
} from "@/lib/content";
import { getSession } from "@/lib/auth";
import { getLevelName } from "@/lib/settings";

export const dynamic = "force-dynamic";

export default async function EspacePage() {
  const session = await getSession();
  if (!session) redirect("/connexion?next=/espace");
  const user = session.user;

  const [stats, favorites, subjects, recentExams, announcements, pending, interactives, promotions] = await Promise.all([
    getStudentStats(user.id),
    getStudentFavorites(user.id),
    getSubjectsForLevel(user.niveau ?? null),
    getRecentExams(6),
    getPublishedAnnouncements(3),
    getPendingAttempts(user.id),
    getPublishedInteractiveExams(user.niveau ?? null),
    getPublicPromotions("dashboard"),
  ]);

  const levelName = await getLevelName(user.niveau);
  const progressWithSubject = stats.progression.map((p) => {
    const subject = subjects.find((s) => s.id === p.subjectId);
    const exams = interactives.filter((i) => i.subjectId === p.subjectId).length;
    return {
      id: p.subjectId,
      name: subject?.name ?? "Matière",
      color: subject?.color ?? "#1e3a8a",
      questionsRepondues: p.questionsAnswered,
      correct: p.correctAnswers,
      rate: p.questionsAnswered > 0 ? Math.round((p.correctAnswers / p.questionsAnswered) * 100) : 0,
      examsDisponibles: exams,
    };
  });

  const touched = new Set(stats.progression.map((p) => p.subjectId));
  const weak = progressWithSubject.filter((p) => p.questionsRepondues > 0 && p.rate < 60).sort((a, b) => a.rate - b.rate);
  const notTouched = subjects.filter((s) => !touched.has(s.id)).slice(0, 3);

  return (
    <div className="animate-fade-up section">
      <div className="nav-container space-y-6">
        <div className="card overflow-hidden gradient-navy p-6 text-white sm:p-8">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white/10 ring-2 ring-nova-gold/40">
                <LogoMark className="h-8 w-8" />
              </div>
              <div>
                <p className="text-xs uppercase tracking-[0.2em] text-nova-gold-light">Espace élève</p>
                <h1 className="text-2xl font-extrabold">{user.nom}</h1>
                <p className="text-sm text-white/75">
                  {levelName ?? "Niveau non précisé"}
                  {user.serie ? ` · ${user.serie}` : ""} · inscrit le {user.createdAt.toLocaleDateString("fr-FR")}
                </p>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              <Link href="/ressources" className="btn btn-gold btn-sm">Réviser</Link>
              <Link href="/examens-blancs" className="btn btn-outline btn-sm">Examens blancs</Link>
              <Link href="/profil" className="btn btn-ghost btn-sm text-white hover:bg-white/10">Profil</Link>
            </div>
          </div>
        </div>

        {/* ---------------------------------------------------------- STATS */}
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          <StatCard value={stats.tentatives} label="Tentatives" />
          <StatCard value={stats.moyenne} label="Moyenne %" />
          <StatCard value={stats.meilleurScore} label="Meilleur %" />
          <StatCard value={stats.favoris} label="Favoris" />
          <StatCard value={stats.questionsRepondues} label="Questions" />
          <StatCard value={stats.exactitude} label="Exactitude %" />
        </div>

        {/* ------------------------------------------------- RÉVISION INTERROMPUE */}
        {pending.length > 0 ? (
          <div className="card border-nova-gold/40 bg-nova-gold/5 p-5">
            <h2 className="flex items-center gap-2 font-bold text-nova-navy">⏳ Révision interrompue</h2>
            <div className="mt-3 space-y-3">
              {pending.map((p) => (
                <div key={p.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl bg-white p-4">
                  <div>
                    <p className="font-semibold text-nova-navy">{p.examTitle}</p>
                    <p className="text-xs text-slate-500">
                      Commencée le {p.startedAt.toLocaleString("fr-FR")} — la progression est conservée.
                    </p>
                  </div>
                  <Link href={`/examens-blancs/passer/${p.examId}`} className="btn btn-navy btn-sm">
                    Reprendre →
                  </Link>
                </div>
              ))}
            </div>
          </div>
        ) : null}

        {/* ----------------------------------------------------- PROGRESSION */}
        <div className="grid gap-6 lg:grid-cols-2">
          <div className="card space-y-4 p-6">
            <h2 className="font-bold text-nova-navy">📈 Progression par matière</h2>
            {progressWithSubject.length === 0 ? (
              <p className="text-sm text-slate-500">Aucune activité encore enregistrée. Commencez par un examen blanc.</p>
            ) : (
              <ul className="space-y-4">
                {progressWithSubject.map((p) => (
                  <li key={p.id}>
                    <div className="flex items-center justify-between text-sm">
                      <span className="font-semibold text-nova-navy">{p.name}</span>
                      <span className="text-slate-500">{p.questionsRepondues} q · {p.rate} %</span>
                    </div>
                    <div className="mt-1.5 h-2 w-full overflow-hidden rounded-full bg-slate-100">
                      <div
                        className="h-full rounded-full"
                        style={{
                          width: `${p.rate}%`,
                          backgroundColor: p.rate >= 60 ? "#16a34a" : p.rate >= 40 ? "#c9a227" : "#dc2626",
                        }}
                      />
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div className="card space-y-4 p-6">
            <h2 className="font-bold text-nova-navy">🎯 Recommandations de révision</h2>
            {weak.length > 0 ? (
              <ul className="space-y-2 text-sm text-slate-600">
                {weak.map((w) => (
                  <li key={w.id} className="rounded-lg bg-amber-50 p-3">
                    <p className="font-semibold text-amber-900">{w.name}</p>
                    <p className="text-xs text-amber-700">
                      Taux de réussite {w.rate} % — revoyez cette matière avant l'examen.
                    </p>
                  </li>
                ))}
              </ul>
            ) : null}
            {notTouched.length > 0 ? (
              <div>
                <p className="text-sm font-semibold text-slate-600">Matières à découvrir</p>
                <ul className="mt-2 space-y-2 text-sm">
                  {notTouched.map((s) => (
                    <li key={s.id} className="flex items-center justify-between rounded-lg bg-slate-50 p-3">
                      <span className="text-nova-navy">{s.icon} {s.name}</span>
                      <Link href={`/ressources?matiere=${s.id}`} className="btn btn-outline btn-sm">Commencer</Link>
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}
            {weak.length === 0 && notTouched.length === 0 ? (
              <p className="text-sm text-slate-500">Continuez vos révisions pour obtenir des recommandations personnalisées.</p>
            ) : null}
            <div className="flex flex-wrap gap-2">
              {interactives.slice(0, 3).map((e) => (
                <Link key={e.id} href={`/examens-blancs/passer/${e.id}`} className="btn btn-navy btn-sm">
                  Examen blanc : {e.title}
                </Link>
              ))}
            </div>
          </div>
        </div>

        {/* ------------------------------------------------ DERNIERS RÉSULTATS */}
        <div className="grid gap-6 lg:grid-cols-2">
          <div className="card space-y-4 p-6">
            <h2 className="font-bold text-nova-navy">📝 Derniers résultats</h2>
            {stats.derniers.length === 0 ? (
              <p className="text-sm text-slate-500">Vous n'avez encore aucun résultat.</p>
            ) : (
              <ul className="space-y-3">
                {stats.derniers.map((a) => (
                  <li key={a.id} className="flex items-center justify-between gap-3 rounded-xl bg-slate-50 p-3">
                    <div>
                      <p className="font-semibold text-nova-navy">{a.examTitle}</p>
                      <p className="text-xs text-slate-500">
                        {a.submittedAt ? a.submittedAt.toLocaleDateString("fr-FR") : "En cours"}
                      </p>
                    </div>
                    <span className={`badge ${a.passed ? "badge-green" : "badge-red"}`}>
                      {a.percent} % · {a.score}/{a.maxScore}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div className="card space-y-4 p-6">
            <h2 className="font-bold text-nova-navy">⭐ Examens favoris</h2>
            {favorites.length === 0 ? (
              <p className="text-sm text-slate-500">Aucun favori. Ajoutez un document depuis sa page pour le retrouver ici.</p>
            ) : (
              <ul className="space-y-3">
                {favorites.map((f) => (
                  <li key={f.id} className="flex items-center justify-between gap-3 rounded-xl bg-slate-50 p-3">
                    <div>
                      <p className="font-semibold text-nova-navy">{f.title}</p>
                      <p className="text-xs text-slate-500">{f.subjectName ?? ""} {f.year ? `· ${f.year}` : ""}</p>
                    </div>
                    <Link href={`/examens/${f.id}`} className="btn btn-outline btn-sm">Voir</Link>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>

        {/* -------------------------------------------------- ANNOUNCES & EXAMENS */}
        <div className="grid gap-6 lg:grid-cols-2">
          <div className="card space-y-3 p-6">
            <h2 className="font-bold text-nova-navy">📢 Annonces</h2>
            {announcements.length === 0 ? (
              <p className="text-sm text-slate-500">Aucune annonce en ce moment.</p>
            ) : (
              announcements.map((a) => (
                <div key={a.id} className="rounded-xl bg-slate-50 p-3">
                  <p className="font-semibold text-nova-navy">{a.title}</p>
                  <p className="mt-1 text-sm text-slate-600">{a.content}</p>
                </div>
              ))
            )}
          </div>

          <div className="card space-y-3 p-6">
            <h2 className="font-bold text-nova-navy">📚 Derniers examens consultés</h2>
            <ul className="space-y-3">
              {recentExams.slice(0, 5).map((e) => (
                <li key={e.id} className="flex items-center justify-between gap-3 rounded-xl bg-slate-50 p-3">
                  <div>
                    <p className="font-semibold text-nova-navy">{e.title}</p>
                    <p className="text-xs text-slate-500">{e.subjectName ?? ""} {e.year ? `· ${e.year}` : ""}</p>
                  </div>
                  <Link href={`/examens/${e.id}`} className="btn btn-outline btn-sm">Ouvrir</Link>
                </li>
              ))}
              {recentExams.length === 0 ? <p className="text-sm text-slate-500">Aucun document publié.</p> : null}
            </ul>
          </div>
        </div>

        {/* ---------------------------------------------------------- MATIERES */}
        <div className="card p-6">
          <h2 className="mb-4 font-bold text-nova-navy">📖 Matières disponibles</h2>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
            {subjects.map((s) => (
              <Link
                key={s.id}
                href={`/ressources?matiere=${s.id}`}
                className="rounded-xl border p-4 text-center transition-colors hover:border-nova-gold"
              >
                <div className="text-2xl">{s.icon ?? "📚"}</div>
                <p className="mt-2 text-sm font-semibold text-nova-navy">{s.name}</p>
              </Link>
            ))}
          </div>
        </div>

        {promotions.length > 0 ? (
          <div className="card space-y-4 p-6">
            <h2 className="font-bold text-nova-navy">Découvrez aussi nos autres plateformes</h2>
            <PromotionList promos={promotions} />
          </div>
        ) : null}
      </div>
    </div>
  );
}

function StatCard({ value, label }: { value: number; label: string }) {
  return (
    <div className="card p-4 text-center">
      <div className="text-2xl font-extrabold text-nova-navy">{value}</div>
      <div className="text-xs text-slate-500">{label}</div>
    </div>
  );
}
