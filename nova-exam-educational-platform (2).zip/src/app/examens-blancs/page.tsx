import Link from "next/link";
import { InteractiveCard, type InteractiveItem } from "@/components/level-content";
import { getPublishedInteractiveExams, searchExams } from "@/lib/content";

export const dynamic = "force-dynamic";

export default async function ExamensBlancsPage() {
  const [interactives, documents] = await Promise.all([
    getPublishedInteractiveExams(),
    searchExams({ examType: "blanc" }),
  ]);

  const items: InteractiveItem[] = interactives.map((e) => ({
    id: e.id,
    title: e.title,
    description: e.description,
    durationMinutes: e.durationMinutes,
    maxScore: e.maxScore,
    isWhitePaper: e.isWhitePaper,
    subjectName: e.subjectName,
  }));

  return (
    <div className="animate-fade-up section">
      <div className="nav-container space-y-6">
        <header>
          <p className="text-xs font-semibold uppercase tracking-[0.2em] gold-text">Entraînement gratuit</p>
          <h1 className="mt-2 text-3xl font-extrabold text-nova-navy sm:text-4xl">Examens blancs</h1>
          <p className="mt-2 max-w-2xl text-sm text-slate-600">
            Passez des examens en ligne avec chronomètre, correction automatique, explications et historique de vos
            tentatives. Aucun paiement.
          </p>
          <p className="mt-3 inline-block rounded-lg bg-amber-50 p-2 text-xs text-amber-800">
            ⚠️ Les examens blancs sont des entraînements. Ils ne constituent pas des résultats officiels.
          </p>
        </header>

        {items.length === 0 ? (
          <div className="card p-8 text-center">
            <p className="text-3xl">✍️</p>
            <p className="mt-3 font-bold text-nova-navy">Aucun examen blanc disponible</p>
            <p className="mt-1 text-sm text-slate-600">
              L'administrateur peut créer des examens blancs avec questions, barème, durée et seuil de réussite depuis le
              panneau d'administration.
            </p>
          </div>
        ) : (
          <div className="grid-cards">
            {items.map((e) => (
              <InteractiveCard key={e.id} exam={e} />
            ))}
          </div>
        )}

        {documents.length > 0 ? (
          <div className="space-y-4">
            <h2 className="text-xl font-bold text-nova-navy">Documents « examen blanc » téléchargeables</h2>
            <div className="grid-cards">
              {documents.map((d) => (
                <div key={d.id} className="card card-hover p-5">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="badge badge-gold">Examen blanc</span>
                    {d.year ? <span className="badge badge-gray">{d.year}</span> : null}
                    {d.hasCorrection ? <span className="badge badge-green">Corrigé</span> : null}
                  </div>
                  <h3 className="mt-2 font-bold text-nova-navy">{d.title}</h3>
                  <p className="mt-1 text-sm text-slate-600">{d.description ?? "—"}</p>
                  <div className="mt-3 flex flex-wrap gap-2 text-xs text-slate-500">
                    {d.subjectName ? <span>{d.subjectName}</span> : null}
                    <Link href={`/examens/${d.id}`} className="btn btn-outline btn-sm">Voir détails</Link>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}
