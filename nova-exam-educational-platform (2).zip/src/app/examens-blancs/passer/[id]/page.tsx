import { redirect } from "next/navigation";
import ExamPlayer from "@/components/exam-player";
import { getSession } from "@/lib/auth";

export const dynamic = "force-dynamic";

export default async function PasserExamenBlanc({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const session = await getSession();
  if (!session) redirect("/connexion?next=/examens-blancs/passer/" + id);

  return <ExamPlayer examId={id} />;
}
