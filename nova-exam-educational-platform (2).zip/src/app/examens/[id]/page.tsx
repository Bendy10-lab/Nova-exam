import Link from "next/link";
import { notFound } from "next/navigation";
import FavoriteButton from "@/components/favorite-button";
import { getExamById, getStudentFavorites } from "@/lib/content";
import { getSession } from "@/lib/auth";

export const dynamic = "force-dynamic";

export default async function ExamDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const exam = await getExamById(id);
  if (!exam || !exam.title) notFound();

  const session = await getSession();
  let isFavorite = false;
  if (session) {
    const favorites = await getStudentFavorites(session.user.id);
    isFavorite = favorites.some((f) => f.id === exam.id);
  }

  return (
    <div className="animate-fade-up section">
      <div className="nav-container max-w-4xl space-y-6">
        <Link href="/examens" className="text-sm font-semibold text-nova-blue underline">← Retour à la bibliothèque</Link>

        <article className="card space-y-5 p-6 sm:p-8">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <span className="badge badge-navy">
                  {exam.examType === "blanc" ? "Examen blanc" : "Examen précédent"}
                </span>
                {exam.year ? <span className="badge badge-gray">{exam.year}</span> : null}
                {exam.hasCorrection ? <span className="badge badge-green">Corrigé disponible</span> : null}
                {exam.isOfficial ? <span className="badge badge-gold">Document officiel</span> : (
                  <span className="badge badge-gray">Document d'entraînement / partagé</span>
                )}
              </div>
              <h1 className="mt-3 text-2xl font-extrabold text-nova-navy sm:text-3xl">{exam.title}</h1>
              <p className="mt-2 text-sm text-slate-500">
                {exam.subjectName ?? "Matière non spécifiée"}
                {exam.levelName ? ` · ${exam.levelName}` : ""}
                {exam.serieName ? ` · ${exam.serieName}` : ""}
              </p>
            </div>
            {session ? <FavoriteButton examId={exam.id} /> : (
              <Link href="/inscription" className="btn btn-outline btn-sm">Se connecter pour favoriser</Link>
            )}
          </div>

          <p className="text-sm leading-relaxed text-slate-600">
            {exam.description ?? "Aucune description fournie pour ce document."}
          </p>

          <div className="grid gap-3 sm:grid-cols-2">
            <div className="rounded-xl bg-slate-50 p-4">
              <h2 className="font-bold text-nova-navy">Document</h2>
              {exam.filePath ? (
                <a href={exam.filePath} download className="btn btn-navy btn-sm mt-3">Télécharger le PDF ⬇</a>
              ) : (
                <p className="mt-2 text-sm text-slate-500">Aucun fichier PDF associé pour le moment.</p>
              )}
            </div>
            <div className="rounded-xl bg-slate-50 p-4">
              <h2 className="font-bold text-nova-navy">Corrigé</h2>
              {exam.correctionFilePath ? (
                <a href={exam.correctionFilePath} download className="btn btn-gold btn-sm mt-3">Télécharger le corrigé ⬇</a>
              ) : (
                <p className="mt-2 text-sm text-slate-500">
                  {exam.hasCorrection ? "Le corrigé est disponible sous une autre forme." : "Corrigé non disponible pour ce document."}
                </p>
              )}
            </div>
          </div>

          <p className="text-xs leading-relaxed text-slate-500">
            ✓ Téléchargement gratuit. Aucun paiement requis.
            <br />✓ Respectez les droits d'utilisation : les documents sont fournis pour l'étude et la préparation.
            <br />✓ Seuls les documents vérifiés par l'administrateur sont présentés comme officiels.
          </p>
        </article>

        {isFavorite ? (
          <p className="text-sm text-nova-gold">★ Ce document est dans vos favoris.</p>
        ) : null}
      </div>
    </div>
  );
}
