import Link from "next/link";
import ExamFilters from "@/components/exam-filters";
import { ExamCard, type ExamItem } from "@/components/level-content";
import { getActiveLevels, getActiveSeries, getSubjectsForLevel, searchExams } from "@/lib/content";

export const dynamic = "force-dynamic";

export default async function ExamensPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const sp = await searchParams;
  const q = (sp.q as string) ?? "";
  const niveau = (sp.niveau as string) ?? "";
  const serie = (sp.serie as string) ?? "";
  const matiere = (sp.matiere as string) ?? "";
  const annee = (sp.annee as string) ?? "";
  const type = (sp.type as string) ?? "";
  const corrige = (sp.corrige as string) ?? "";

  const [levels, series, results] = await Promise.all([
    getActiveLevels(),
    getActiveSeries(),
    searchExams({
      level: niveau || null,
      serie: serie || null,
      subject: matiere || null,
      year: annee ? Number.parseInt(annee, 10) || null : null,
      examType: type || null,
      hasCorrection: corrige === "" ? null : corrige === "1",
      q: q || null,
    }),
  ]);

  const allSubjects = await getSubjectsForLevel(null);
  const exams: ExamItem[] = results.map((e) => ({
    id: e.id,
    title: e.title,
    description: e.description,
    year: e.year,
    examType: e.examType,
    hasCorrection: e.hasCorrection,
    filePath: e.filePath,
    isOfficial: e.isOfficial,
    subjectId: e.subjectId,
    subjectName: e.subjectName,
    levelName: e.levelName,
    createdAt: e.createdAt,
  }));

  const years = Array.from(new Set(results.map((e) => e.year).filter((y): y is number => !!y))).sort((a, b) => b - a);

  return (
    <div className="animate-fade-up section">
      <div className="nav-container space-y-6">
        <header>
          <p className="text-xs font-semibold uppercase tracking-[0.2em] gold-text">Bibliothèque</p>
          <h1 className="mt-2 text-3xl font-extrabold text-nova-navy sm:text-4xl">Examens précédents</h1>
          <p className="mt-2 max-w-2xl text-sm text-slate-600">
            Recherchez et téléchargez gratuitement les documents disponibles. Les corrigés sont fournis quand ils
           existent.
          </p>
        </header>

        <ExamFilters
          options={{
            levels,
            series,
            subjects: allSubjects,
            years,
            initial: { niveau, serie, matiere, annee, type, corrige, q },
          }}
        />

        <div className="flex items-center justify-between text-sm text-slate-500">
          <p>
            <span className="font-bold text-nova-navy">{exams.length}</span> document(s) trouvé(s)
          </p>
        </div>

        {exams.length === 0 ? (
          <div className="card p-8 text-center">
            <p className="text-3xl">📭</p>
            <p className="mt-3 font-bold text-nova-navy">Aucun document disponible pour ces critères</p>
            <p className="mt-1 text-sm text-slate-600">
              Aucun examen n'a été publié pour ce niveau, cette matière ou cette année. Essayez de modifier les filtres
              ou consultez la page d'accueil.
            </p>
            <Link href="/" className="btn btn-outline mt-4">Retour à l'accueil</Link>
          </div>
        ) : (
          <div className="grid-cards">
            {exams.map((e) => (
              <ExamCard key={e.id} exam={e} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
