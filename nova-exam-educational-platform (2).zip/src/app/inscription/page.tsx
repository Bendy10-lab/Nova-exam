import { redirect } from "next/navigation";
import { RegisterForm } from "@/components/auth-forms";
import { getSession } from "@/lib/auth";
import { getActiveLevels, getActiveSeries } from "@/lib/content";

export const dynamic = "force-dynamic";

export default async function InscriptionPage() {
  const session = await getSession();
  if (session) redirect("/espace");

  const levels = await getActiveLevels();
  const series = await getActiveSeries();

  return (
    <div className="section">
      <div className="nav-container grid gap-8 lg:grid-cols-[1fr_1.1fr]">
        <div className="hidden space-y-6 lg:block">
          <div className="gradient-navy rounded-2xl p-8 text-white">
            <h2 className="text-2xl font-extrabold">Rejoignez NOVA EXAM gratuitement</h2>
            <ul className="mt-5 space-y-3 text-sm text-white/80">
              <li className="flex gap-3"><span className="gold-text">✓</span> Accès gratuit aux examens précédents et aux corrigés</li>
              <li className="flex gap-3"><span className="gold-text">✓</span> Examens blancs avec correction automatique</li>
              <li className="flex gap-3"><span className="gold-text">✓</span> Suivi de votre progression par matière</li>
              <li className="flex gap-3"><span className="gold-text">✓</span> Espace personnel sécurisé</li>
              <li className="flex gap-3"><span className="gold-text">✓</span> Aucun paiement, jamais</li>
            </ul>
          </div>
        </div>
        <RegisterForm levels={levels} series={series} />
      </div>
    </div>
  );
}
