import type { Metadata, Viewport } from "next";
import SiteHeader from "@/components/site-header";
import SiteFooter from "@/components/site-footer";
import { getSession } from "@/lib/auth";
import { getSettings, publicSettings } from "@/lib/settings";
import "./globals.css";

export const metadata: Metadata = {
  title: {
    default: "NOVA EXAM — Prépare ton examen, construis ton avenir.",
    template: "%s | NOVA EXAM",
  },
  description:
    "NOVA EXAM est une plateforme éducative gratuite pour les élèves de 9ème année fondamentale et de NS4 en Haïti : examens précédents, exercices, corrigés et examens blancs.",
  keywords: [
    "NOVA EXAM",
    "9ème année fondamentale",
    "NS4",
    "examens haïti",
    "examens blancs",
    "corrigés gratuits",
    "Beneche Jurgens",
  ],
  authors: [{ name: "Beneche Jurgens" }],
  openGraph: {
    title: "NOVA EXAM",
    description: "Prépare ton examen, construis ton avenir.",
    type: "website",
    locale: "fr_FR",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#0b1a3b",
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const session = await getSession();
  const settings = publicSettings(await getSettings());

  return (
    <html lang="fr">
      <body className="flex min-h-screen flex-col bg-slate-50 font-sans text-nova-ink antialiased">
        <SiteHeader user={session?.user ?? null} whatsapp={settings.whatsapp} />
        <main className="flex-1">{children}</main>
        <SiteFooter />
      </body>
    </html>
  );
}
