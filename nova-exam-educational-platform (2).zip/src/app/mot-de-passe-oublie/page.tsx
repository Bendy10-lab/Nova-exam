import { ForgotForm } from "@/components/auth-forms";

export const dynamic = "force-dynamic";

export default function MotDePasseOubliePage() {
  return (
    <div className="section">
      <div className="nav-container mx-auto max-w-xl">
        <ForgotForm />
      </div>
    </div>
  );
}
