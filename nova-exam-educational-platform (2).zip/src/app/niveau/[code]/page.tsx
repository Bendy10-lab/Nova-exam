import Link from "next/link";
import { notFound } from "next/navigation";
import { ExamCard, InteractiveCard, LevelHeader, ResourceCard, SubjectGrid, type ExamItem, type InteractiveItem, type ResourceItem } from "@/components/level-content";
import {
  getActiveLevels,
  getPublishedInteractiveExams,
  getResources,
  getSubjectsForLevel,
  searchExams,
} from "@/lib/content";

export const dynamic = "force-dynamic";

export default async function NiveauPage({ params }: { params: Promise<{ code: string }> }) {
  const { code } = await params;
  const levels = await getActiveLevels();
  const level = levels.find((l) => l.code.toLowerCase() === code.toLowerCase());
  if (!level) notFound();

  const [subjects, exams, whitePapers, interactives, resources] = await Promise.all([
    getSubjectsForLevel(level.id),
    searchExams({ level: level.id, examType: "precedent" }),
    searchExams({ level: level.id, examType: "blanc" }),
    getPublishedInteractiveExams(level.id),
    getResources({ levelId: level.id }),
  ]);

  const examItems: ExamItem[] = exams.map((e) => ({
    id: e.id,
    title: e.title,
    description: e.description,
    year: e.year,
    examType: e.examType,
    hasCorrection: e.hasCorrection,
    filePath: e.filePath,
    isOfficial: e.isOfficial,
    subjectId: e.subjectId,
    subjectName: e.subjectName,
    levelName: e.levelName,
    createdAt: e.createdAt,
  }));

  const interactiveItems: InteractiveItem[] = interactives.map((e) => ({
    id: e.id,
    title: e.title,
    description: e.description,
    durationMinutes: e.durationMinutes,
    maxScore: e.maxScore,
    isWhitePaper: e.isWhitePaper,
    subjectName: e.subjectName,
  }));

  const resourceItems: ResourceItem[] = resources.map((r) => ({
    id: r.id,
    title: r.title,
    summary: r.summary,
    resourceType: r.resourceType,
    filePath: r.filePath,
    subjectName: r.subjectName,
    createdAt: r.createdAt,
  }));

  return (
    <div className="animate-fade-up">
      <LevelHeader levelCode={level.code} name={level.name} description={level.description} />

      <section className="section bg-white">
        <div className="nav-container space-y-6">
          <header className="flex flex-wrap items-end justify-between gap-3">
            <div>
              <h2 className="text-2xl font-extrabold text-nova-navy">Matières disponibles</h2>
              <p className="mt-1 text-sm text-slate-600">Toutes les ressources publiées sont accessibles gratuitement.</p>
            </div>
            <Link href="/examens?niveau=9em" className="btn btn-outline btn-sm">Bibliothèque d'examens →</Link>
          </header>
          <SubjectGrid subjects={subjects} exams={examItems} />
        </div>
      </section>

      <section className="section bg-slate-50">
        <div className="nav-container space-y-6">
          <h2 className="text-2xl font-extrabold text-nova-navy">Examens précédents</h2>
          {examItems.length === 0 ? (
            <div className="card p-8 text-center">
              <p className="text-3xl">📭</p>
              <p className="mt-3 font-bold text-nova-navy">Aucun document disponible pour ce niveau</p>
              <p className="mt-1 text-sm text-slate-600">L'administrateur peut importer des PDF depuis son téléphone.</p>
            </div>
          ) : (
            <div className="grid-cards">{examItems.map((e) => <ExamCard key={e.id} exam={e} />)}</div>
          )}
        </div>
      </section>

      <section className="section bg-white">
        <div className="nav-container space-y-6">
          <h2 className="text-2xl font-extrabold text-nova-navy">Examens blancs interactifs</h2>
          {interactiveItems.length === 0 ? (
            <div className="card p-8 text-center">
              <p className="text-3xl">✍️</p>
              <p className="mt-3 font-bold text-nova-navy">Aucun examen blanc publié</p>
              <p className="mt-1 text-sm text-slate-600">Suivez l'actualisation de la plateforme.</p>
            </div>
          ) : (
            <div className="grid-cards">{interactiveItems.map((e) => <InteractiveCard key={e.id} exam={e} />)}</div>
          )}
        </div>
      </section>

      <section className="section bg-slate-50">
        <div className="nav-container space-y-6">
          <h2 className="text-2xl font-extrabold text-nova-navy">Ressources pédagogiques</h2>
          {resourceItems.length === 0 ? (
            <p className="text-sm text-slate-500">Aucune ressource publiée pour ce niveau.</p>
          ) : (
            <div className="grid-cards">{resourceItems.map((r) => <ResourceCard key={r.id} resource={r} />)}</div>
          )}
          {whitePapers.length > 0 ? (
            <p className="text-xs text-slate-500">
              {whitePapers.length} document(s) « examen blanc » disponible(s) dans la bibliothèque.
            </p>
          ) : null}
        </div>
      </section>
    </div>
  );
}
