import Link from "next/link";
import clsx from "clsx";
import { Logo, LogoMark } from "@/components/brand";
import PromotionList from "@/components/promotion-card";
import {
  ExamCard,
  InteractiveCard,
  LevelHeader,
  ResourceCard,
  SubjectGrid,
  type ExamItem,
  type InteractiveItem,
  type ResourceItem,
  type SubjectItem,
} from "@/components/level-content";
import {
  getActiveLevels,
  getActiveSeries,
  getPublicPromotions,
  getPublishedAnnouncements,
  getRecentExams,
  getRecentInteractiveExams,
  getResources,
  getSubjectsForLevel,
  searchExams,
} from "@/lib/content";
import { getRealStats, getSettings, publicSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

const ADVANTAGES = [
  {
    icon: "🎓",
    title: "Contenu adapté au programme",
    text: "Matières organisées selon les programmes de 9ème fondamentale et de NS4 en Haïti.",
  },
  {
    icon: "📥",
    title: "Téléchargements gratuits",
    text: "Examens précédents et corrigés disponibles gratuitement, sans inscription payante.",
  },
  {
    icon: "⚡",
    title: "Examens blancs interactifs",
    text: "Chronomètre, navigation entre les questions et correction automatique de la note.",
  },
  {
    icon: "📊",
    title: "Suivi de progression",
    text: "Consultez vos résultats, vos matières fortes et vos points de faiblesse.",
  },
  {
    icon: "🔒",
    title: "Espace privé sécurisé",
    text: "Chaque élève consulte uniquement ses propres données et ses propres résultats.",
  },
  {
    icon: "📱",
    title: "Pensé pour le téléphone",
    text: "Interface rapide, simple et utilisable depuis un Android, une tablette ou un ordinateur.",
  },
];

export default async function HomePage() {
  const [settings, stats, levels, promotions, announcements, recentExams, recentInteractive, resources] =
    await Promise.all([
      getSettings(),
      getRealStats(),
      getActiveLevels(),
      getPublicPromotions("home"),
      getPublishedAnnouncements(3),
      getRecentExams(8),
      getRecentInteractiveExams(4),
      getResources({ limit: 6 }),
    ]);

  const pub = publicSettings(settings);
  const nine = levels.find((l) => l.code === "9em") ?? levels[0];
  const ns4 = levels.find((l) => l.code === "ns4") ?? levels[1];

  const [nineSubjects, ns4Subjects, nineExams, ns4Exams, nineSeries, ns4Series, ns4WhitePapers] =
    await Promise.all([
      getSubjectsForLevel(nine?.id ?? null),
      getSubjectsForLevel(ns4?.id ?? null),
      searchExams({ level: nine?.id ?? null, examType: "precedent", q: null }),
      searchExams({ level: ns4?.id ?? null, examType: "precedent", q: null }),
      getActiveSeries(nine?.id ?? null),
      getActiveSeries(ns4?.id ?? null),
      searchExams({ examType: "blanc" }),
    ]);

  const examItems: ExamItem[] = recentExams.map((e) => ({
    id: e.id,
    title: e.title,
    description: e.description,
    year: e.year,
    examType: e.examType,
    hasCorrection: e.hasCorrection,
    filePath: e.filePath,
    isOfficial: e.isOfficial,
    subjectId: e.subjectId,
    subjectName: e.subjectName,
    levelName: e.levelName,
    createdAt: e.createdAt,
  }));

  const interactiveItems: InteractiveItem[] = recentInteractive.map((e) => ({
    id: e.id,
    title: e.title,
    description: e.description,
    durationMinutes: e.durationMinutes,
    maxScore: e.maxScore,
    isWhitePaper: e.isWhitePaper,
    subjectName: e.subjectName,
  }));

  const resourceItems: ResourceItem[] = resources.map((r) => ({
    id: r.id,
    title: r.title,
    summary: r.summary,
    resourceType: r.resourceType,
    filePath: r.filePath,
    subjectName: r.subjectName,
    createdAt: r.createdAt,
  }));

  const subjectItems = (list: typeof nineSubjects): SubjectItem[] =>
    list.map((s) => ({
      id: s.id,
      code: s.code,
      name: s.name,
      description: s.description,
      icon: s.icon,
      color: s.color,
      position: s.position,
    }));

  return (
    <div className="animate-fade-up">
      {/* ------------------------------------------------------------- HERO */}
      <section className="relative overflow-hidden gradient-navy text-white">
        <div className="pointer-events-none absolute inset-0 opacity-20" aria-hidden>
          <div className="absolute -left-24 top-10 h-64 w-64 rounded-full bg-nova-gold/40 blur-3xl" />
          <div className="absolute right-0 top-40 h-72 w-72 rounded-full bg-nova-blue-light/60 blur-3xl" />
        </div>
        <div className="nav-container relative grid gap-10 py-14 lg:grid-cols-2 lg:py-20">
          <div className="space-y-6">
            <Logo light />
            <div>
              <p className="text-sm font-semibold uppercase tracking-[0.25em] text-nova-gold-light">
                Plateforme éducative gratuite · Haïti
              </p>
              <h1 className="mt-3 text-3xl font-extrabold leading-tight sm:text-4xl lg:text-[2.9rem]">
                Prépare ton examen,
                <br />
                construis ton <span className="gold-text">avenir.</span>
              </h1>
              <p className="mt-4 max-w-xl text-sm text-white/75 sm:text-base">{pub.description}</p>
            </div>
            <div className="flex flex-wrap gap-3">
              <Link href="/inscription" className="btn btn-gold">
                🚀 Commencer gratuitement
              </Link>
              <Link href="/inscription" className="btn btn-outline btn-sm">
                Créer un compte
              </Link>
              <Link href="/connexion" className="btn btn-ghost btn-sm text-white hover:bg-white/10">
                Se connecter
              </Link>
            </div>
            <p className="text-xs text-white/55">
              Inscription gratuite · Aucun paiement requis · Aucun frais d'inscription
            </p>
          </div>

          <div className="space-y-4">
            <div className="card grid grid-cols-3 gap-3 p-5 text-center">
              <Stat value={stats.matieres} label="matières" />
              <Stat value={stats.examens} label="examens" />
              <Stat value={stats.examensBlancs} label="examens blancs" />
              <Stat value={stats.ressources} label="ressources" />
              <Stat value={stats.eleves} label="élèves inscrits" />
              <Stat value={stats.tentatives} label="tentatives" />
            </div>
            {announcements.length > 0 ? (
              <div className="card border-nova-gold/40 bg-white/95 p-5">
                <h3 className="flex items-center gap-2 font-bold text-nova-navy">
                  📢 <span>Du nouveau sur la plateforme</span>
                </h3>
                <ul className="mt-3 space-y-3">
                  {announcements.slice(0, 2).map((a) => (
                    <li key={a.id} className="border-l-2 border-nova-gold pl-3 text-sm text-slate-600">
                      <p className="font-semibold text-nova-navy">{a.title}</p>
                      <p className="line-clamp-2">{a.content}</p>
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}
          </div>
        </div>
      </section>

      {/* ------------------------------------------------------- 9EME SECTION */}
      {nine ? (
        <section className="section bg-white">
          <div className="nav-container space-y-8">
            <LevelHeader levelCode="9em" name="9ème année fondamentale" description={nine.description} />
            <SubjectGrid subjects={subjectItems(nineSubjects)} exams={nineExams} />
            <div className="flex flex-wrap gap-3">
              <Link href="/niveau/9em" className="btn btn-navy">
                Ouvrir l'espace 9ème →
              </Link>
              <Link href="/examens?niveau=9em" className="btn btn-outline">
                Examens précédents
              </Link>
            </div>
          </div>
        </section>
      ) : null}

      {/* --------------------------------------------------------- NS4 SECTION */}
      {ns4 ? (
        <section className="section bg-slate-50">
          <div className="nav-container space-y-8">
            <LevelHeader
              accent="gold"
              levelCode="ns4"
              name="NS4 — première année du cycle supérieur"
              description={ns4.description}
            />
            {ns4Series.length > 0 ? (
              <div className="flex flex-wrap gap-2">
                {ns4Series.map((s) => (
                  <span key={s.id} className="badge badge-navy">
                    {s.name}
                  </span>
                ))}
              </div>
            ) : null}
            <SubjectGrid subjects={subjectItems(ns4Subjects)} exams={ns4Exams} />
            <div className="flex flex-wrap gap-3">
              <Link href="/niveau/ns4" className="btn btn-navy">
                Ouvrir l'espace NS4 →
              </Link>
              <Link href="/examens?niveau=ns4" className="btn btn-outline">
                Examens précédents
              </Link>
            </div>
          </div>
        </section>
      ) : null}

      {/* ------------------------------------------------------------ ADVANTAGES */}
      <section className="section bg-white">
        <div className="nav-container space-y-8">
          <header className="text-center">
            <p className="text-xs font-semibold uppercase tracking-[0.2em] gold-text">Pourquoi NOVA EXAM</p>
            <h2 className="mt-2 text-2xl font-extrabold text-nova-navy sm:text-3xl">
              Ce que vous gagnez avec NOVA EXAM
            </h2>
            <p className="mx-auto mt-3 max-w-2xl text-sm text-slate-600">
              Une plateforme simple, rapide et entièrement gratuite, pensée pour les élèves haïtiens.
            </p>
          </header>
          <div className="grid-cards">
            {ADVANTAGES.map((a) => (
              <div key={a.title} className="card p-5">
                <div className="text-3xl">{a.icon}</div>
                <h3 className="mt-3 font-bold text-nova-navy">{a.title}</h3>
                <p className="mt-2 text-sm text-slate-600">{a.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ------------------------------------------------------ EXAMENS PRÉCÉDENTS */}
      <section className="section bg-slate-50">
        <div className="nav-container space-y-8">
          <header className="flex flex-wrap items-end justify-between gap-3">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.2em] gold-text">Bibliothèque</p>
              <h2 className="mt-2 text-2xl font-extrabold text-nova-navy sm:text-3xl">Examens précédents</h2>
              <p className="mt-2 max-w-2xl text-sm text-slate-600">
                Recherchez par niveau, matière, année et corrigé. Tout est téléchargeable gratuitement.
              </p>
            </div>
            <Link href="/examens" className="btn btn-outline">
              Tout voir →
            </Link>
          </header>
          {examItems.length === 0 ? (
            <EmptyState title="Aucun document disponible pour le moment" text="L'administrateur publiera bientôt les premiers examens." />
          ) : (
            <div className="grid-cards">{examItems.map((e) => <ExamCard key={e.id} exam={e} />)}</div>
          )}
        </div>
      </section>

      {/* ---------------------------------------------------- EXAMENS BLANCS */}
      <section className="section bg-white">
        <div className="nav-container space-y-8">
          <header className="flex flex-wrap items-end justify-between gap-3">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.2em] gold-text">Entraînement</p>
              <h2 className="mt-2 text-2xl font-extrabold text-nova-navy sm:text-3xl">Examens blancs gratuits</h2>
              <p className="mt-2 max-w-2xl text-sm text-slate-600">
                Passez un examen en ligne, obtenez votre note, vos réponses et vos explications. Entraînement seulement —
                pas de résultat officiel.
              </p>
            </div>
            <Link href="/examens-blancs" className="btn btn-outline">
              Tout voir →
            </Link>
          </header>
          {interactiveItems.length === 0 ? (
            <EmptyState title="Aucun examen blanc publié" text="L'administrateur peut créer des examens blancs depuis le panneau d'administration." />
          ) : (
            <div className="grid-cards">{interactiveItems.map((e) => <InteractiveCard key={e.id} exam={e} />)}</div>
          )}
          {ns4WhitePapers.length === 0 && interactiveItems.length === 0 ? null : (
            <p className="text-center text-xs text-slate-500">
              ⚠️ Les examens blancs sont des entraînements et ne constituent pas des résultats officiels.
            </p>
          )}
        </div>
      </section>

      {/* ------------------------------------------------------- RESSOURCES */}
      <section className="section bg-slate-50">
        <div className="nav-container space-y-8">
          <header className="flex flex-wrap items-end justify-between gap-3">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.2em] gold-text">Gratuit</p>
              <h2 className="mt-2 text-2xl font-extrabold text-nova-navy sm:text-3xl">Fiches, résumés et corrigés</h2>
            </div>
            <Link href="/ressources" className="btn btn-outline">
              Tout voir →
            </Link>
          </header>
          {resourceItems.length === 0 ? (
            <EmptyState title="Aucune ressource publiée" text="Les ressources apparaîtront ici dès leur publication." />
          ) : (
            <div className="grid-cards">{resourceItems.map((r) => <ResourceCard key={r.id} resource={r} />)}</div>
          )}
        </div>
      </section>

      {/* ------------------------------------------------------------- FONDATEUR */}
      <section className="section bg-white">
        <div className="nav-container grid gap-10 lg:grid-cols-[0.9fr_1.1fr]">
          <div className="flex justify-center">
            <div className="flex h-64 w-64 items-center justify-center rounded-3xl gradient-navy shadow-xl animate-pulse-soft sm:h-72 sm:w-72">
              <LogoMark className="h-24 w-24" />
            </div>
          </div>
          <div className="space-y-5">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.2em] gold-text">Le fondateur</p>
              <h2 className="mt-2 text-2xl font-extrabold text-nova-navy sm:text-3xl">{pub.founderName}</h2>
              <p className="text-lg font-semibold text-slate-700">{pub.founderTitle}</p>
            </div>
            <p className="text-sm leading-relaxed text-slate-600">{pub.founderBio}</p>
            <div className="card border-nova-gold/30 bg-nova-gold/5 p-5">
              <h3 className="flex items-center gap-2 font-bold text-nova-navy">🎯 Mission éducative</h3>
              <p className="mt-2 text-sm text-slate-600">{pub.founderMission}</p>
            </div>
            <Link href="/a-propos" className="btn btn-outline">
              En savoir plus sur le projet →
            </Link>
          </div>
        </div>
      </section>

      {/* ------------------------------------------------------- PROMOTIONS */}
      {promotions.length > 0 ? (
        <section className="section bg-slate-50">
          <div className="nav-container space-y-8">
            <header className="text-center">
              <p className="text-xs font-semibold uppercase tracking-[0.2em] gold-text">Partage de projets</p>
              <h2 className="mt-2 text-2xl font-extrabold text-nova-navy sm:text-3xl">
                Découvrez aussi nos autres plateformes
              </h2>
              <p className="mx-auto mt-3 max-w-2xl text-sm text-slate-600">
                NOVA EXAM présente d'autres projets numériques utiles. Le contenu éducatif reste gratuit.
              </p>
            </header>
            <PromotionList promos={promotions} />
            <div className="text-center">
              <Link href="/plateformes" className="btn btn-outline">
                Voir toutes les plateformes →
              </Link>
            </div>
          </div>
        </section>
      ) : null}

      {/* ---------------------------------------------------------------- CTA */}
      <section className="section bg-white">
        <div className="nav-container">
          <div className="card overflow-hidden gradient-navy p-8 text-center text-white sm:p-12">
            <h2 className="text-2xl font-extrabold sm:text-3xl">
              Commencez votre révision <span className="gold-text">déjà aujourd'hui</span>
            </h2>
            <p className="mx-auto mt-3 max-w-xl text-sm text-white/75">
              Créez votre compte gratuitement en quelques secondes et conservez l'accès à vos examens, vos résultats et
              votre progression.
            </p>
            <div className="mt-6 flex flex-wrap justify-center gap-3">
              <Link href="/inscription" className="btn btn-gold">
                Créer mon compte gratuit
              </Link>
              <Link href="/connexion" className="btn btn-outline btn-sm">
                Se connecter
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

function Stat({ value, label }: { value: number; label: string }) {
  return (
    <div>
      <div className="text-2xl font-extrabold text-nova-navy sm:text-3xl">{value}</div>
      <div className="text-[0.7rem] uppercase tracking-wide text-slate-500">{label}</div>
    </div>
  );
}

function EmptyState({ title, text }: { title: string; text: string }) {
  return (
    <div className="card p-8 text-center">
      <p className="text-3xl">📭</p>
      <p className="mt-3 font-bold text-nova-navy">{title}</p>
      <p className="mt-1 text-sm text-slate-600">{text}</p>
    </div>
  );
}
