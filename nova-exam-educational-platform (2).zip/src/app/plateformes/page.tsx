import Link from "next/link";
import PromotionList from "@/components/promotion-card";
import { getPublicPromotions } from "@/lib/content";
import { getSettings, publicSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

export default async function PlateformesPage() {
  const promos = await getPublicPromotions("home");
  const settings = publicSettings(await getSettings());

  return (
    <div className="animate-fade-up section">
      <div className="nav-container space-y-8">
        <header className="text-center">
          <p className="text-xs font-semibold uppercase tracking-[0.2em] gold-text">Nos plateformes</p>
          <h1 className="mt-2 text-3xl font-extrabold text-nova-navy sm:text-4xl">
            Découvrez aussi nos autres plateformes
          </h1>
          <p className="mx-auto mt-3 max-w-2xl text-sm text-slate-600">
            NOVA EXAM partage d'autres projets numériques utiles. Le contenu éducatif de NOVA EXAM reste gratuit.
          </p>
        </header>

        {promos.length === 0 ? (
          <div className="card p-8 text-center">
            <p className="text-3xl">🔗</p>
            <p className="mt-3 font-bold text-nova-navy">Aucune promotion publiée pour le moment</p>
            <p className="mt-1 text-sm text-slate-600">
              L'administrateur peut ajouter des plateformes depuis le panneau d'administration —
              <Link href="/" className="ml-1 font-semibold text-nova-blue underline">retour à l'accueil</Link>.
            </p>
          </div>
        ) : (
          <PromotionList promos={promos} />
        )}

        <div className="card p-6 text-center">
          <h2 className="text-lg font-bold text-nova-navy">Une plateforme à proposer ?</h2>
          <p className="mx-auto mt-2 max-w-xl text-sm text-slate-600">
            Contactez {settings.founderName} via le formulaire de contact pour demander l'ajout de votre projet.
          </p>
          <Link href="/contact" className="btn btn-outline mt-4">Contacter</Link>
        </div>
      </div>
    </div>
  );
}
