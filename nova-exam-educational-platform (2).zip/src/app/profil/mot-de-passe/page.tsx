import Link from "next/link";
import { redirect } from "next/navigation";
import { PasswordForm } from "@/components/profile-forms";
import { getSession } from "@/lib/auth";

export const dynamic = "force-dynamic";

export default async function MotDePassePage() {
  const session = await getSession();
  if (!session) redirect("/connexion?next=/profil/mot-de-passe");

  return (
    <div className="section">
      <div className="nav-container max-w-2xl space-y-6">
        <nav className="text-sm text-slate-500">
          <Link href="/espace" className="font-semibold text-nova-blue underline">Espace élève</Link>
          <span className="mx-2">/</span> Profil
          <span className="mx-2">/</span> Mot de passe
        </nav>
        <PasswordForm />
        <div className="text-center">
          <Link href="/profil" className="btn btn-outline">← Retour au profil</Link>
        </div>
      </div>
    </div>
  );
}
