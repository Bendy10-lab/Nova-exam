import Link from "next/link";
import { redirect } from "next/navigation";
import { ProfileForm } from "@/components/profile-forms";
import { getActiveLevels, getActiveSeries } from "@/lib/content";
import { getSession } from "@/lib/auth";

export const dynamic = "force-dynamic";

export default async function ProfilPage() {
  const session = await getSession();
  if (!session) redirect("/connexion?next=/profil");

  const [levels, series] = await Promise.all([getActiveLevels(), getActiveSeries()]);

  return (
    <div className="section">
      <div className="nav-container max-w-3xl space-y-6">
        <nav className="text-sm text-slate-500">
          <Link href="/espace" className="font-semibold text-nova-blue underline">Espace élève</Link>
          <span className="mx-2">/</span> Profil
        </nav>
        <ProfileForm
          user={{
            id: session.user.id,
            nom: session.user.nom,
            email: session.user.email,
            niveau: session.user.niveau,
            serie: session.user.serie,
            createdAt: session.user.createdAt,
          }}
          levels={levels}
          series={series}
        />
        <div className="flex flex-wrap items-center justify-between gap-3">
          <Link href="/profil/mot-de-passe" className="btn btn-outline">Changer le mot de passe →</Link>
          <Link href="/espace" className="btn btn-ghost">← Retour à mon espace</Link>
        </div>
      </div>
    </div>
  );
}
