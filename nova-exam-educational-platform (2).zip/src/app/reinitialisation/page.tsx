import { ResetForm } from "@/components/auth-forms";

export const dynamic = "force-dynamic";

export default function ReinitialisationPage() {
  return (
    <div className="section">
      <div className="nav-container mx-auto max-w-xl">
        <ResetForm />
      </div>
    </div>
  );
}
