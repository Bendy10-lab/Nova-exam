import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/db";
import { resources, subjects } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

const LABEL: Record<string, string> = {
  fiche: "Fiche de révision",
  resume: "Résumé",
  correction: "Correction",
  pdf: "Document PDF",
};

export default async function ResourceDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [resource] = await db
    .select({
      id: resources.id,
      title: resources.title,
      summary: resources.summary,
      content: resources.content,
      resourceType: resources.resourceType,
      filePath: resources.filePath,
      subjectName: subjects.name,
      published: resources.published,
    })
    .from(resources)
    .leftJoin(subjects, eq(resources.subjectId, subjects.id))
    .where(eq(resources.id, id))
    .limit(1);

  if (!resource || !resource.published) notFound();

  return (
    <div className="animate-fade-up section">
      <div className="nav-container max-w-4xl space-y-6">
        <Link href="/ressources" className="text-sm font-semibold text-nova-blue underline">← Retour aux ressources</Link>
        <article className="card space-y-5 p-6 sm:p-8">
          <div className="flex flex-wrap items-center gap-2">
            <span className="badge badge-navy">{LABEL[resource.resourceType] ?? resource.resourceType}</span>
            {resource.subjectName ? <span className="badge badge-gray">{resource.subjectName}</span> : null}
          </div>
          <h1 className="text-2xl font-extrabold text-nova-navy sm:text-3xl">{resource.title}</h1>
          {resource.summary ? <p className="text-sm leading-relaxed text-slate-600">{resource.summary}</p> : null}

          {resource.content ? (
            <div className="prose-nova">
              {resource.content.split("\n").map((line, i) =>
                line.trim() === "" ? (
                  <br key={i} />
                ) : (
                  <p key={i} className="text-sm leading-relaxed text-slate-700">
                    {line}
                  </p>
                ),
              )}
            </div>
          ) : null}

          {resource.filePath ? (
            <a href={resource.filePath} download className="btn btn-gold">Télécharger le document ⬇</a>
          ) : null}

          <p className="text-xs text-slate-500">
            ✓ Contenu gratuit. ✓ Aucun paiement requis. ✓ Accessible sur téléphone, tablette et ordinateur.
          </p>
        </article>
      </div>
    </div>
  );
}
