import Link from "next/link";
import { ResourceCard, type ResourceItem } from "@/components/level-content";
import { getActiveLevels, getResources } from "@/lib/content";

export const dynamic = "force-dynamic";

export default async function RessourcesPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const sp = await searchParams;
  const matiere = (sp.matiere as string) ?? "";
  const niveau = (sp.niveau as string) ?? "";
  const type = (sp.type as string) ?? "";
  const q = (sp.q as string) ?? "";

  const levels = await getActiveLevels();
  const results = await getResources({ subjectId: matiere || null, levelId: niveau || null, type: type || null, q: q || null });

  const items: ResourceItem[] = results.map((r) => ({
    id: r.id,
    title: r.title,
    summary: r.summary,
    resourceType: r.resourceType,
    filePath: r.filePath,
    subjectName: r.subjectName,
    createdAt: r.createdAt,
  }));

  const TYPES: Record<string, string> = {
    fiche: "Fiches de révision",
    resume: "Résumés",
    correction: "Corrigés",
    pdf: "Documents PDF",
  };

  return (
    <div className="animate-fade-up section">
      <div className="nav-container space-y-6">
        <header>
          <p className="text-xs font-semibold uppercase tracking-[0.2em] gold-text">Gratuit</p>
          <h1 className="mt-2 text-3xl font-extrabold text-nova-navy sm:text-4xl">Ressources pédagogiques</h1>
          <p className="mt-2 max-w-2xl text-sm text-slate-600">
            Fiches de révision, résumés, corrigés et documents PDF. Tout est gratuit et consultabile sur tous vos appareils.
          </p>
        </header>

        <div className="grid gap-3 sm:grid-cols-4">
          <Link href="/ressources" className={`card p-4 text-sm font-semibold ${!type ? "border-nova-gold" : ""}`}>
            Toutes ({results.length})
          </Link>
          {Object.entries(TYPES).map(([key, label]) => (
            <Link key={key} href={`/ressources?type=${key}${niveau ? `&niveau=${niveau}` : ""}`} className={`card p-4 text-sm font-semibold ${type === key ? "border-nova-gold" : ""}`}>
              {label}
            </Link>
          ))}
        </div>

        <div className="flex flex-wrap gap-2 text-sm">
          <span className="text-slate-500">Niveau :</span>
          <Link href="/ressources" className="badge badge-gray">Tous</Link>
          {levels.map((l) => (
            <Link key={l.id} href={`/ressources?niveau=${l.id}`} className={`badge ${niveau === l.id ? "badge-gold" : "badge-navy"}`}>
              {l.name}
            </Link>
          ))}
        </div>

        {q ? <p className="text-sm text-slate-500">Recherche : « {q} »</p> : null}

        {items.length === 0 ? (
          <div className="card p-8 text-center">
            <p className="text-3xl">📭</p>
            <p className="mt-3 font-bold text-nova-navy">Aucune ressource disponible</p>
            <p className="mt-1 text-sm text-slate-600">Aucun contenu publié pour ces critères. Revenez plus tard ou modifiez vos filtres.</p>
          </div>
        ) : (
          <div className="grid-cards">
            {items.map((r) => (
              <ResourceCard key={r.id} resource={r} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
