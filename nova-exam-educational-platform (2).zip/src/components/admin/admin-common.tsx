"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

type AdminSubmitResult = {
  submit: (form: FormData | HTMLFormElement) => Promise<void>;
  busy: boolean;
  error: string;
  message: string;
  clear: () => void;
};

export function useAdminSubmit(action: string, onDone?: () => void): AdminSubmitResult {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  async function submit(form: FormData | HTMLFormElement) {
    let fd: FormData;
    if (form instanceof HTMLFormElement) {
      fd = new FormData(form);
    } else {
      fd = new FormData();
      for (const [key, value] of form.entries()) fd.append(key, value);
    }
    fd.set("action", action);
    setBusy(true);
    setError("");
    setMessage("");
    try {
      const res = await fetch("/api/admin", { method: "POST", body: fd });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        setError(data.error ?? "Une erreur est survenue.");
        return;
      }
      setMessage(data.message ?? "Action effectuée.");
      router.refresh();
      onDone?.();
    } catch {
      setError("Vérifiez votre connexion et réessayez.");
    } finally {
      setBusy(false);
    }
  }

  return { submit, busy, error, message, clear: () => { setError(""); setMessage(""); } };
}

export function useAdminAction() {
  const router = useRouter();
  const [busyId, setBusyId] = useState("");
  const [error, setError] = useState("");

  async function run(action: string, payload: Record<string, unknown>, id = "") {
    setBusyId(id);
    setError("");
    const res = await fetch("/api/admin", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action, ...payload }),
    });
    const data = await res.json();
    setBusyId("");
    if (!res.ok || !data.ok) {
      setError(data.error ?? "Erreur.");
      return;
    }
    router.refresh();
  }

  return { run, busyId, error };
}

export function AdminFeedback({ error, message }: { error: string; message: string }) {
  if (!error && !message) return null;
  return (
    <div className="space-y-1">
      {error ? <p className="text-sm font-medium text-red-600">⚠️ {error}</p> : null}
      {message ? <p className="text-sm font-medium text-green-600">✓ {message}</p> : null}
    </div>
  );
}

export function AdminDeleteButton({
  onConfirm,
  children = "Supprimer",
  className = "btn btn-outline btn-sm",
  confirmText = "Supprimer définitivement ?",
}: {
  onConfirm: () => Promise<void> | void;
  children?: React.ReactNode;
  className?: string;
  confirmText?: string;
}) {
  return (
    <button
      type="button"
      onClick={() => {
        if (window.confirm(confirmText)) void onConfirm();
      }}
      className={className}
    >
      {children}
    </button>
  );
}

export function AdminSection({
  title,
  description,
  children,
  actions,
}: {
  title: string;
  description?: string;
  children: React.ReactNode;
  actions?: React.ReactNode;
}) {
  return (
    <section className="card space-y-5 p-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-nova-navy">{title}</h2>
          {description ? <p className="text-sm text-slate-600">{description}</p> : null}
        </div>
        {actions}
      </div>
      {children}
    </section>
  );
}
