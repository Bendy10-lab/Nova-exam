"use client";

import { useState } from "react";
import { AdminFeedback, useAdminAction, useAdminSubmit } from "@/components/admin/admin-common";

// ---------------------------------------------------------------------------
// Niveaux
// ---------------------------------------------------------------------------

export function LevelForm({ levels }: { levels: { id: string; name: string; code: string; position: number; isActive: boolean }[] }) {
  const { submit, busy, error, message } = useAdminSubmit("createLevel");
  const action = useAdminAction();
  const [selected, setSelected] = useState(levels[0]?.id ?? "");
  const editing = levels.find((l) => l.id === selected);

  return (
    <div className="space-y-5">
      <form action={submit} className="space-y-3">
        <div className="grid gap-3 sm:grid-cols-4">
          <label className="field">
            <span className="label">Code *</span>
            <input className="input" name="code" placeholder="ex. : 9em" required />
          </label>
          <label className="field sm:col-span-2">
            <span className="label">Nom *</span>
            <input className="input" name="name" placeholder="9ème année fondamentale" required />
          </label>
          <label className="field">
            <span className="label">Position</span>
            <input className="input" name="position" type="number" defaultValue={1} />
          </label>
        </div>
        <label className="field">
          <span className="label">Description</span>
          <textarea className="textarea" name="description" />
        </label>
        <AdminFeedback error={error} message={message} />
        <button type="submit" disabled={busy} className="btn btn-navy btn-sm">{busy ? "Enregistrement…" : "Ajouter un niveau"}</button>
      </form>

      {levels.length === 0 ? (
        <p className="text-sm text-slate-500">Aucun niveau existant.</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-slate-500">
                <th className="py-2 pr-3">Nom</th>
                <th className="py-2 pr-3">Code</th>
                <th className="py-2 pr-3">Position</th>
                <th className="py-2 pr-3">Actif</th>
                <th className="py-2">Actions</th>
              </tr>
            </thead>
            <tbody>
              {levels.map((l) => (
                <tr key={l.id} className="border-t border-slate-100">
                  <td className="py-2 pr-3 font-semibold text-nova-navy">{l.name}</td>
                  <td className="py-2 pr-3 text-slate-600">{l.code}</td>
                  <td className="py-2 pr-3 text-slate-600">{l.position}</td>
                  <td className="py-2 pr-3">
                    <span className={`badge ${l.isActive ? "badge-green" : "badge-red"}`}>{l.isActive ? "Actif" : "Inactif"}</span>
                  </td>
                  <td className="py-2">
                    <input type="hidden" name="id" value={l.id} />
                    <button
                      type="button"
                      className="btn btn-outline btn-sm"
                      onClick={() => setSelected(l.id)}
                    >
                      Modifier
                    </button>
                    <button
                      type="button"
                      className="btn btn-outline btn-sm ml-2"
                      disabled={action.busyId === l.id}
                      onClick={() => action.run("deleteLevel", { id: l.id }, l.id)}
                    >
                      Supprimer
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {selected ? (
            <form action={submit} className="mt-4 space-y-3 rounded-xl bg-slate-50 p-4">
              <p className="font-semibold text-nova-navy">Modification : {editing?.name}</p>
              <div className="grid gap-3 sm:grid-cols-4">
                <input type="hidden" name="id" value={selected} />
                <label className="field">
                  <span className="label">Code</span>
                  <input className="input" name="code" defaultValue={editing?.code} />
                </label>
                <label className="field sm:col-span-2">
                  <span className="label">Nom</span>
                  <input className="input" name="name" defaultValue={editing?.name} />
                </label>
                <label className="field">
                  <span className="label">Position</span>
                  <input className="input" name="position" type="number" defaultValue={editing?.position} />
                </label>
              </div>
              <label className="field">
                <span className="label">Description</span>
                <textarea className="textarea" name="description" defaultValue={""} />
              </label>
              <label className="flex items-center gap-2 text-sm">
                <input type="checkbox" name="isActive" value="1" defaultChecked={editing?.isActive} className="h-4 w-4 accent-nova-navy" />
                Niveau actif
              </label>
              <button type="submit" className="action-update btn btn-navy btn-sm">Enregistrer les modifications</button>
            </form>
          ) : null}
        </div>
      )}
      <style>{`.action-update{background:#14295c !important}`}</style>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Séries
// ---------------------------------------------------------------------------

export function SeriesForm({
  levels,
  series,
}: {
  levels: { id: string; code: string; name: string }[];
  series: { id: string; code: string; name: string; position: number; levelId: string | null; isActive: boolean }[];
}) {
  const { submit, busy, error, message } = useAdminSubmit("createSeries");
  const action = useAdminAction();
  const [selected, setSelected] = useState(series[0]?.id ?? "");
  const editing = series.find((s) => s.id === selected);

  return (
    <div className="space-y-5">
      <form action={submit} className="space-y-3">
        <div className="grid gap-3 sm:grid-cols-4">
          <label className="field">
            <span className="label">Code *</span>
            <input className="input" name="code" placeholder="ex. : sciences" required />
          </label>
          <label className="field sm:col-span-2">
            <span className="label">Nom *</span>
            <input className="input" name="name" placeholder="Sciences" required />
          </label>
          <label className="field">
            <span className="label">Position</span>
            <input className="input" name="position" type="number" defaultValue={1} />
          </label>
        </div>
        <label className="field">
          <span className="label">Niveau</span>
          <select className="select" name="levelId">
            <option value="">— Non associé —</option>
            {levels.map((l) => (
              <option key={l.id} value={l.id}>{l.name}</option>
            ))}
          </select>
        </label>
        <AdminFeedback error={error} message={message} />
        <button type="submit" disabled={busy} className="btn btn-navy btn-sm">{busy ? "Enregistrement…" : "Ajouter une série"}</button>
      </form>

      {series.length === 0 ? (
        <p className="text-sm text-slate-500">Aucune série.</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-slate-500">
                <th className="py-2 pr-3">Nom</th>
                <th className="py-2 pr-3">Code</th>
                <th className="py-2 pr-3">Niveau</th>
                <th className="py-2">Actions</th>
              </tr>
            </thead>
            <tbody>
              {series.map((s) => (
                <tr key={s.id} className="border-t border-slate-100">
                  <td className="py-2 pr-3 font-semibold text-nova-navy">{s.name}</td>
                  <td className="py-2 pr-3 text-slate-600">{s.code}</td>
                  <td className="py-2 pr-3 text-slate-600">{levels.find((l) => l.id === s.levelId)?.name ?? "—"}</td>
                  <td className="py-2">
                    <button type="button" className="btn btn-outline btn-sm" onClick={() => setSelected(s.id)}>Modifier</button>
                    <button
                      type="button"
                      className="btn btn-outline btn-sm ml-2"
                      disabled={action.busyId === s.id}
                      onClick={() => action.run("deleteSeries", { id: s.id }, s.id)}
                    >
                      Supprimer
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {selected && editing ? (
            <form action={submit} className="mt-4 space-y-3 rounded-xl bg-slate-50 p-4">
              <p className="font-semibold text-nova-navy">Modification : {editing.name}</p>
              <div className="grid gap-3 sm:grid-cols-4">
                <input type="hidden" name="id" value={selected} />
                <label className="field">
                  <span className="label">Code</span>
                  <input className="input" name="code" defaultValue={editing.code} />
                </label>
                <label className="field sm:col-span-2">
                  <span className="label">Nom</span>
                  <input className="input" name="name" defaultValue={editing.name} />
                </label>
                <label className="field">
                  <span className="label">Position</span>
                  <input className="input" name="position" type="number" defaultValue={editing.position} />
                </label>
              </div>
              <label className="field">
                <span className="label">Niveau</span>
                <select className="select" name="levelId" defaultValue={editing.levelId ?? ""}>
                  <option value="">— Non associé —</option>
                  {levels.map((l) => (
                    <option key={l.id} value={l.id}>{l.name}</option>
                  ))}
                </select>
              </label>
              <label className="flex items-center gap-2 text-sm">
                <input type="checkbox" name="isActive" value="1" defaultChecked={editing.isActive} className="h-4 w-4 accent-nova-navy" />
                Série active
              </label>
              <button type="submit" className="btn btn-navy btn-sm">Enregistrer</button>
            </form>
          ) : null}
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Matières
// ---------------------------------------------------------------------------

export function SubjectForm({
  levels,
  subjects,
}: {
  levels: { id: string; code: string; name: string }[];
  subjects: {
    id: string;
    code: string;
    name: string;
    description: string | null;
    color: string;
    icon: string | null;
    position: number;
    levelId: string | null;
    isActive: boolean;
  }[];
}) {
  const { submit, busy, error, message } = useAdminSubmit("createSubject");
  const action = useAdminAction();
  const [selected, setSelected] = useState(subjects[0]?.id ?? "");
  const editing = subjects.find((s) => s.id === selected);

  return (
    <div className="space-y-5">
      <form action={submit} className="space-y-3">
        <div className="grid gap-3 sm:grid-cols-2">
          <label className="field">
            <span className="label">Code *</span>
            <input className="input" name="code" placeholder="ex. : math" required />
          </label>
          <label className="field">
            <span className="label">Nom *</span>
            <input className="input" name="name" placeholder="Mathématiques" required />
          </label>
          <label className="field">
            <span className="label">Icone (emoji)</span>
            <input className="input" name="icon" placeholder="🔢" />
          </label>
          <label className="field">
            <span className="label">Couleur</span>
            <input className="input" name="color" placeholder="#1e3a8a" defaultValue="#1e3a8a" />
          </label>
          <label className="field">
            <span className="label">Niveau</span>
            <select className="select" name="levelId">
              <option value="">— Tous les niveaux —</option>
              {levels.map((l) => (
                <option key={l.id} value={l.id}>{l.name}</option>
              ))}
            </select>
          </label>
          <label className="field">
            <span className="label">Position</span>
            <input className="input" name="position" type="number" defaultValue={1} />
          </label>
        </div>
        <label className="field">
          <span className="label">Description</span>
          <textarea className="textarea" name="description" />
        </label>
        <AdminFeedback error={error} message={message} />
        <button type="submit" disabled={busy} className="btn btn-navy btn-sm">{busy ? "Enregistrement…" : "Ajouter une matière"}</button>
      </form>

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-slate-500">
              <th className="py-2 pr-3">Matière</th>
              <th className="py-2 pr-3">Code</th>
              <th className="py-2 pr-3">Niveau</th>
              <th className="py-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {subjects.map((s) => (
              <tr key={s.id} className="border-t border-slate-100">
                <td className="py-2 pr-3 font-semibold text-nova-navy">
                  {s.icon} {s.name}
                </td>
                <td className="py-2 pr-3 text-slate-600">{s.code}</td>
                <td className="py-2 pr-3 text-slate-600">{levels.find((l) => l.id === s.levelId)?.name ?? "Tous"}</td>
                <td className="py-2">
                  <button type="button" className="btn btn-outline btn-sm" onClick={() => setSelected(s.id)}>Modifier</button>
                  <button
                    type="button"
                    className="btn btn-outline btn-sm ml-2"
                    disabled={action.busyId === s.id}
                    onClick={() => action.run("deleteSubject", { id: s.id }, s.id)}
                  >
                    Supprimer
                  </button>
                </td>
              </tr>
            ))}
            {subjects.length === 0 ? (
              <tr><td colSpan={4} className="py-3 text-slate-500">Aucune matière.</td></tr>
            ) : null}
          </tbody>
        </table>

        {selected && editing ? (
          <form action={submit} className="mt-4 space-y-3 rounded-xl bg-slate-50 p-4">
            <p className="font-semibold text-nova-navy">Modification : {editing.name}</p>
            <input type="hidden" name="id" value={selected} />
            <div className="grid gap-3 sm:grid-cols-2">
              <label className="field">
                <span className="label">Code</span>
                <input className="input" name="code" defaultValue={editing.code} />
              </label>
              <label className="field">
                <span className="label">Nom</span>
                <input className="input" name="name" defaultValue={editing.name} />
              </label>
              <label className="field">
                <span className="label">Icone</span>
                <input className="input" name="icon" defaultValue={editing.icon ?? ""} />
              </label>
              <label className="field">
                <span className="label">Couleur</span>
                <input className="input" name="color" defaultValue={editing.color} />
              </label>
              <label className="field">
                <span className="label">Niveau</span>
                <select className="select" name="levelId" defaultValue={editing.levelId ?? ""}>
                  <option value="">— Tous les niveaux —</option>
                  {levels.map((l) => (
                    <option key={l.id} value={l.id}>{l.name}</option>
                  ))}
                </select>
              </label>
              <label className="field">
                <span className="label">Position</span>
                <input className="input" name="position" type="number" defaultValue={editing.position} />
              </label>
            </div>
            <label className="field">
              <span className="label">Description</span>
              <textarea className="textarea" name="description" defaultValue={editing.description ?? ""} />
            </label>
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" name="isActive" value="1" defaultChecked={editing.isActive} className="h-4 w-4 accent-nova-navy" />
              Matière active
            </label>
            <button type="submit" className="btn btn-navy btn-sm">Enregistrer</button>
          </form>
        ) : null}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Ressources
// ---------------------------------------------------------------------------

export function ResourceForm({
  subjects,
}: {
  subjects: { id: string; code: string; name: string }[];
}) {
  const { submit, busy, error, message } = useAdminSubmit("createResource");
  const action = useAdminAction();

  return (
    <div className="space-y-4">
      <form action={submit} className="space-y-3">
        <div className="grid gap-3 sm:grid-cols-2">
          <label className="field">
            <span className="label">Titre *</span>
            <input className="input" name="title" required />
          </label>
          <label className="field">
            <span className="label">Type</span>
            <select className="select" name="resourceType">
              <option value="fiche">Fiche de révision</option>
              <option value="resume">Résumé</option>
              <option value="correction">Correction</option>
              <option value="pdf">Document PDF</option>
            </select>
          </label>
          <label className="field">
            <span className="label">Matière *</span>
            <select className="select" name="subjectId" required>
              <option value="">Choisir…</option>
              {subjects.map((s) => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
          </label>
          <label className="field">
            <span className="label">Niveau (code)</span>
            <input className="input" name="levelId" placeholder="ex. : 9em ou ns4" />
          </label>
        </div>
        <label className="field">
          <span className="label">Résumé court</span>
          <textarea className="textarea" name="summary" />
        </label>
        <label className="field">
          <span className="label">Contenu (texte)</span>
          <textarea className="textarea" name="content" placeholder="Contenu pédagogique…" />
        </label>
        <label className="field">
          <span className="label">Fichier (PDF ou image)</span>
          <input className="input" type="file" name="file" accept=".pdf,image/*" />
        </label>
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" name="published" value="1" defaultChecked className="h-4 w-4 accent-nova-navy" />
          Publier immédiatement
        </label>
        <AdminFeedback error={error} message={message} />
        <button type="submit" disabled={busy} className="btn btn-navy btn-sm">{busy ? "Enregistrement…" : "Ajouter la ressource"}</button>
      </form>

      <button
        type="button"
        className="btn btn-outline btn-sm"
        onClick={() => action.run("resetDemoContent", {})}
      >
        Réinitialiser le contenu de démonstration
      </button>
      <p className="text-xs text-slate-500">
        Les ressources sont gratuites. L'option de réinitialisation ne touche pas aux comptes des élèves.
      </p>
    </div>
  );
}
