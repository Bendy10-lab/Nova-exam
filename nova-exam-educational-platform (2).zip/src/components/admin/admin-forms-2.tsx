"use client";

import { useState } from "react";
import { AdminFeedback, useAdminAction, useAdminSubmit } from "@/components/admin/admin-common";

type OptionItem = { text: string };
type QuestionDraft = {
  prompt: string;
  type: "mcq" | "short";
  options: OptionItem[];
  correctIndex: number;
  correctAnswer: string;
  explanation: string;
  points: number;
  image: string;
};

const emptyQuestion = (): QuestionDraft => ({
  prompt: "",
  type: "mcq",
  options: [{ text: "" }, { text: "" }, { text: "" }, { text: "" }],
  correctIndex: 0,
  correctAnswer: "",
  explanation: "",
  points: 20,
  image: "",
});

// ---------------------------------------------------------------------------
// Bibliothèque d'examens (PDF)
// ---------------------------------------------------------------------------

export function ExamForm({
  levels,
  series,
  subjects,
  exams,
}: {
  levels: { id: string; code: string; name: string }[];
  series: { id: string; code: string; name: string }[];
  subjects: { id: string; code: string; name: string }[];
  exams: {
    id: string;
    title: string;
    subjectName: string | null;
    filePath: string | null;
    correctionFilePath: string | null;
    published: boolean;
    isOfficial: boolean;
    year: number | null;
    examType: string;
  }[];
}) {
  const { submit, busy, error, message } = useAdminSubmit("createExam");
  const action = useAdminAction();
  const [selected, setSelected] = useState("");

  return (
    <div className="space-y-5">
      <form action={submit} className="space-y-3">
        <div className="grid gap-3 sm:grid-cols-2">
          <label className="field">
            <span className="label">Titre *</span>
            <input className="input" name="title" required placeholder="Ex. : Mathématiques 2023" />
          </label>
          <label className="field">
            <span className="label">Année</span>
            <input className="input" name="year" type="number" placeholder="2023" />
          </label>
          <label className="field">
            <span className="label">Niveau</span>
            <select className="select" name="levelId">
              <option value="">— Tous —</option>
              {levels.map((l) => (
                <option key={l.id} value={l.id}>{l.name}</option>
              ))}
            </select>
          </label>
          <label className="field">
            <span className="label">Série</span>
            <select className="select" name="serieId">
              <option value="">— Tous —</option>
              {series.map((s) => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
          </label>
          <label className="field">
            <span className="label">Matière</span>
            <select className="select" name="subjectId">
              <option value="">— Aucune —</option>
              {subjects.map((s) => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
          </label>
          <label className="field">
            <span className="label">Type</span>
            <select className="select" name="examType">
              <option value="precedent">Examen précédent</option>
              <option value="blanc">Examen blanc</option>
            </select>
          </label>
        </div>
        <label className="field">
          <span className="label">Description</span>
          <textarea className="textarea" name="description" />
        </label>
        <label className="field">
          <span className="label">Fichier PDF de l'examen</span>
          <input className="input" type="file" name="file" accept=".pdf" />
        </label>
        <label className="field">
          <span className="label">Fichier du corrigé (PDF)</span>
          <input className="input" type="file" name="correction" accept=".pdf" />
        </label>
        <div className="flex flex-wrap gap-4 text-sm">
          <label className="flex items-center gap-2">
            <input type="checkbox" name="hasCorrection" value="1" className="h-4 w-4 accent-nova-navy" /> Corrigé disponible
          </label>
          <label className="flex items-center gap-2">
            <input type="checkbox" name="isOfficial" value="1" className="h-4 w-4 accent-nova-navy" /> Document officiel (vérifié)
          </label>
          <label className="flex items-center gap-2">
            <input type="checkbox" name="published" value="1" defaultChecked className="h-4 w-4 accent-nova-navy" /> Publié
          </label>
        </div>
        <AdminFeedback error={error} message={message} />
        <button type="submit" disabled={busy} className="btn btn-navy btn-sm">{busy ? "Enregistrement…" : "Ajouter l'examen"}</button>
      </form>

      {selected ? (
        <form action={submit} className="space-y-3 rounded-xl bg-slate-50 p-4">
          <p className="font-semibold text-nova-navy">Modifier l'examen</p>
          <input type="hidden" name="id" value={selected} />
          <div className="grid gap-3 sm:grid-cols-2">
            <label className="field">
              <span className="label">Titre</span>
              <input className="input" name="title" defaultValue={""} />
            </label>
            <label className="field">
              <span className="label">Année</span>
              <input className="input" name="year" type="number" defaultValue={""} />
            </label>
            <label className="field">
              <span className="label">Niveau</span>
              <select className="select" name="levelId" defaultValue={""}>
                <option value="">— Tous —</option>
                {levels.map((l) => (
                  <option key={l.id} value={l.id}>{l.name}</option>
                ))}
              </select>
            </label>
            <label className="field">
              <span className="label">Série</span>
              <select className="select" name="serieId" defaultValue={""}>
                <option value="">— Tous —</option>
                {series.map((s) => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </select>
            </label>
            <label className="field">
              <span className="label">Matière</span>
              <select className="select" name="subjectId" defaultValue={""}>
                <option value="">— Aucune —</option>
                {subjects.map((s) => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </select>
            </label>
            <label className="field">
              <span className="label">Type</span>
              <select className="select" name="examType">
                <option value="precedent">Examen précédent</option>
                <option value="blanc">Examen blanc</option>
              </select>
            </label>
          </div>
          <label className="field">
            <span className="label">Description</span>
            <textarea className="textarea" name="description" />
          </label>
          <label className="field">
            <span className="label">Nouveau fichier PDF</span>
            <input className="input" type="file" name="file" accept=".pdf" />
          </label>
          <label className="field">
            <span className="label">Nouveau fichier de corrigé</span>
            <input className="input" type="file" name="correction" accept=".pdf" />
          </label>
          <div className="flex flex-wrap gap-4 text-sm">
            <label className="flex items-center gap-2">
              <input type="checkbox" name="hasCorrection" value="1" className="h-4 w-4 accent-nova-navy" /> Corrigé disponible
            </label>
            <label className="flex items-center gap-2">
              <input type="checkbox" name="isOfficial" value="1" className="h-4 w-4 accent-nova-navy" /> Document officiel
            </label>
            <label className="flex items-center gap-2">
              <input type="checkbox" name="published" value="1" defaultChecked className="h-4 w-4 accent-nova-navy" /> Publié
            </label>
          </div>
          <button type="submit" className="btn btn-navy btn-sm">Enregistrer</button>
        </form>
      ) : null}

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-slate-500">
              <th className="py-2 pr-3">Titre</th>
              <th className="py-2 pr-3">Matière</th>
              <th className="py-2 pr-3">PDF</th>
              <th className="py-2 pr-3">Corrigé</th>
              <th className="py-2 pr-3">Statut</th>
              <th className="py-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {exams.map((e) => (
              <tr key={e.id} className="border-t border-slate-100">
                <td className="py-2 pr-3 font-semibold text-nova-navy">
                  {e.title}
                  {e.isOfficial ? <span className="badge badge-gold ml-2">Officiel</span> : null}
                  {e.year ? <span className="badge badge-gray ml-2">{e.year}</span> : null}
                </td>
                <td className="py-2 pr-3 text-slate-600">{e.subjectName ?? "—"}</td>
                <td className="py-2 pr-3">{e.filePath ? "✓" : "—"}</td>
                <td className="py-2 pr-3">{e.correctionFilePath ? "✓" : "—"}</td>
                <td className="py-2 pr-3">
                  <span className={`badge ${e.published ? "badge-green" : "badge-gray"}`}>{e.published ? "Publié" : "Brouillon"}</span>
                </td>
                <td className="py-2">
                  <button type="button" className="btn btn-outline btn-sm" onClick={() => setSelected(e.id)}>Modifier</button>
                  <button
                    type="button"
                    className="btn btn-outline btn-sm ml-2"
                    disabled={action.busyId === e.id}
                    onClick={() => action.run("deleteExam", { id: e.id }, e.id)}
                  >
                    Supprimer
                  </button>
                </td>
              </tr>
            ))}
            {exams.length === 0 ? (
              <tr><td colSpan={6} className="py-3 text-slate-500">Aucun examen dans la bibliothèque.</td></tr>
            ) : null}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Examens interactifs
// ---------------------------------------------------------------------------

export function InteractiveExamForm({
  levels,
  series,
  subjects,
  exams,
}: {
  levels: { id: string; code: string; name: string }[];
  series: { id: string; code: string; name: string }[];
  subjects: { id: string; code: string; name: string }[];
  exams: {
    id: string;
    title: string;
    durationMinutes: number;
    maxScore: number;
    passingScore: number;
    isWhitePaper: boolean;
    published: boolean;
    subjectName: string | null;
    levelName: string | null;
    questionCount: number;
  }[];
}) {
  const { submit, busy, error, message } = useAdminSubmit("createInteractiveExam");
  const action = useAdminAction();
  const [selected, setSelected] = useState("");

  return (
    <div className="space-y-5">
      <form action={submit} className="space-y-3">
        <div className="grid gap-3 sm:grid-cols-2">
          <label className="field">
            <span className="label">Titre *</span>
            <input className="input" name="title" required />
          </label>
          <label className="field">
            <span className="label">Niveau</span>
            <select className="select" name="levelId">
              <option value="">— Tous —</option>
              {levels.map((l) => (
                <option key={l.id} value={l.id}>{l.name}</option>
              ))}
            </select>
          </label>
          <label className="field">
            <span className="label">Série</span>
            <select className="select" name="serieId">
              <option value="">— Tous —</option>
              {series.map((s) => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
          </label>
          <label className="field">
            <span className="label">Matière</span>
            <select className="select" name="subjectId">
              <option value="">— Aucune —</option>
              {subjects.map((s) => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
          </label>
          <label className="field">
            <span className="label">Durée (minutes)</span>
            <input className="input" name="durationMinutes" type="number" defaultValue={30} />
          </label>
          <label className="field">
            <span className="label">Note maximale</span>
            <input className="input" name="maxScore" type="number" defaultValue={100} />
          </label>
          <label className="field">
            <span className="label">Seuil de réussite (%)</span>
            <input className="input" name="passingScore" type="number" defaultValue={50} />
          </label>
        </div>
        <label className="field">
          <span className="label">Description</span>
          <textarea className="textarea" name="description" />
        </label>
        <div className="flex flex-wrap gap-4 text-sm">
          <label className="flex items-center gap-2">
            <input type="checkbox" name="isWhitePaper" value="1" defaultChecked className="h-4 w-4 accent-nova-navy" /> Examen blanc (entraînement)
          </label>
          <label className="flex items-center gap-2">
            <input type="checkbox" name="published" value="1" defaultChecked className="h-4 w-4 accent-nova-navy" /> Publié
          </label>
        </div>
        <AdminFeedback error={error} message={message} />
        <button type="submit" disabled={busy} className="btn btn-navy btn-sm">{busy ? "Enregistrement…" : "Créer l'examen interactif"}</button>
      </form>

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-slate-500">
              <th className="py-2 pr-3">Examen</th>
              <th className="py-2 pr-3">Matière</th>
              <th className="py-2 pr-3">Questions</th>
              <th className="py-2 pr-3">Durée</th>
              <th className="py-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {exams.map((e) => (
              <tr key={e.id} className="border-t border-slate-100">
                <td className="py-2 pr-3 font-semibold text-nova-navy">{e.title}</td>
                <td className="py-2 pr-3 text-slate-600">{e.subjectName ?? "—"}</td>
                <td className="py-2 pr-3 text-slate-600">{e.questionCount}</td>
                <td className="py-2 pr-3 text-slate-600">{e.durationMinutes} min</td>
                <td className="py-2">
                  <button type="button" className="btn btn-outline btn-sm" onClick={() => setSelected(e.id)}>
                    Gérer les questions
                  </button>
                  <button
                    type="button"
                    className="btn btn-outline btn-sm ml-2"
                    disabled={action.busyId === e.id}
                    onClick={() => action.run("deleteInteractiveExam", { id: e.id }, e.id)}
                  >
                    Supprimer
                  </button>
                </td>
              </tr>
            ))}
            {exams.length === 0 ? (
              <tr><td colSpan={5} className="py-3 text-slate-500">Aucun examen interactif.</td></tr>
            ) : null}
          </tbody>
        </table>
      </div>

      {selected ? (
        <QuestionsEditor examId={selected} />
      ) : null}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Éditeur de questions
// ---------------------------------------------------------------------------

export function QuestionsEditor({
  examId,
  initialQuestions = [],
}: {
  examId: string;
  initialQuestions?: Array<{
    id: string;
    prompt: string;
    questionType: string;
    optionsJson: { text: string }[] | null;
    correctIndex: number | null;
    correctAnswer: string | null;
    explanation: string | null;
    points: number;
    imagePath: string | null;
  }>;
}) {
  const { submit, busy, error, message } = useAdminSubmit("saveQuestions");
  const [questions, setQuestions] = useState<QuestionDraft[]>(
    initialQuestions.length > 0
      ? initialQuestions.map((q) => ({
          prompt: q.prompt,
          type: (q.questionType as "mcq" | "short") ?? "mcq",
          options: (q.optionsJson ?? [{ text: "" }, { text: "" }]).map((o) => ({ text: String(o.text) })),
          correctIndex: q.correctIndex ?? 0,
          correctAnswer: q.correctAnswer ?? "",
          explanation: q.explanation ?? "",
          points: q.points ?? 20,
          image: q.imagePath ?? "",
        }))
      : [emptyQuestion()],
  );
  const [imageFile, setImageFile] = useState<File | null>(null);

  function update(index: number, patch: Partial<QuestionDraft>) {
    setQuestions((qs) => qs.map((q, i) => (i === index ? { ...q, ...patch } : q)));
  }

  async function uploadImage(file: File) {
    setImageFile(file);
    const fd = new FormData();
    fd.set("folder", "questions");
    fd.set("prefix", "q");
    fd.set("file", file);
    const res = await fetch("/api/admin", { method: "POST", body: fd });
    const data = await res.json();
    if (data.ok) {
      setQuestions((qs) => qs.map((q) => ({ ...q, image: data.url })));
    }
  }

  function buildPayload() {
    return JSON.stringify(
      questions.map((q) => ({
        prompt: q.prompt,
        type: q.type,
        options: q.type === "mcq" ? q.options.filter((o) => o.text.trim() !== "") : [],
        correctIndex: q.type === "mcq" ? q.correctIndex : null,
        correctAnswer: q.type === "short" ? q.correctAnswer : null,
        explanation: q.explanation,
        points: Number(q.points) || 1,
        image: q.image,
      })),
    );
  }

  return (
    <div className="space-y-4 rounded-xl bg-slate-50 p-4">
      <p className="font-semibold text-nova-navy">Questions de cet examen</p>

      {questions.map((q, i) => (
        <div key={i} className="card space-y-3 p-4">
          <div className="flex items-start justify-between gap-3">
            <span className="badge badge-navy">Question {i + 1}</span>
            <button
              type="button"
              className="btn btn-outline btn-sm"
              onClick={() => setQuestions((qs) => qs.filter((_, idx) => idx !== i))}
            >
              Retirer
            </button>
          </div>
          <label className="field">
            <span className="label">Énoncé *</span>
            <textarea
              className="textarea"
              value={q.prompt}
              onChange={(e) => update(i, { prompt: e.target.value })}
            />
          </label>
          <div className="grid gap-3 sm:grid-cols-2">
            <label className="field">
              <span className="label">Type</span>
              <select
                className="select"
                value={q.type}
                onChange={(e) => update(i, { type: e.target.value as "mcq" | "short" })}
              >
                <option value="mcq">Choix multiples</option>
                <option value="short">Réponse courte</option>
              </select>
            </label>
            <label className="field">
              <span className="label">Points</span>
              <input
                className="input"
                type="number"
                value={q.points}
                onChange={(e) => update(i, { points: Number(e.target.value) })}
              />
            </label>
          </div>

          {q.type === "mcq" ? (
            <div className="space-y-2">
              {q.options.map((opt, oi) => (
                <div key={oi} className="flex items-center gap-2">
                  <span className="w-6 font-bold text-slate-500">{String.fromCharCode(65 + oi)}</span>
                  <input
                    className="input"
                    placeholder="Texte de l'option"
                    value={opt.text}
                    onChange={(e) =>
                      update(i, { options: q.options.map((o, idx) => (idx === oi ? { text: e.target.value } : o)) })
                    }
                  />
                  <button
                    type="button"
                    className="btn btn-outline btn-sm"
                    title="Marquer comme correcte"
                    onClick={() => update(i, { correctIndex: oi })}
                  >
                    ✓ Correcte
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <label className="field">
              <span className="label">Réponse attendue</span>
              <input
                className="input"
                value={q.correctAnswer}
                onChange={(e) => update(i, { correctAnswer: e.target.value })}
                placeholder="Ex. : 24 cm²"
              />
            </label>
          )}

          <label className="field">
            <span className="label">Explication pédagogique</span>
            <textarea
              className="textarea"
              value={q.explanation}
              onChange={(e) => update(i, { explanation: e.target.value })}
            />
          </label>

          {q.type === "short" || q.type === "mcq" ? (
            <label className="field">
              <span className="label">Image (optionnelle)</span>
              <div className="flex flex-wrap items-center gap-3">
                <input
                  className="input"
                  type="file"
                  accept="image/*"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) void uploadImage(file);
                  }}
                />
                {q.image ? (
                  <img src={q.image} alt="question" className="h-16 w-16 rounded-lg object-cover" />
                ) : null}
              </div>
            </label>
          ) : null}
        </div>
      ))}

      <div className="flex flex-wrap gap-2">
        <button type="button" className="btn btn-outline btn-sm" onClick={() => setQuestions((qs) => [...qs, emptyQuestion()])}>
          + Ajouter une question
        </button>
        <button type="button" className="btn btn-navy btn-sm" disabled={busy} onClick={() => {
          const fd = new FormData();
          fd.set("id", examId);
          fd.set("questions", buildPayload());
          void submit(fd);
        }}>
          {busy ? "Sauvegarde…" : "Sauvegarder les questions"}
        </button>
      </div>
      <AdminFeedback error={error} message={message} />
      {imageFile ? <p className="text-xs text-slate-500">Image en cours d'upload…</p> : null}
    </div>
  );
}
