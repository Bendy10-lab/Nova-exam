"use client";

import { useState } from "react";
import { AdminFeedback, useAdminAction, useAdminSubmit } from "@/components/admin/admin-common";

// ---------------------------------------------------------------------------
// Promotions
// ---------------------------------------------------------------------------

export type PromotionRow = {
  id: string;
  name: string;
  logoPath: string | null;
  shortDescription: string | null;
  description: string | null;
  category: string | null;
  websiteUrl: string | null;
  downloadUrl: string | null;
  buttonText: string;
  startsAt: string | null;
  endsAt: string | null;
  status: string;
  position: number;
  showOnHome: boolean;
  showInFooter: boolean;
  showInDashboard: boolean;
  clicks: number;
};

export function PromotionForm({ promotions }: { promotions: PromotionRow[] }) {
  const { submit, busy, error, message } = useAdminSubmit("createPromotion");
  const action = useAdminAction();
  const [selected, setSelected] = useState(promotions[0]?.id ?? "");
  const editing = promotions.find((p) => p.id === selected);

  return (
    <div className="space-y-5">
      <form action={submit} className="space-y-3">
        <div className="grid gap-3 sm:grid-cols-2">
          <label className="field">
            <span className="label">Nom de la plateforme *</span>
            <input className="input" name="name" required placeholder="Ex. : Klas Pam" />
          </label>
          <label className="field">
            <span className="label">Catégorie</span>
            <input className="input" name="category" placeholder="Éducation" />
          </label>
          <label className="field">
            <span className="label">Adresse du site web</span>
            <input className="input" name="websiteUrl" placeholder="https://…" />
          </label>
          <label className="field">
            <span className="label">Lien de téléchargement</span>
            <input className="input" name="downloadUrl" placeholder="https://… ou lien d'application" />
          </label>
          <label className="field">
            <span className="label">Texte du bouton</span>
            <input className="input" name="buttonText" placeholder="Visiter" defaultValue="Visiter" />
          </label>
          <label className="field">
            <span className="label">Position d'affichage</span>
            <input className="input" name="position" type="number" defaultValue={1} />
          </label>
          <label className="field">
            <span className="label">Date de début</span>
            <input className="input" name="startsAt" type="date" />
          </label>
          <label className="field">
            <span className="label">Date de fin (facultatif)</span>
            <input className="input" name="endsAt" type="date" />
          </label>
        </div>
        <label className="field">
          <span className="label">Description courte</span>
          <input className="input" name="shortDescription" placeholder="Une phrase de présentation" />
        </label>
        <label className="field">
          <span className="label">Description complète</span>
          <textarea className="textarea" name="description" />
        </label>
        <label className="field">
          <span className="label">Logo ou image</span>
          <input className="input" type="file" name="logo" accept="image/*" />
        </label>
        <div className="flex flex-wrap gap-4 text-sm">
          <label className="flex items-center gap-2">
            <input type="checkbox" name="showOnHome" value="1" defaultChecked className="h-4 w-4 accent-nova-navy" /> Page d'accueil
          </label>
          <label className="flex items-center gap-2">
            <input type="checkbox" name="showInFooter" value="1" className="h-4 w-4 accent-nova-navy" /> Pied de page
          </label>
          <label className="flex items-center gap-2">
            <input type="checkbox" name="showInDashboard" value="1" className="h-4 w-4 accent-nova-navy" /> Tableau de bord élève
          </label>
        </div>
        <label className="field">
          <span className="label">Statut</span>
          <select className="select" name="status" defaultValue="brouillon">
            <option value="brouillon">Brouillon</option>
            <option value="publiee">Publiée</option>
            <option value="desactivee">Désactivée</option>
          </select>
        </label>
        <AdminFeedback error={error} message={message} />
        <button type="submit" disabled={busy} className="btn btn-navy btn-sm">{busy ? "Enregistrement…" : "Ajouter la promotion"}</button>
      </form>

      {selected && editing ? (
        <form action={submit} className="space-y-3 rounded-xl bg-slate-50 p-4">
          <p className="font-semibold text-nova-navy">Modification : {editing.name}</p>
          <input type="hidden" name="id" value={selected} />
          <div className="grid gap-3 sm:grid-cols-2">
            <label className="field">
              <span className="label">Nom</span>
              <input className="input" name="name" defaultValue={editing.name} />
            </label>
            <label className="field">
              <span className="label">Catégorie</span>
              <input className="input" name="category" defaultValue={editing.category ?? ""} />
            </label>
            <label className="field">
              <span className="label">Site web</span>
              <input className="input" name="websiteUrl" defaultValue={editing.websiteUrl ?? ""} />
            </label>
            <label className="field">
              <span className="label">Téléchargement</span>
              <input className="input" name="downloadUrl" defaultValue={editing.downloadUrl ?? ""} />
            </label>
            <label className="field">
              <span className="label">Texte du bouton</span>
              <input className="input" name="buttonText" defaultValue={editing.buttonText} />
            </label>
            <label className="field">
              <span className="label">Position</span>
              <input className="input" name="position" type="number" defaultValue={editing.position} />
            </label>
            <label className="field">
              <span className="label">Date de début</span>
              <input className="input" name="startsAt" type="date" defaultValue={editing.startsAt ?? ""} />
            </label>
            <label className="field">
              <span className="label">Date de fin</span>
              <input className="input" name="endsAt" type="date" defaultValue={editing.endsAt ?? ""} />
            </label>
          </div>
          <label className="field">
            <span className="label">Description courte</span>
            <input className="input" name="shortDescription" defaultValue={editing.shortDescription ?? ""} />
          </label>
          <label className="field">
            <span className="label">Description complète</span>
            <textarea className="textarea" name="description" defaultValue={editing.description ?? ""} />
          </label>
          <label className="field">
            <span className="label">Nouveau logo</span>
            <input className="input" type="file" name="logo" accept="image/*" />
          </label>
          <div className="flex flex-wrap gap-4 text-sm">
            <label className="flex items-center gap-2">
              <input type="checkbox" name="showOnHome" value="1" defaultChecked={editing.showOnHome} className="h-4 w-4 accent-nova-navy" /> Page d'accueil
            </label>
            <label className="flex items-center gap-2">
              <input type="checkbox" name="showInFooter" value="1" defaultChecked={editing.showInFooter} className="h-4 w-4 accent-nova-navy" /> Pied de page
            </label>
            <label className="flex items-center gap-2">
              <input type="checkbox" name="showInDashboard" value="1" defaultChecked={editing.showInDashboard} className="h-4 w-4 accent-nova-navy" /> Tableau de bord élève
            </label>
          </div>
          <label className="field">
            <span className="label">Statut</span>
            <select className="select" name="status" defaultValue={editing.status}>
              <option value="brouillon">Brouillon</option>
              <option value="publiee">Publiée</option>
              <option value="desactivee">Désactivée</option>
            </select>
          </label>
          <div className="flex flex-wrap items-center gap-3">
            <button type="submit" className="btn btn-navy btn-sm">Enregistrer</button>
            <button
              type="button"
              className="btn btn-outline btn-sm"
              disabled={action.busyId === editing.id}
              onClick={() => action.run("deletePromotion", { id: editing.id }, editing.id)}
            >
              Supprimer la promotion
            </button>
          </div>
        </form>
      ) : null}

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-slate-500">
              <th className="py-2 pr-3">Plateforme</th>
              <th className="py-2 pr-3">Catégorie</th>
              <th className="py-2 pr-3">Affichage</th>
              <th className="py-2 pr-3">Statut</th>
              <th className="py-2 pr-3">Clics</th>
              <th className="py-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {promotions.map((p) => (
              <tr key={p.id} className="border-t border-slate-100">
                <td className="py-2 pr-3">
                  <div className="flex items-center gap-2">
                    {p.logoPath ? (
                      <img src={p.logoPath} alt="" className="h-8 w-8 rounded-lg object-cover" />
                    ) : (
                      <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-nova-navy font-bold text-nova-gold-light">
                        {p.name.slice(0, 2).toUpperCase()}
                      </span>
                    )}
                    <span className="font-semibold text-nova-navy">{p.name}</span>
                  </div>
                </td>
                <td className="py-2 pr-3 text-slate-600">{p.category ?? "—"}</td>
                <td className="py-2 pr-3 text-slate-600">
                  {p.showOnHome ? "Accueil " : ""}
                  {p.showInFooter ? "Pied " : ""}
                  {p.showInDashboard ? "Espace " : ""}
                  {!p.showOnHome && !p.showInFooter && !p.showInDashboard ? "—" : ""}
                </td>
                <td className="py-2 pr-3">
                  <span className={`badge ${p.status === "publiee" ? "badge-green" : p.status === "desactivee" ? "badge-red" : "badge-gray"}`}>
                    {p.status === "publiee" ? "Publiée" : p.status === "desactivee" ? "Désactivée" : "Brouillon"}
                  </span>
                </td>
                <td className="py-2 pr-3 font-semibold text-nova-navy">{p.clicks}</td>
                <td className="py-2">
                  <button type="button" className="btn btn-outline btn-sm" onClick={() => setSelected(p.id)}>Modifier</button>
                  <button
                    type="button"
                    className="btn btn-outline btn-sm ml-2"
                    disabled={action.busyId === p.id}
                    onClick={() =>
                      action.run("updatePromotion", {
                        id: p.id,
                        status: p.status === "publiee" ? "desactivee" : "publiee",
                        showOnHome: p.showOnHome ? "0" : "1",
                        showInFooter: p.showInFooter ? "0" : "1",
                        showInDashboard: p.showInDashboard ? "0" : "1",
                      }, p.id)
                    }
                  >
                    Activer / désactiver
                  </button>
                </td>
              </tr>
            ))}
            {promotions.length === 0 ? (
              <tr><td colSpan={6} className="py-3 text-slate-500">Aucune promotion.</td></tr>
            ) : null}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Annonces
// ---------------------------------------------------------------------------

export function AnnouncementForm({
  announcements,
}: {
  announcements: { id: string; title: string; content: string; published: boolean }[];
}) {
  const { submit, busy, error, message } = useAdminSubmit("createAnnouncement");
  const action = useAdminAction();
  const [selected, setSelected] = useState(announcements[0]?.id ?? "");
  const editing = announcements.find((a) => a.id === selected);

  return (
    <div className="space-y-5">
      <form action={submit} className="space-y-3">
        <label className="field">
          <span className="label">Titre *</span>
          <input className="input" name="title" required />
        </label>
        <label className="field">
          <span className="label">Contenu *</span>
          <textarea className="textarea" name="content" required />
        </label>
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" name="published" value="1" defaultChecked className="h-4 w-4 accent-nova-navy" />
          Publier immédiatement
        </label>
        <AdminFeedback error={error} message={message} />
        <button type="submit" disabled={busy} className="btn btn-navy btn-sm">{busy ? "Enregistrement…" : "Ajouter l'annonce"}</button>
      </form>

      {selected && editing ? (
        <form action={submit} className="space-y-3 rounded-xl bg-slate-50 p-4">
          <p className="font-semibold text-nova-navy">Modification : {editing.title}</p>
          <input type="hidden" name="id" value={selected} />
          <label className="field">
            <span className="label">Titre</span>
            <input className="input" name="title" defaultValue={editing.title} />
          </label>
          <label className="field">
            <span className="label">Contenu</span>
            <textarea className="textarea" name="content" defaultValue={editing.content} />
          </label>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" name="published" value="1" defaultChecked={editing.published} className="h-4 w-4 accent-nova-navy" />
            Annonce publiée
          </label>
          <div className="flex flex-wrap gap-3">
            <button type="submit" className="btn btn-navy btn-sm">Enregistrer</button>
            <button
              type="button"
              className="btn btn-outline btn-sm"
              disabled={action.busyId === editing.id}
              onClick={() => action.run("deleteAnnouncement", { id: editing.id }, editing.id)}
            >
              Supprimer
            </button>
          </div>
        </form>
      ) : null}

      <ul className="space-y-2">
        {announcements.map((a) => (
          <li key={a.id} className="flex items-center justify-between gap-3 rounded-xl bg-slate-50 p-3 text-sm">
            <span className="font-semibold text-nova-navy">{a.title}</span>
            <span className={`badge ${a.published ? "badge-green" : "badge-gray"}`}>{a.published ? "Publiée" : "Brouillon"}</span>
          </li>
        ))}
        {announcements.length === 0 ? <li className="text-sm text-slate-500">Aucune annonce.</li> : null}
      </ul>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Utilisateurs
// ---------------------------------------------------------------------------

export function UserActions({
  users,
}: {
  users: {
    id: string;
    nom: string;
    email: string;
    role: string;
    isActive: boolean;
    niveau: string | null;
    serie: string | null;
    lastLoginAt: string | null;
    createdAt: string;
    activityCount: number;
  }[];
}) {
  const action = useAdminAction();
  const [report, setReport] = useState("");
  const [message, setMessage] = useState("");

  async function resetPassword(id: string) {
    const password = window.prompt("Nouveau mot de passe (8 caractères minimum) pour cet utilisateur :");
    if (!password) return;
    await action.run("resetUserPassword", { id, password }, id);
    setMessage("Mot de passe réinitialisé.");
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-3">
        <input className="input max-w-xs" placeholder="Rechercher par nom ou e-mail…" value={report} onChange={(e) => setReport(e.target.value)} />
        <span className="text-sm text-slate-500">{users.length} compte(s)</span>
      </div>
      {message ? <p className="text-sm font-medium text-green-600">{message}</p> : null}
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-slate-500">
              <th className="py-2 pr-3">Nom</th>
              <th className="py-2 pr-3">E-mail</th>
              <th className="py-2 pr-3">Rôle</th>
              <th className="py-2 pr-3">Niveau</th>
              <th className="py-2 pr-3">Dernière connexion</th>
              <th className="py-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {users
              .filter((u) => (report ? u.nom.toLowerCase().includes(report.toLowerCase()) || u.email.toLowerCase().includes(report.toLowerCase()) : true))
              .map((u) => (
                <tr key={u.id} className="border-t border-slate-100">
                  <td className="py-2 pr-3 font-semibold text-nova-navy">{u.nom}</td>
                  <td className="py-2 pr-3 text-slate-600">{u.email}</td>
                  <td className="py-2 pr-3">
                    <select
                      className="select py-1"
                      value={u.role}
                      onChange={(e) => action.run("updateUserRole", { id: u.id, role: e.target.value }, u.id)}
                    >
                      <option value="eleve">Élève</option>
                      <option value="administrateur">Administrateur</option>
                      <option value="super_administrateur">Super administrateur</option>
                    </select>
                  </td>
                  <td className="py-2 pr-3 text-slate-600">{u.niveau ?? "—"}{u.serie ? ` / ${u.serie}` : ""}</td>
                  <td className="py-2 pr-3 text-slate-600">
                    {u.lastLoginAt ? new Date(u.lastLoginAt).toLocaleDateString("fr-FR") : "—"}
                  </td>
                  <td className="py-2">
                    <span className={`badge ${u.isActive ? "badge-green" : "badge-red"}`}>{u.isActive ? "Actif" : "Suspendu"}</span>{" "}
                    <button
                      type="button"
                      className="btn btn-outline btn-sm"
                      disabled={action.busyId === u.id}
                      onClick={() => action.run("updateUserStatus", { id: u.id, isActive: u.isActive ? "0" : "1" }, u.id)}
                    >
                      {u.isActive ? "Suspendre" : "Réactiver"}
                    </button>{" "}
                    <button type="button" className="btn btn-outline btn-sm" onClick={() => void resetPassword(u.id)}>
                      Mot de passe
                    </button>
                  </td>
                </tr>
              ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Paramètres du site
// ---------------------------------------------------------------------------

export function SettingsForm({ values }: { values: Record<string, string> }) {
  const { submit, busy, error, message } = useAdminSubmit("updateSettings");

  function buildPayload() {
    const fd = new FormData();
    const fields = [
      "site_name", "site_slogan", "site_description", "whatsapp_number", "contact_email",
      "founder_name", "founder_title", "founder_bio", "founder_mission", "address",
      "facebook_url", "instagram_url", "twitter_url", "youtube_url",
    ];
    const inputs = document.querySelectorAll<HTMLInputElement | HTMLTextAreaElement>("[data-setting]");
    const payload: Record<string, string> = {};
    inputs.forEach((input) => {
      payload[input.dataset.setting ?? ""] = input.value;
    });
    for (const f of fields) {
      if (!(f in payload)) payload[f] = values[f] ?? "";
    }
    fd.set("values", JSON.stringify(payload));
    return fd;
  }

  return (
    <div className="space-y-5">
      <form action={submit} className="space-y-4">
        <Field label="Nom du site" value={values.site_name ?? ""} dataSetting="site_name" />
        <Field label="Slogan" value={values.site_slogan ?? ""} dataSetting="site_slogan" />
        <Field label="Description du site" value={values.site_description ?? ""} dataSetting="site_description" textarea />
        <Field label="Numéro WhatsApp (avec indicatif, ex. 509 1234567)" value={values.whatsapp_number ?? ""} dataSetting="whatsapp_number" />
        <Field label="Adresse e-mail de contact" value={values.contact_email ?? ""} dataSetting="contact_email" />
        <Field label="Adresse" value={values.address ?? ""} dataSetting="address" />

        <hr className="border-slate-200" />
        <h3 className="font-bold text-nova-navy">Présentation du fondateur</h3>
        <Field label="Nom du fondateur" value={values.founder_name ?? ""} dataSetting="founder_name" />
        <Field label="Titre du fondateur" value={values.founder_title ?? ""} dataSetting="founder_title" />
        <Field label="Présentation du fondateur" value={values.founder_bio ?? ""} dataSetting="founder_bio" textarea />
        <Field label="Mission éducative" value={values.founder_mission ?? ""} dataSetting="founder_mission" textarea />

        <hr className="border-slate-200" />
        <h3 className="font-bold text-nova-navy">Liens sociaux (optionnels)</h3>
        <Field label="Facebook" value={values.facebook_url ?? ""} dataSetting="facebook_url" />
        <Field label="Instagram" value={values.instagram_url ?? ""} dataSetting="instagram_url" />
        <Field label="Twitter / X" value={values.twitter_url ?? ""} dataSetting="twitter_url" />
        <Field label="YouTube" value={values.youtube_url ?? ""} dataSetting="youtube_url" />

        <AdminFeedback error={error} message={message} />
        <button type="button" className="btn btn-navy btn-sm" disabled={busy} onClick={() => void submit(buildPayload())}>
          {busy ? "Enregistrement…" : "Enregistrer les paramètres"}
        </button>
      </form>
    </div>
  );
}

function Field({
  label,
  value,
  dataSetting,
  textarea,
}: {
  label: string;
  value: string;
  dataSetting: string;
  textarea?: boolean;
}) {
  return (
    <label className="field">
      <span className="label">{label}</span>
      {textarea ? (
        <textarea className="textarea" defaultValue={value} data-setting={dataSetting} />
      ) : (
        <input className="input" defaultValue={value} data-setting={dataSetting} />
      )}
    </label>
  );
}
