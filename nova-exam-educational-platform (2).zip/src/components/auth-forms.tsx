"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useState } from "react";

type Level = { id: string; code: string; name: string };
type Series = { id: string; code: string; name: string };

async function post(action: string, payload: Record<string, unknown>) {
  const res = await fetch("/api/auth", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ action, ...payload }),
  });
  return { res, data: await res.json() };
}

export function RegisterForm({ levels, series }: { levels: Level[]; series: Series[] }) {
  const router = useRouter();
  const [nom, setNom] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [niveau, setNiveau] = useState("");
  const [serie, setSerie] = useState("");
  const [error, setError] = useState("");
  const [sending, setSending] = useState(false);

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError("");
    if (nom.trim().length < 2) return setError("Veuillez entrer votre nom complet.");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return setError("Veuillez entrer un e-mail valide.");
    if (password.length < 8) return setError("Le mot de passe doit contenir au moins 8 caractères.");
    if (password !== confirm) return setError("Les deux mots de passe ne correspondent pas.");

    setSending(true);
    const { res, data } = await post("register", { nom, email, password, niveau: niveau || null, serie: serie || null });
    setSending(false);
    if (!res.ok || !data.ok) {
      setError(data.error ?? "Impossible de créer le compte.");
      return;
    }
    router.push("/espace");
    router.refresh();
  }

  return (
    <form onSubmit={submit} className="card space-y-4 p-6 sm:p-8">
      <h1 className="text-2xl font-extrabold text-nova-navy">Créer un compte gratuit</h1>
      <p className="text-sm text-slate-600">Inscription sans frais. Aucun paiement requis.</p>

      <label className="field">
        <span className="label">Nom complet *</span>
        <input className="input" value={nom} onChange={(e) => setNom(e.target.value)} placeholder="Ex. : Marie Dubois" autoComplete="name" />
      </label>

      <label className="field">
        <span className="label">Adresse e-mail *</span>
        <input className="input" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="vous@exemple.com" autoComplete="email" />
      </label>

      <div className="grid gap-4 sm:grid-cols-2">
        <label className="field">
          <span className="label">Niveau scolaire</span>
          <select className="select" value={niveau} onChange={(e) => { setNiveau(e.target.value); setSerie(""); }}>
            <option value="">Choisir…</option>
            {levels.map((l) => (
              <option key={l.id} value={l.code}>{l.name}</option>
            ))}
          </select>
        </label>
        <label className="field">
          <span className="label">Série {niveau === "ns4" ? "(si applicable)" : ""}</span>
          <select className="select" value={serie} onChange={(e) => setSerie(e.target.value)} disabled={!niveau}>
            <option value="">Choisir…</option>
            {series.map((s) => (
              <option key={s.id} value={s.code}>{s.name}</option>
            ))}
          </select>
        </label>
      </div>

      <label className="field">
        <span className="label">Mot de passe *</span>
        <input className="input" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="8 caractères minimum" autoComplete="new-password" />
      </label>

      <label className="field">
        <span className="label">Confirmer le mot de passe *</span>
        <input className="input" type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} autoComplete="new-password" />
      </label>

      {error ? <p className="text-sm font-medium text-red-600">{error}</p> : null}

      <button type="submit" disabled={sending} className="btn btn-navy btn-block">
        {sending ? "Création…" : "Créer mon compte"}
      </button>

      <p className="text-center text-sm text-slate-600">
        Vous avez déjà un compte ?{" "}
        <Link href="/connexion" className="font-semibold text-nova-blue underline">Se connecter</Link>
      </p>
      <p className="text-center text-xs text-slate-500">
        En vous inscrivant, vous acceptez que vos données soient utilisées uniquement pour votre espace personnel.
      </p>
    </form>
  );
}

export function LoginForm() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [sending, setSending] = useState(false);

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError("");
    if (!email || !password) return setError("Veuillez remplir les deux champs.");
    setSending(true);
    const { res, data } = await post("login", { email, password });
    setSending(false);
    if (!res.ok || !data.ok) {
      setError(data.error ?? "Connexion impossible.");
      return;
    }
    const next = data.user?.role === "eleve" ? "/espace" : "/administrateur";
    router.push(next);
    router.refresh();
  }

  return (
    <form onSubmit={submit} className="card space-y-4 p-6 sm:p-8">
      <h1 className="text-2xl font-extrabold text-nova-navy">Se connecter</h1>
      <p className="text-sm text-slate-600">Accédez à votre espace, vos examens et vos résultats.</p>

      <label className="field">
        <span className="label">Adresse e-mail</span>
        <input className="input" type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" />
      </label>

      <label className="field">
        <span className="label">Mot de passe</span>
        <input className="input" type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" />
      </label>

      {error ? <p className="text-sm font-medium text-red-600">{error}</p> : null}

      <button type="submit" disabled={sending} className="btn btn-navy btn-block">
        {sending ? "Connexion…" : "Se connecter"}
      </button>

      <div className="flex justify-between text-sm">
        <Link href="/mot-de-passe-oublie" className="font-semibold text-nova-blue underline">Mot de passe oublié ?</Link>
        <Link href="/inscription" className="font-semibold text-nova-blue underline">Créer un compte</Link>
      </div>
    </form>
  );
}

export function ForgotForm() {
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const [sending, setSending] = useState(false);

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError("");
    setInfo("");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return setError("Veuillez entrer un e-mail valide.");
    setSending(true);
    const { res, data } = await post("forgot", { email });
    setSending(false);
    if (!res.ok || !data.ok) {
      setError(data.error ?? "Une erreur est survenue.");
      return;
    }
    setInfo(data.resetUrl ? `Lien de réinitialisation (valide 1 heure) : ${data.resetUrl}` : data.message ?? "Demande enregistrée.");
  }

  return (
    <form onSubmit={submit} className="card space-y-4 p-6 sm:p-8">
      <h1 className="text-2xl font-extrabold text-nova-navy">Mot de passe oublié</h1>
      <p className="text-sm text-slate-600">
        Entrez votre e-mail. Un lien de réinitialisation sera généré (et envoyé par e-mail si un service est configuré).
      </p>
      <label className="field">
        <span className="label">Adresse e-mail</span>
        <input className="input" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
      </label>
      {error ? <p className="text-sm font-medium text-red-600">{error}</p> : null}
      {info ? <p className="break-all rounded-lg bg-slate-50 p-3 text-xs text-nova-navy">{info}</p> : null}
      <button type="submit" disabled={sending} className="btn btn-navy btn-block">
        {sending ? "Traitement…" : "Envoyer la demande"}
      </button>
      <Link href="/connexion" className="text-sm font-semibold text-nova-blue underline">Retour à la connexion</Link>
    </form>
  );
}

export function ResetForm() {
  const params = useSearchParams();
  const token = params.get("token") ?? "";
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");
  const [ok, setOk] = useState("");
  const [sending, setSending] = useState(false);
  const router = useRouter();

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError("");
    setOk("");
    if (password.length < 8) return setError("Le mot de passe doit contenir au moins 8 caractères.");
    if (password !== confirm) return setError("Les deux mots de passe ne correspondent pas.");
    setSending(true);
    const { res, data } = await post("reset", { token, password });
    setSending(false);
    if (!res.ok || !data.ok) {
      setError(data.error ?? "Lien invalide.");
      return;
    }
    setOk(data.message);
    setTimeout(() => router.push("/connexion"), 1200);
  }

  if (!token) {
    return (
      <div className="card space-y-4 p-8 text-center">
        <h1 className="text-2xl font-extrabold text-nova-navy">Lien de réinitialisation invalide</h1>
        <p className="text-sm text-slate-600">Ce lien ne contient pas de jeton de sécurité. Demandez un nouveau lien.</p>
        <Link href="/mot-de-passe-oublie" className="btn btn-navy">Nouvelle demande</Link>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="card space-y-4 p-6 sm:p-8">
      <h1 className="text-2xl font-extrabold text-nova-navy">Nouveau mot de passe</h1>
      <p className="text-sm text-slate-600">Choisissez un mot de passe de 8 caractères minimum.</p>
      <label className="field">
        <span className="label">Nouveau mot de passe</span>
        <input className="input" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
      </label>
      <label className="field">
        <span className="label">Confirmer</span>
        <input className="input" type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} />
      </label>
      {error ? <p className="text-sm font-medium text-red-600">{error}</p> : null}
      {ok ? <p className="text-sm font-medium text-green-600">{ok}</p> : null}
      <button type="submit" disabled={sending} className="btn btn-navy btn-block">
        {sending ? "Validation…" : "Réinitialiser"}
      </button>
    </form>
  );
}
