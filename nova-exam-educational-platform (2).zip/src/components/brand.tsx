import clsx from "clsx";

/** Logo NOVA EXAM : livre ouvert + toque de diplômé. */
export function LogoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={clsx("h-9 w-9", className)} role="img" aria-label="NOVA EXAM">
      <defs>
        <linearGradient id="nova-gold-grad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#e7c86a" />
          <stop offset="100%" stopColor="#c9a227" />
        </linearGradient>
        <linearGradient id="nova-navy-grad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#14295c" />
          <stop offset="100%" stopColor="#0b1a3b" />
        </linearGradient>
      </defs>
      <circle cx="32" cy="32" r="32" fill="url(#nova-navy-grad)" />
      {/* Toque de diplômé */}
      <path d="M32 10 L54 19 L32 28 L10 19 Z" fill="url(#nova-gold-grad)" />
      <path d="M20 22.5 L20 33 C20 36.5 24 39 32 39 C40 39 44 36.5 44 33 L44 22.5 L32 28 Z" fill="#ffffff" opacity="0.92" />
      <path d="M54 19 L54 26 C54 28.5 49.5 30 46 30 C42.5 30 38 28.5 38 26 L38 22.5 L50 17 Z" fill="url(#nova-gold-grad)" />
      {/* Livre ouvert */}
      <path d="M11 46 C16 42.5 21 42 26 43.5 L32 45 L38 43.5 C43 42 48 42.5 53 46 L53 54 L11 54 Z" fill="url(#nova-gold-grad)" opacity="0.95" />
      <path d="M32 45 L32 54" stroke="#0b1a3b" strokeWidth="1.4" />
      <path d="M16 48.5 C20 46.8 24 46.5 28 47.4" stroke="#0b1a3b" strokeWidth="1" fill="none" opacity="0.55" />
      <path d="M36 47.4 C40 46.5 44 46.8 48 48.5" stroke="#0b1a3b" strokeWidth="1" fill="none" opacity="0.55" />
    </svg>
  );
}

export function Logo({
  className,
  showText = true,
  light = false,
}: {
  className?: string;
  showText?: boolean;
  light?: boolean;
}) {
  return (
    <div className={clsx("flex items-center gap-2.5", className)}>
      <LogoMark className="h-9 w-9 shrink-0" />
      {showText ? (
        <div className="leading-tight">
          <div className={clsx("font-extrabold tracking-tight", light ? "text-white" : "text-nova-navy")}>
            NOVA<span className="gold-text"> EXAM</span>
          </div>
          <div className={clsx("text-[0.62rem] uppercase tracking-[0.22em]", light ? "text-white/60" : "text-nova-muted")}>
            Préparation des examens officiels
          </div>
        </div>
      ) : null}
    </div>
  );
}
