"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

type Props = { whatsapp: string; contactEmail: string };

export function WhatsAppButton({ whatsapp, label = "💬 WhatsApp" }: { whatsapp: string; label?: string }) {
  if (!whatsapp) return null;
  return (
    <a
      href={`https://wa.me/${whatsapp.replace(/^\+/, "")}`}
      target="_blank"
      rel="noreferrer"
      className="btn btn-gold btn-sm"
    >
      {label} : {whatsapp}
    </a>
  );
}

export function ContactForm({ whatsapp, contactEmail }: Props) {
  const [sending, setSending] = useState(false);
  const [message, setMessage] = useState("");
  const [email, setEmail] = useState("");
  const [sujet, setSujet] = useState("");
  const [error, setError] = useState("");
  const [ok, setOk] = useState("");
  const router = useRouter();

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError("");
    setOk("");
    if (!message.trim()) {
      setError("Veuillez écrire votre message.");
      return;
    }
    setSending(true);
    const res = await fetch("/api/contact", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "message", sujet, email, message }),
    });
    const data = await res.json();
    setSending(false);
    if (!res.ok || !data.ok) {
      setError(data.error ?? "Une erreur est survenue.");
      return;
    }
    setOk(data.message);
    setMessage("");
    setSujet("");
    setEmail("");
    router.refresh();
  }

  return (
    <form onSubmit={submit} className="card space-y-4 p-6">
      <h2 className="text-xl font-bold text-nova-navy">Écrivez-nous</h2>
      <div className="grid gap-4 sm:grid-cols-2">
        <label className="field">
          <span className="label">Sujet</span>
          <input className="input" value={sujet} onChange={(e) => setSujet(e.target.value)} placeholder="Assistance, partenariat…" />
        </label>
        <label className="field">
          <span className="label">Votre e-mail (facultatif)</span>
          <input className="input" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="vous@exemple.com" />
        </label>
      </div>
      <label className="field">
        <span className="label">Message</span>
        <textarea className="textarea" value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Décrivez votre demande ou votre problème…" />
      </label>
      {error ? <p className="text-sm font-medium text-red-600">{error}</p> : null}
      {ok ? <p className="text-sm font-medium text-green-600">{ok}</p> : null}
      <div className="flex flex-wrap items-center gap-3">
        <button type="submit" disabled={sending} className="btn btn-navy">
          {sending ? "Envoi…" : "Envoyer le message"}
        </button>
        <span className="text-xs text-slate-500">Ou écrivez à {contactEmail}</span>
        {whatsapp ? (
          <a href={`https://wa.me/${whatsapp.replace(/^\+/, "")}`} target="_blank" rel="noreferrer" className="btn btn-outline btn-sm">
            WhatsApp
          </a>
        ) : null}
      </div>
    </form>
  );
}

export function ReportForm() {
  const [sending, setSending] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [ok, setOk] = useState("");

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError("");
    setOk("");
    if (message.trim().length < 10) {
      setError("Décrivez l'erreur avec plus de détails.");
      return;
    }
    setSending(true);
    const res = await fetch("/api/contact", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "report", sujet: "Erreur dans un examen", message }),
    });
    const data = await res.json();
    setSending(false);
    if (!res.ok || !data.ok) {
      setError(data.error ?? "Une erreur est survenue.");
      return;
    }
    setOk(data.message);
    setMessage("");
  }

  return (
    <form onSubmit={submit} className="card space-y-4 p-6">
      <h2 className="text-xl font-bold text-nova-navy">Signaler une erreur dans un examen</h2>
      <p className="text-sm text-slate-600">
        Une question incorrecte, une réponse ambiguë, un document manquant ? Signalez-le pour que nous corrigions la
        ressource rapidement.
      </p>
      <label className="field">
        <span className="label">Description de l'erreur</span>
        <textarea
          className="textarea"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Ex. : question 3 — la réponse correcte devrait être « 24 cm² » et non « 24 cm »."
        />
      </label>
      {error ? <p className="text-sm font-medium text-red-600">{error}</p> : null}
      {ok ? <p className="text-sm font-medium text-green-600">{ok}</p> : null}
      <button type="submit" disabled={sending} className="btn btn-navy">
        {sending ? "Envoi…" : "Signaler l'erreur"}
      </button>
    </form>
  );
}

export const FAQ_ITEMS = [
  {
    q: "NOVA EXAM est-elle vraiment gratuite ?",
    a: "Oui. L'inscription, les exercices, les corrigés, les examens blancs et les téléchargements de documents sont entièrement gratuits. Aucun abonnement ni paiement n'est demandé.",
  },
  {
    q: "Dois-je créer un compte pour réviser ?",
    a: "Vous pouvez consulter les contenus publics sans compte. Un compte gratuit est nécessaire pour passer un examen blanc, sauvegarder vos résultats et suivre votre progression.",
  },
  {
    q: "Comment fonctionnent les examens blancs ?",
    a: "Vous répondez aux questions dans un temps imparti, puis vous soumettez. La plateforme calcule la note, affiche les réponses correctes et les explications. C'est un entraînement, pas un résultat officiel.",
  },
  {
    q: "Mon mot de passe est oublié. Que faire ?",
    a: "Utilisez la page « Mot de passe oublié ». Une demande génère un lien de réinitialisation valable une heure. Si un service d'e-mail est configuré, le lien est envoyé par e-mail.",
  },
  {
    q: "Mon enfant ou moi pouvons-nous voir les données des autres élèves ?",
    a: "Non. Chaque élève accède uniquement à son propre espace. Les pages administratives sont protégées et vérifiées côté serveur.",
  },
  {
    q: "Les examens publiés sont-ils officiels ?",
    a: "Seuls les documents marqués comme officiels et vérifiés par l'administrateur sont présentés comme officiels. Les autres sont des ressources d'entraînement ou des documents partagés.",
  },
  {
    q: "Comment puis-je obtenir de l'aide ?",
    a: "Utilisez le formulaire de contact, le WhatsApp configuré ou écrivez à l'adresse e-mail indiquée. Les messages sont enregistrés et consultés par l'administrateur.",
  },
];
