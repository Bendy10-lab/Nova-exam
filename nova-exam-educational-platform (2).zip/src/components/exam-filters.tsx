"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { useCallback } from "react";

export type FilterOptions = {
  levels: { id: string; code: string; name: string }[];
  series: { id: string; code: string; name: string }[];
  subjects: { id: string; code: string; name: string }[];
  years: number[];
  initial: {
    niveau: string;
    serie: string;
    matiere: string;
    annee: string;
    type: string;
    corrige: string;
    q: string;
  };
};

export default function ExamFilters({ options }: { options: FilterOptions }) {
  const router = useRouter();
  const params = useSearchParams();

  const buildUrl = useCallback(
    (next: Record<string, string>) => {
      const merged = {
        niveau: params.get("niveau") ?? "",
        serie: params.get("serie") ?? "",
        matiere: params.get("matiere") ?? "",
        annee: params.get("annee") ?? "",
        type: params.get("type") ?? "",
        corrige: params.get("corrige") ?? "",
        q: params.get("q") ?? "",
        ...next,
      };
      const query = new URLSearchParams();
      for (const [key, value] of Object.entries(merged)) {
        if (value) query.set(key, value);
      }
      const qs = query.toString();
      router.push(`/examens${qs ? `?${qs}` : ""}`);
    },
    [params, router],
  );

  return (
    <div className="card space-y-4 p-5">
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        <label className="field">
          <span className="label">Niveau</span>
          <select className="select" value={options.initial.niveau} onChange={(e) => buildUrl({ niveau: e.target.value, serie: "" })}>
            <option value="">Tous</option>
            {options.levels.map((l) => (
              <option key={l.id} value={l.id}>{l.name}</option>
            ))}
          </select>
        </label>

        <label className="field">
          <span className="label">Série</span>
          <select className="select" value={options.initial.serie} onChange={(e) => buildUrl({ serie: e.target.value })}>
            <option value="">Tous</option>
            {options.series.map((s) => (
              <option key={s.id} value={s.id}>{s.name}</option>
            ))}
          </select>
        </label>

        <label className="field">
          <span className="label">Matière</span>
          <select className="select" value={options.initial.matiere} onChange={(e) => buildUrl({ matiere: e.target.value })}>
            <option value="">Toutes</option>
            {options.subjects.map((s) => (
              <option key={s.id} value={s.id}>{s.name}</option>
            ))}
          </select>
        </label>

        <label className="field">
          <span className="label">Année</span>
          <select className="select" value={options.initial.annee} onChange={(e) => buildUrl({ annee: e.target.value })}>
            <option value="">Toutes</option>
            {options.years.map((y) => (
              <option key={y} value={String(y)}>{y}</option>
            ))}
          </select>
        </label>

        <label className="field">
          <span className="label">Type de document</span>
          <select className="select" value={options.initial.type} onChange={(e) => buildUrl({ type: e.target.value })}>
            <option value="">Tous</option>
            <option value="precedent">Examens précédents</option>
            <option value="blanc">Examens blancs</option>
          </select>
        </label>

        <label className="field">
          <span className="label">Corrigé disponible</span>
          <select className="select" value={options.initial.corrige} onChange={(e) => buildUrl({ corrige: e.target.value })}>
            <option value="">Tous</option>
            <option value="1">Oui</option>
            <option value="0">Non</option>
          </select>
        </label>

        <label className="field sm:col-span-2 lg:col-span-3">
          <span className="label">Recherche</span>
          <input
            className="input"
            defaultValue={options.initial.q}
            placeholder="Titre ou description…"
            onKeyDown={(e) => {
              if (e.key === "Enter") buildUrl({ q: (e.target as HTMLInputElement).value });
            }}
          />
        </label>
      </div>
      <button type="button" className="btn btn-outline btn-sm" onClick={() => router.push("/examens")}>
        Réinitialiser les filtres
      </button>
    </div>
  );
}
