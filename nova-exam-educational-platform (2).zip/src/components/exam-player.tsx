"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";

type Question = {
  id: string;
  orderNo: number;
  prompt: string;
  questionType: string;
  options: { text: string }[];
  points: number;
  imagePath: string | null;
};

type ResultDetail = {
  id: string;
  prompt: string;
  correct: boolean;
  points: number;
  earned: number;
  explanation: string | null;
  correctAnswer: string | null;
  userAnswer: string | null;
  questionType: string;
};

type ExamData = {
  id: string;
  title: string;
  description: string | null;
  durationMinutes: number;
  maxScore: number;
  passingScore: number;
  isWhitePaper: boolean;
  subjectName: string | null;
  questionCount: number;
};

export default function ExamPlayer({ examId }: { examId: string }) {
  const router = useRouter();
  const [exam, setExam] = useState<ExamData | null>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [phase, setPhase] = useState<"loading" | "intro" | "running" | "result" | "error">("loading");
  const [error, setError] = useState("");
  const [index, setIndex] = useState(0);
  const [remaining, setRemaining] = useState(0);
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<{
    score: number;
    percent: number;
    passed: boolean;
    feedback: string;
    maxScore: number;
    passingScore: number;
    details: ResultDetail[];
    notice: string | null;
  } | null>(null);
  const startedRef = useRef(false);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const load = useCallback(async () => {
    setPhase("loading");
    const res = await fetch(`/api/exams/${examId}`, { cache: "no-store" });
    const data = await res.json();
    if (!res.ok || !data.ok) {
      setError(data.error ?? "Impossible de charger l'examen.");
      setPhase("error");
      return;
    }
    setExam(data.exam);
    setQuestions(data.questions ?? []);
    setRemaining(data.exam.durationMinutes * 60);
    if (data.requiresLogin) {
      setPhase("intro");
      return;
    }
    if (!startedRef.current && data.attemptId) startedRef.current = true;
    if ((data.questions ?? []).length > 0) setPhase("intro");
  }, [examId]);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    if (phase !== "running") return;
    timerRef.current = setInterval(() => {
      setRemaining((v) => {
        if (v <= 1) {
          if (timerRef.current) clearInterval(timerRef.current);
          void submit(true);
          return 0;
        }
        return v - 1;
      });
    }, 1000);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase]);

  const formatTime = (s: number) => `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;

  async function start() {
    if (!exam) return;
    await fetch(`/api/exams/${examId}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "start" }),
    });
    startedRef.current = true;
    setPhase("running");
  }

  async function submit(auto = false) {
    if (!exam) return;
    setSubmitting(true);
    const res = await fetch(`/api/exams/${examId}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "submit", answers }),
    });
    const data = await res.json();
    setSubmitting(false);
    if (!res.ok || !data.ok) {
      setError(data.error ?? "Soumission impossible.");
      setPhase("error");
      return;
    }
    setResult({
      score: data.score,
      percent: data.percent,
      passed: data.passed,
      feedback: data.feedback,
      maxScore: data.maxScore,
      passingScore: data.passingScore,
      details: data.details,
      notice: data.whitePaperNotice,
    });
    setPhase("result");
    router.refresh();
    if (auto) setError("Le temps imparti est écoulé : votre examen a été soumis.");
  }

  const answeredCount = useMemo(
    () => questions.filter((q) => (answers[q.id] ?? "").trim() !== "").length,
    [questions, answers],
  );

  if (phase === "loading") {
    return (
      <div className="card p-8 text-center text-slate-500">Chargement de l'examen…</div>
    );
  }

  if (phase === "error") {
    return (
      <div className="card space-y-4 p-8 text-center">
        <p className="text-3xl">⚠️</p>
        <h1 className="text-xl font-bold text-nova-navy">Examen indisponible</h1>
        <p className="text-sm text-slate-600">{error}</p>
        <Link href="/examens-blancs" className="btn btn-outline">Retour aux examens blancs</Link>
      </div>
    );
  }

  if (!exam) return null;

  if (phase === "intro") {
    return (
      <div className="section">
        <div className="nav-container mx-auto max-w-3xl space-y-6">
          <div className="card space-y-5 p-6 sm:p-8">
            <div>
              <span className="badge badge-gold">{exam.isWhitePaper ? "Examen blanc d'entraînement" : "Examen interactif"}</span>
              <h1 className="mt-3 text-2xl font-extrabold text-nova-navy sm:text-3xl">{exam.title}</h1>
              <p className="mt-1 text-sm text-slate-500">
                {exam.subjectName ?? ""} · {exam.questionCount} question(s) · {exam.durationMinutes} min · note max {exam.maxScore} · seuil {exam.passingScore}
              </p>
            </div>
            {exam.description ? <p className="text-sm text-slate-600">{exam.description}</p> : null}

            {questions.length === 0 ? (
              <p className="text-sm text-slate-500">Aucune question configurée pour cet examen.</p>
            ) : null}

            <ul className="grid gap-3 sm:grid-cols-3 text-sm text-slate-600">
              <li>✍️ Répondez à toutes les questions.</li>
              <li>⏱️ Chronomètre : {exam.durationMinutes} minutes.</li>
              <li>✅ Correction et explications après soumission.</li>
            </ul>

            {exam.isWhitePaper ? (
              <p className="rounded-lg bg-amber-50 p-3 text-xs text-amber-800">
                ⚠️ Les examens blancs sont des entraînements et ne constituent pas des résultats officiels.
              </p>
            ) : null}

            {!exam.questionCount ? null : (
              <div className="flex flex-wrap gap-3">
                <button type="button" onClick={() => void start()} className="btn btn-navy">Commencer l'examen</button>
                <Link href="/examens-blancs" className="btn btn-outline">Annuler</Link>
              </div>
            )}

            {!exam.questionCount ? null : (
              <p className="text-xs text-slate-500">
                Vous n'êtes pas connecté ?{" "}
                <Link href="/connexion" className="font-semibold text-nova-blue underline">Connectez-vous</Link> pour
                sauvegarder vos résultats.
              </p>
            )}
          </div>
        </div>
      </div>
    );
  }

  const current = questions[index];

  if (phase === "running" && current) {
    return (
      <div className="section">
        <div className="nav-container mx-auto max-w-3xl space-y-5">
          <div className="card flex flex-wrap items-center justify-between gap-3 p-4">
            <div>
              <h1 className="font-bold text-nova-navy">{exam.title}</h1>
              <p className="text-xs text-slate-500">
                Question {index + 1} / {questions.length} · {answeredCount} réponse(s) enregistrée(s)
              </p>
            </div>
            <div className="flex items-center gap-3">
              <span className={`badge ${remaining < 60 ? "badge-red" : "badge-navy"}`}>⏱ {formatTime(remaining)}</span>
              <button type="button" onClick={() => void submit(false)} className="btn btn-gold btn-sm">
                {submitting ? "Soumission…" : "Soumettre"}
              </button>
            </div>
          </div>

          <div className="card space-y-5 p-6">
            <div className="flex items-start justify-between gap-4">
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-nova-blue/10 font-bold text-nova-navy">
                {index + 1}
              </div>
              <p className="font-semibold text-nova-navy">{current.prompt}</p>
            </div>

            {current.questionType === "mcq" && current.options.length > 0 ? (
              <div className="space-y-3">
                {current.options.map((opt, i) => {
                  const selected = answers[current.id] === String(i);
                  return (
                    <label
                      key={i}
                      className={`flex cursor-pointer items-center gap-3 rounded-xl border p-4 transition-colors ${
                        selected ? "border-nova-gold bg-nova-gold/8" : "border-slate-200 hover:border-nova-blue/40"
                      }`}
                    >
                      <input
                        type="radio"
                        name={`q-${current.id}`}
                        checked={selected}
                        onChange={() => setAnswers((a) => ({ ...a, [current.id]: String(i) }))}
                        className="h-4 w-4 accent-nova-navy"
                      />
                      <span className="font-medium text-slate-700">
                        {String.fromCharCode(65 + i)}. {opt.text}
                      </span>
                    </label>
                  );
                })}
              </div>
            ) : (
              <textarea
                className="textarea"
                value={answers[current.id] ?? ""}
                onChange={(e) => setAnswers((a) => ({ ...a, [current.id]: e.target.value }))}
                placeholder="Votre réponse…"
              />
            )}

            {current.imagePath ? (
              <img src={current.imagePath} alt="Illustration de la question" className="max-h-72 rounded-xl object-contain" />
            ) : null}

            <p className="text-xs text-slate-500">{current.points} point(s) · {current.questionType === "mcq" ? "Question à choix multiples" : "Réponse courte"}</p>

            <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 pt-4">
              <button
                type="button"
                onClick={() => setIndex((i) => Math.max(0, i - 1))}
                disabled={index === 0}
                className="btn btn-outline btn-sm"
              >
                ← Précédente
              </button>
              {index < questions.length - 1 ? (
                <button type="button" onClick={() => setIndex((i) => Math.min(questions.length - 1, i + 1))} className="btn btn-navy btn-sm">
                  Suivante →
                </button>
              ) : (
                <button type="button" onClick={() => void submit(false)} className="btn btn-gold btn-sm">
                  {submitting ? "Soumission…" : "Terminer et soumettre"}
                </button>
              )}
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            {questions.map((q, i) => (
              <button
                key={q.id}
                type="button"
                onClick={() => setIndex(i)}
                className={`h-9 w-9 rounded-lg text-sm font-semibold ${
                  i === index ? "bg-nova-navy text-white" : answers[q.id] ? "bg-nova-gold/25 text-nova-navy" : "bg-slate-200 text-slate-600"
                }`}
              >
                {i + 1}
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (phase === "result" && result && exam) {
    const scoreColor = result.percent >= exam.passingScore ? "text-green-600" : "text-red-600";
    return (
      <div className="section">
        <div className="nav-container mx-auto max-w-4xl space-y-6">
          <div className={`card space-y-4 p-6 text-center sm:p-8 gradient-navy text-white`}>
            <span className="badge badge-gold">Examen soumis</span>
            <p className="text-sm text-white/70">{exam.title}</p>
            <div className="text-5xl font-extrabold">
              {result.percent}<span className="text-2xl">%</span>
            </div>
            <p className={`text-sm font-semibold ${scoreColor === "text-green-600" ? "text-nova-gold-light" : "text-red-300"}`}>
              {result.passed ? "✅ Réussi (seuil : " + result.passingScore + " %)" : "❌ Non atteint (seuil : " + result.passingScore + " %)"}
            </p>
            <p className="text-sm text-white/75">
              Note obtenue : {result.score} / {result.maxScore}
            </p>
            <p className="mx-auto max-w-2xl text-sm text-white/85">{result.feedback}</p>
            {result.notice ? <p className="text-xs text-amber-200">⚠️ {result.notice}</p> : null}
            <div className="flex flex-wrap justify-center gap-3">
              <button type="button" onClick={() => { setResult(null); setAnswers({}); setPhase("intro"); }} className="btn btn-gold btn-sm">
                Recommencer
              </button>
              <Link href="/examens-blancs" className="btn btn-outline btn-sm">Voir les autres examens</Link>
              <Link href="/espace" className="btn btn-ghost btn-sm text-white hover:bg-white/10">Mon espace</Link>
            </div>
          </div>

          <div className="space-y-4">
            <h2 className="text-xl font-bold text-nova-navy">Détail des réponses</h2>
            {result.details.map((d, i) => (
              <div key={d.id} className={`card p-5 ${d.correct ? "" : "border-red-200"}`}>
                <div className="flex items-start justify-between gap-3">
                  <h3 className="font-bold text-nova-navy">{i + 1}. {d.prompt}</h3>
                  <span className={`badge ${d.correct ? "badge-green" : "badge-red"}`}>
                    {d.correct ? `✓ ${d.earned}/${d.points}` : `✗ 0/${d.points}`}
                  </span>
                </div>
                {d.questionType === "mcq" ? (
                  <p className="mt-3 text-sm text-slate-600">
                    Votre réponse : <span className="font-semibold">{d.userAnswer ?? "—"}</span>
                  </p>
                ) : (
                  <div className="mt-3 grid gap-1 text-sm">
                    <p className="text-slate-600">Votre réponse : <span className="font-semibold">{d.userAnswer ?? "—"}</span></p>
                  </div>
                )}
                <p className="mt-2 text-sm">
                  Réponse correcte :{" "}
                  <span className="font-semibold text-green-700">{d.correctAnswer ?? "—"}</span>
                </p>
                {d.explanation ? (
                  <p className="mt-2 rounded-lg bg-slate-50 p-3 text-sm text-slate-600">💡 {d.explanation}</p>
                ) : null}
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return null;
}
