"use client";

import { useState } from "react";

export default function FavoriteButton({ examId }: { examId: string }) {
  const [favorite, setFavorite] = useState(false);
  const [loading, setLoading] = useState(false);

  async function toggle(e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    setLoading(true);
    const res = await fetch("/api/favorites", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ examId }),
    });
    const data = await res.json();
    setLoading(false);
    if (res.ok && data.ok) {
      setFavorite(Boolean(data.favorite));
    }
  }

  return (
    <button
      type="button"
      onClick={(e) => void toggle(e)}
      disabled={loading}
      className={`btn btn-sm ${favorite ? "btn-gold" : "btn-outline"}`}
      aria-pressed={favorite}
      title={favorite ? "Retirer des favoris" : "Ajouter aux favoris"}
    >
      {favorite ? "★ Favori" : "☆ Favori"}
    </button>
  );
}
