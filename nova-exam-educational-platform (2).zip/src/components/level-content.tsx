import Link from "next/link";
import clsx from "clsx";
import { LogoMark } from "@/components/brand";

export type SubjectItem = {
  id: string;
  code: string;
  name: string;
  description: string | null;
  icon: string | null;
  color: string;
  position: number;
};

export type ExamItem = {
  id: string;
  title: string;
  description: string | null;
  year: number | null;
  examType: string;
  hasCorrection: boolean;
  filePath: string | null;
  isOfficial: boolean;
  subjectId: string | null;
  subjectName: string | null;
  levelName: string | null;
  createdAt: Date;
};

export type InteractiveItem = {
  id: string;
  title: string;
  description: string | null;
  durationMinutes: number;
  maxScore: number;
  isWhitePaper: boolean;
  subjectName: string | null;
};

export type ResourceItem = {
  id: string;
  title: string;
  summary: string | null;
  resourceType: string;
  filePath: string | null;
  subjectName: string | null;
  createdAt: Date;
};

const TYPE_LABEL: Record<string, string> = {
  fiche: "Fiches de révision",
  resume: "Résumés",
  correction: "Corrigés",
  pdf: "Documents PDF",
};

export function SubjectCard({ subject, examCount }: { subject: SubjectItem; examCount?: number }) {
  return (
    <Link
      href={`/ressources?matiere=${subject.id}`}
      className="card card-hover flex flex-col gap-3 p-5"
    >
      <div className="flex items-center gap-3">
        <span
          className="flex h-11 w-11 items-center justify-center rounded-xl text-lg"
          style={{ backgroundColor: `${subject.color}1a`, color: subject.color }}
        >
          {subject.icon ?? "📚"}
        </span>
        <h3 className="font-bold text-nova-navy">{subject.name}</h3>
      </div>
      <p className="text-sm text-slate-600 line-clamp-3">
        {subject.description ?? "Fiches, résumés, exercices, corrigés et examens blancs disponibles gratuitement."}
      </p>
      <div className="mt-auto flex items-center justify-between pt-2">
        <span className="badge badge-gold">{TYPE_LABEL.fiche} · {TYPE_LABEL.resume} · {TYPE_LABEL.correction}</span>
        {examCount !== undefined ? (
          <span className="badge badge-gray">{examCount} examen</span>
        ) : null}
      </div>
    </Link>
  );
}

export function SubjectGrid({ subjects, exams }: { subjects: SubjectItem[]; exams?: ExamItem[] }) {
  return (
    <div className="grid-cards">
      {subjects.map((s) => (
        <SubjectCard
          key={s.id}
          subject={s}
          examCount={exams ? exams.filter((e) => e.subjectId === s.id).length : undefined}
        />
      ))}
    </div>
  );
}

export function ExamCard({ exam }: { exam: ExamItem }) {
  const typeLabel = exam.examType === "blanc" ? "Examen blanc" : "Examen précédent";
  return (
    <div className="card card-hover flex flex-col gap-3 p-5">
      <div className="flex flex-wrap items-center gap-2">
        <span className="badge badge-navy">{typeLabel}</span>
        {exam.year ? <span className="badge badge-gray">{exam.year}</span> : null}
        {exam.hasCorrection ? <span className="badge badge-green">Corrigé disponible</span> : null}
        {exam.isOfficial ? <span className="badge badge-gold">Document officiel</span> : null}
      </div>
      <h3 className="font-bold text-nova-navy">{exam.title}</h3>
      <p className="text-sm text-slate-600 line-clamp-3">{exam.description ?? "—"}</p>
      <div className="mt-auto flex flex-wrap items-center gap-2 pt-2 text-xs text-slate-500">
        {exam.subjectName ? <span>{exam.subjectName}</span> : null}
        {exam.levelName ? <span>· {exam.levelName}</span> : null}
        <Link href={`/examens/${exam.id}`} className="btn btn-outline btn-sm">
          Voir détails
        </Link>
        {exam.filePath ? (
          <a href={exam.filePath} download className="btn btn-gold btn-sm">
            Télécharger ⬇
          </a>
        ) : (
          <span className="badge badge-gray">Aucun PDF</span>
        )}
      </div>
    </div>
  );
}

export function InteractiveCard({ exam }: { exam: InteractiveItem }) {
  return (
    <div className="card card-hover flex flex-col gap-3 p-5">
      <div className="flex flex-wrap items-center gap-2">
        <span className="badge badge-gold">Examen blanc interactif</span>
        <span className="badge badge-gray">{exam.durationMinutes} min</span>
        <span className="badge badge-navy">Note max : {exam.maxScore}</span>
      </div>
      <h3 className="font-bold text-nova-navy">{exam.title}</h3>
      <p className="text-sm text-slate-600 line-clamp-3">{exam.description ?? "—"}</p>
      <div className="mt-auto flex flex-wrap items-center gap-2 pt-2 text-xs text-slate-500">
        {exam.subjectName ? <span>{exam.subjectName}</span> : null}
        <Link href={`/examens-blancs/passer/${exam.id}`} className="btn btn-navy btn-sm">
          Commencer
        </Link>
      </div>
    </div>
  );
}

export function ResourceCard({ resource }: { resource: ResourceItem }) {
  return (
    <div className="card card-hover flex flex-col gap-3 p-5">
      <div className="flex flex-wrap items-center gap-2">
        <span className="badge badge-navy">{TYPE_LABEL[resource.resourceType] ?? resource.resourceType}</span>
        {resource.subjectName ? <span className="badge badge-gray">{resource.subjectName}</span> : null}
      </div>
      <h3 className="font-bold text-nova-navy">{resource.title}</h3>
      <p className="text-sm text-slate-600 line-clamp-3">{resource.summary ?? "—"}</p>
      <div className="mt-auto flex flex-wrap items-center gap-2 pt-2">
        <Link href={`/ressources/${resource.id}`} className="btn btn-outline btn-sm">
          Lire
        </Link>
        {resource.filePath ? (
          <a href={resource.filePath} download className="btn btn-gold btn-sm">
            Télécharger ⬇
          </a>
        ) : null}
      </div>
    </div>
  );
}

export function LevelHeader({
  levelCode,
  name,
  description,
  accent = "navy",
}: {
  levelCode: string;
  name: string;
  description: string | null;
  accent?: "navy" | "gold";
}) {
  return (
    <section className={clsx("section", accent === "gold" ? "bg-white" : "gradient-navy text-white")}>
      <div className="nav-container">
        <div className="flex items-center gap-3">
          <LogoMark className={clsx("h-12 w-12", accent === "gold" ? "" : "ring-2 ring-nova-gold/40")} />
          <div>
            <p className={clsx("text-xs font-semibold uppercase tracking-[0.2em]", accent === "gold" ? "text-nova-gold" : "text-nova-gold-light")}>
              {levelCode.toUpperCase()}
            </p>
            <h2 className="text-2xl font-extrabold sm:text-3xl">{name}</h2>
          </div>
        </div>
        <p className={clsx("mt-4 max-w-3xl text-sm sm:text-base", accent === "gold" ? "text-slate-600" : "text-white/75")}>
          {description ?? "Toutes les ressources de ce niveau sont publiées gratuitement."}
        </p>
      </div>
    </section>
  );
}
