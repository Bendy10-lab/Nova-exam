"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

type Level = { id: string; code: string; name: string };
type Series = { id: string; code: string; name: string };
type User = { id: string; nom: string; email: string; niveau: string | null; serie: string | null; createdAt: Date };

export function ProfileForm({ user, levels, series }: { user: User; levels: Level[]; series: Series[] }) {
  const router = useRouter();
  const [nom, setNom] = useState(user.nom);
  const [niveau, setNiveau] = useState(user.niveau ?? "");
  const [serie, setSerie] = useState(user.serie ?? "");
  const [error, setError] = useState("");
  const [ok, setOk] = useState("");
  const [sending, setSending] = useState(false);

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError("");
    setOk("");
    if (nom.trim().length < 2) return setError("Le nom complet est obligatoire.");
    setSending(true);
    const res = await fetch("/api/auth", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "updateProfile", nom, niveau: niveau || null, serie: serie || null }),
    });
    const data = await res.json();
    setSending(false);
    if (!res.ok || !data.ok) {
      setError(data.error ?? "Impossible de mettre à jour le profil.");
      return;
    }
    setOk("Profil mis à jour.");
    router.refresh();
  }

  return (
    <form onSubmit={submit} className="card space-y-4 p-6 sm:p-8">
      <h1 className="text-2xl font-extrabold text-nova-navy">Mon profil</h1>
      <div className="grid gap-4 sm:grid-cols-2">
        <label className="field">
          <span className="label">Nom complet</span>
          <input className="input" value={nom} onChange={(e) => setNom(e.target.value)} />
        </label>
        <label className="field">
          <span className="label">Adresse e-mail</span>
          <input className="input" value={user.email} disabled />
          <span className="hint">L'e-mail ne peut pas être modifié pour garantir la sécurité du compte.</span>
        </label>
        <label className="field">
          <span className="label">Niveau scolaire</span>
          <select className="select" value={niveau} onChange={(e) => { setNiveau(e.target.value); setSerie(""); }}>
            <option value="">Choisir…</option>
            {levels.map((l) => (
              <option key={l.id} value={l.code}>{l.name}</option>
            ))}
          </select>
        </label>
        <label className="field">
          <span className="label">Série</span>
          <select className="select" value={serie} onChange={(e) => setSerie(e.target.value)} disabled={!niveau}>
            <option value="">Choisir…</option>
            {series.map((s) => (
              <option key={s.id} value={s.code}>{s.name}</option>
            ))}
          </select>
        </label>
      </div>
      <p className="text-xs text-slate-500">
        Compte créé le {new Date(user.createdAt).toLocaleDateString("fr-FR")}.
      </p>
      {error ? <p className="text-sm font-medium text-red-600">{error}</p> : null}
      {ok ? <p className="text-sm font-medium text-green-600">{ok}</p> : null}
      <button type="submit" disabled={sending} className="btn btn-navy">{sending ? "Enregistrement…" : "Enregistrer"}</button>
    </form>
  );
}

export function PasswordForm() {
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");
  const [ok, setOk] = useState("");
  const [sending, setSending] = useState(false);

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError("");
    setOk("");
    if (next.length < 8) return setError("Le mot de passe doit contenir au moins 8 caractères.");
    if (next !== confirm) return setError("Les deux mots de passe ne correspondent pas.");
    setSending(true);
    const res = await fetch("/api/auth", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "changePassword", current, next }),
    });
    const data = await res.json();
    setSending(false);
    if (!res.ok || !data.ok) {
      setError(data.error ?? "Modification impossible.");
      return;
    }
    setOk(data.message ?? "Mot de passe modifié.");
    setCurrent("");
    setNext("");
    setConfirm("");
  }

  return (
    <form onSubmit={submit} className="card space-y-4 p-6 sm:p-8">
      <h1 className="text-2xl font-extrabold text-nova-navy">Changer le mot de passe</h1>
      <p className="text-sm text-slate-600">Votre mot de passe est stocké sous forme de hachage sécurisé. Vous restez connecté.</p>
      <label className="field">
        <span className="label">Mot de passe actuel</span>
        <input className="input" type="password" value={current} onChange={(e) => setCurrent(e.target.value)} autoComplete="current-password" />
      </label>
      <label className="field">
        <span className="label">Nouveau mot de passe</span>
        <input className="input" type="password" value={next} onChange={(e) => setNext(e.target.value)} autoComplete="new-password" />
      </label>
      <label className="field">
        <span className="label">Confirmer le nouveau mot de passe</span>
        <input className="input" type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} autoComplete="new-password" />
      </label>
      {error ? <p className="text-sm font-medium text-red-600">{error}</p> : null}
      {ok ? <p className="text-sm font-medium text-green-600">{ok}</p> : null}
      <button type="submit" disabled={sending} className="btn btn-navy">{sending ? "Modification…" : "Modifier"}</button>
    </form>
  );
}
