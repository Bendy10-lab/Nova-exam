"use client";

import Link from "next/link";
import { useState } from "react";

export type PromotionCardProps = {
  id: string;
  name: string;
  logoPath: string | null;
  shortDescription: string | null;
  description: string | null;
  category: string | null;
  websiteUrl: string | null;
  downloadUrl: string | null;
  buttonText: string;
};

/** Carte de promotion. Le clic est enregistré côté serveur (sans données personnelles). */
export function PromotionCard({ promo }: { promo: PromotionCardProps }) {
  const [clicked, setClicked] = useState(false);
  const url = promo.websiteUrl || promo.downloadUrl || null;

  async function trackClick() {
    if (clicked) return;
    setClicked(true);
    try {
      await fetch(`/api/promotions/${promo.id}/click`, { method: "POST" });
    } catch {
      setClicked(false);
    }
  }

  if (!url) {
    return (
      <div className="card card-hover flex flex-col gap-3 p-5">
        <div className="flex items-center gap-3">
          {promo.logoPath ? (
            <img src={promo.logoPath} alt={promo.name} className="h-12 w-12 rounded-xl object-cover" />
          ) : (
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-nova-navy text-nova-gold-light font-bold">
              {promo.name.slice(0, 2).toUpperCase()}
            </div>
          )}
          <div>
            <h3 className="font-bold text-nova-navy">{promo.name}</h3>
            {promo.category ? <span className="badge badge-gray">{promo.category}</span> : null}
          </div>
        </div>
        <p className="text-sm text-slate-600">{promo.shortDescription ?? promo.description}</p>
        <span className="badge badge-gray mt-auto">Lien non configuré</span>
      </div>
    );
  }

  const isDownload = promo.downloadUrl && url === promo.downloadUrl;

  return (
    <div className="card card-hover flex flex-col gap-3 p-5">
      <div className="flex items-center gap-3">
        {promo.logoPath ? (
          <img src={promo.logoPath} alt={promo.name} className="h-12 w-12 rounded-xl object-cover" />
        ) : (
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-nova-navy text-nova-gold-light font-bold">
            {promo.name.slice(0, 2).toUpperCase()}
          </div>
        )}
        <div>
          <h3 className="font-bold text-nova-navy">{promo.name}</h3>
          {promo.category ? <span className="badge badge-gray">{promo.category}</span> : null}
        </div>
      </div>
      <p className="text-sm text-slate-600">{promo.shortDescription ?? promo.description}</p>
      <div className="mt-auto flex flex-wrap items-center gap-2">
        <a
          href={url}
          target="_blank"
          rel="noreferrer noopener"
          onClick={() => void trackClick()}
          className="btn btn-navy btn-sm"
        >
          {promo.buttonText || "Visiter"}
          {isDownload ? " ⬇" : " ↗"}
        </a>
      </div>
    </div>
  );
}

export default function PromotionList({ promos }: { promos: PromotionCardProps[] }) {
  if (!promos || promos.length === 0) return null;
  return (
    <div className="grid-cards">
      {promos.map((p) => (
        <PromotionCard key={p.id} promo={p} />
      ))}
    </div>
  );
}

export function PromoLinkButton({
  promo,
}: {
  promo: { id: string; buttonText: string; websiteUrl: string | null; downloadUrl: string | null; name: string };
}) {
  const [clicked, setClicked] = useState(false);
  const url = promo.websiteUrl || promo.downloadUrl;
  if (!url) return null;
  return (
    <Link
      href={url}
      target="_blank"
      rel="noreferrer noopener"
      onClick={() => {
        if (clicked) return;
        setClicked(true);
        void fetch(`/api/promotions/${promo.id}/click`, { method: "POST" });
      }}
      className="btn btn-gold btn-sm"
    >
      {promo.buttonText || "Visiter"} ↗
    </Link>
  );
}
