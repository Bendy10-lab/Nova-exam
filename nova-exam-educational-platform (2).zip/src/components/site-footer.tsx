import Link from "next/link";
import { LogoMark } from "@/components/brand";
import { getPublicPromotions } from "@/lib/content";
import { publicSettings } from "@/lib/settings";
import { getSettings } from "@/lib/settings";

export default async function SiteFooter() {
  const s = publicSettings(await getSettings());
  const promos = await getPublicPromotions("footer");

  return (
    <footer className="gradient-navy text-white/80">
      <div className="nav-container py-12">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-4">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <LogoMark className="h-10 w-10" />
              <div className="leading-tight">
                <div className="font-extrabold text-white">
                  NOVA<span className="gold-text"> EXAM</span>
                </div>
                <div className="text-[0.62rem] uppercase tracking-[0.22em] text-white/55">
                  Préparation des examens officiels
                </div>
              </div>
            </div>
            <p className="text-sm text-white/70">{s.description}</p>
            {s.whatsapp ? (
              <a
                href={`https://wa.me/${s.whatsapp.replace(/^\+/, "")}`}
                target="_blank"
                rel="noreferrer"
                className="btn btn-gold btn-sm"
              >
                💬 WhatsApp : {s.whatsapp}
              </a>
            ) : null}
          </div>

          <div className="space-y-3">
            <h4 className="font-semibold text-white">Explorer</h4>
            <ul className="space-y-2 text-sm">
              <li><Link href="/niveau/9em" className="hover:text-nova-gold-light">9ème année fondamentale</Link></li>
              <li><Link href="/niveau/ns4" className="hover:text-nova-gold-light">NS4</Link></li>
              <li><Link href="/examens" className="hover:text-nova-gold-light">Examens précédents</Link></li>
              <li><Link href="/examens-blancs" className="hover:text-nova-gold-light">Examens blancs</Link></li>
              <li><Link href="/ressources" className="hover:text-nova-gold-light">Ressources gratuites</Link></li>
            </ul>
          </div>

          <div className="space-y-3">
            <h4 className="font-semibold text-white">Compte</h4>
            <ul className="space-y-2 text-sm">
              <li><Link href="/inscription" className="hover:text-nova-gold-light">Inscription gratuite</Link></li>
              <li><Link href="/connexion" className="hover:text-nova-gold-light">Connexion</Link></li>
              <li><Link href="/espace" className="hover:text-nova-gold-light">Espace élève</Link></li>
              <li><Link href="/plateformes" className="hover:text-nova-gold-light">Nos plateformes</Link></li>
              <li><Link href="/contact" className="hover:text-nova-gold-light">Contact & assistance</Link></li>
            </ul>
          </div>

          <div className="space-y-3">
            <h4 className="font-semibold text-white">Informations</h4>
            <ul className="space-y-2 text-sm">
              <li><Link href="/a-propos" className="hover:text-nova-gold-light">À propos</Link></li>
              <li><Link href="/contact" className="hover:text-nova-gold-light">Questions fréquentes</Link></li>
              <li><Link href="/contact" className="hover:text-nova-gold-light">Signaler une erreur</Link></li>
              <li>
                Contact : <span className="text-white/70">{s.contactEmail}</span>
              </li>
            </ul>
          </div>
        </div>

        {promos.length > 0 ? (
          <div className="mt-10 border-t border-white/15 pt-8">
            <h4 className="font-semibold text-white">Découvrez aussi nos autres plateformes</h4>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 mt-4">
              {promos.map((p) => (
                <a
                  key={p.id}
                  href={p.websiteUrl ?? p.downloadUrl ?? "#"}
                  target="_blank"
                  rel="noreferrer noopener"
                  className="flex items-center gap-3 rounded-xl bg-white/8 p-3 transition-colors hover:bg-white/15"
                >
                  {p.logoPath ? (
                    <img src={p.logoPath} alt={p.name} className="h-9 w-9 rounded-lg object-cover" />
                  ) : (
                    <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-white/15 font-bold text-nova-gold-light">
                      {p.name.slice(0, 2).toUpperCase()}
                    </span>
                  )}
                  <span className="text-sm font-medium text-white">{p.name}</span>
                </a>
              ))}
            </div>
          </div>
        ) : null}

        <div className="mt-10 flex flex-col items-center justify-between gap-3 border-t border-white/15 pt-6 text-xs text-white/55 sm:flex-row">
          <p>
            © {new Date().getFullYear()} {s.siteName} — {s.address || "Haïti"}. Plateforme éducative 100 % gratuite.
          </p>
          <p>Créée par {s.founderName} — {s.founderTitle}</p>
        </div>
      </div>
    </footer>
  );
}
