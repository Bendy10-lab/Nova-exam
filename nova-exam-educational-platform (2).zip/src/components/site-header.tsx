"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState } from "react";
import { Logo } from "@/components/brand";
import type { SafeUser } from "@/lib/auth";

const NAV = [
  { href: "/", label: "Accueil" },
  { href: "/niveau/9em", label: "9ème" },
  { href: "/niveau/ns4", label: "NS4" },
  { href: "/examens", label: "Examens" },
  { href: "/examens-blancs", label: "Examens blancs" },
  { href: "/ressources", label: "Ressources" },
  { href: "/plateformes", label: "Plateformes" },
  { href: "/a-propos", label: "À propos" },
  { href: "/contact", label: "Contact" },
];

export default function SiteHeader({
  user,
  whatsapp,
}: {
  user: SafeUser | null;
  whatsapp: string;
}) {
  const pathname = usePathname();
  const router = useRouter();
  const [menuOpen, setMenuOpen] = useState(false);

  const isAdmin = user?.role === "administrateur" || user?.role === "super_administrateur";

  async function logout() {
    await fetch("/api/auth", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "logout" }),
    });
    router.push("/");
    router.refresh();
  }

  const visibleLinks = NAV.filter((l) => l.href !== "/");

  return (
    <header className="sticky top-0 z-50 border-b border-slate-200 bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/85">
      <div className="nav-container flex h-[62px] items-center justify-between gap-3">
        <Link href="/" className="shrink-0" aria-label="NOVA EXAM — Accueil">
          <Logo />
        </Link>

        <nav className="hidden items-center gap-1 lg:flex">
          {visibleLinks.map((link) => {
            const active = pathname === link.href || pathname.startsWith(`${link.href}/`);
            return (
              <Link
                key={link.href}
                href={link.href}
                className={`rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
                  active ? "bg-nova-blue/10 text-nova-navy" : "text-slate-600 hover:bg-slate-100 hover:text-nova-navy"
                }`}
              >
                {link.label}
              </Link>
            );
          })}
        </nav>

        <div className="hidden items-center gap-2 lg:flex">
          {user ? (
            <>
              <Link href="/espace" className="btn btn-outline btn-sm">
                Espace élève
              </Link>
              {isAdmin ? (
                <Link href="/administrateur" className="btn btn-gold btn-sm">
                   Administrateur
                </Link>
              ) : null}
              <button type="button" onClick={logout} className="btn btn-ghost btn-sm">
                Déconnexion
              </button>
            </>
          ) : (
            <>
              <Link href="/connexion" className="btn btn-outline btn-sm">
                Se connecter
              </Link>
              <Link href="/inscription" className="btn btn-gold btn-sm">
                Créer un compte
              </Link>
            </>
          )}
        </div>

        <div className="flex items-center gap-2 lg:hidden">
          {user ? (
            <Link href="/espace" className="btn btn-navy btn-sm">
              Mon espace
            </Link>
          ) : (
            <Link href="/inscription" className="btn btn-gold btn-sm">
              Compte
            </Link>
          )}
          <button
            type="button"
            onClick={() => setMenuOpen((v) => !v)}
            className="rounded-lg border border-slate-300 p-2 text-nova-navy"
            aria-label="Menu"
            aria-expanded={menuOpen}
          >
            <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M4 7h16M4 12h16M4 17h16" strokeLinecap="round" />
            </svg>
          </button>
        </div>
      </div>

      {menuOpen ? (
        <div className="border-t border-slate-200 bg-white lg:hidden">
          <div className="nav-container space-y-3 py-4">
            {visibleLinks.map((link) => {
              const active = pathname === link.href || pathname.startsWith(`${link.href}/`);
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  onClick={() => setMenuOpen(false)}
                  className={`block rounded-lg px-3 py-2.5 text-sm font-medium ${
                    active ? "bg-nova-blue/10 text-nova-navy" : "text-slate-700"
                  }`}
                >
                  {link.label}
                </Link>
              );
            })}
            <div className="grid grid-cols-1 gap-2 pt-2">
              {user ? (
                <>
                  <Link href="/espace" onClick={() => setMenuOpen(false)} className="btn btn-outline btn-block btn-sm">
                    Espace élève
                  </Link>
                  {isAdmin ? (
                    <Link href="/administrateur" onClick={() => setMenuOpen(false)} className="btn btn-gold btn-block btn-sm">
                      Administrateur
                    </Link>
                  ) : null}
                  <button type="button" onClick={() => { setMenuOpen(false); void logout(); }} className="btn btn-ghost btn-block btn-sm">
                    Déconnexion
                  </button>
                </>
              ) : (
                <>
                  <Link href="/connexion" onClick={() => setMenuOpen(false)} className="btn btn-outline btn-block btn-sm">
                    Se connecter
                  </Link>
                  <Link href="/inscription" onClick={() => setMenuOpen(false)} className="btn btn-gold btn-block btn-sm">
                    Créer un compte
                  </Link>
                </>
              )}
            </div>
          </div>
        </div>
      ) : null}

      {whatsapp ? (
        <div className="border-t border-nova-gold/30 bg-nova-gold/10">
          <div className="nav-container flex items-center justify-between gap-3 py-2 text-xs text-nova-navy">
            <span className="font-medium">Assistance WhatsApp disponible</span>
            <a
              href={`https://wa.me/${whatsapp.replace(/^\+/, "")}`}
              target="_blank"
              rel="noreferrer"
              className="font-semibold underline underline-offset-2"
            >
              Chat maintenant
            </a>
          </div>
        </div>
      ) : null}
    </header>
  );
}
