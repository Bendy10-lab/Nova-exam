import {
  boolean,
  index,
  integer,
  jsonb,
  pgTable,
  real,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

/**
 * Schéma de la base de données de NOVA EXAM.
 * Toutes les tables sont persistées dans PostgreSQL.
 */

// ---------------------------------------------------------------------------
// Niveaux scolaires & séries
// ---------------------------------------------------------------------------

export const levels = pgTable(
  "levels",
  {
    id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
    code: text("code").notNull().unique(),
    name: text("name").notNull(),
    description: text("description"),
    position: integer("position").notNull().default(0),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("levels_position_idx").on(t.position)],
);

export const series = pgTable(
  "series",
  {
    id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
    code: text("code").notNull(),
    name: text("name").notNull(),
    levelId: text("level_id").references(() => levels.id, { onDelete: "cascade" }),
    position: integer("position").notNull().default(0),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("series_level_idx").on(t.levelId), index("series_position_idx").on(t.position)],
);

// ---------------------------------------------------------------------------
// Utilisateurs & profils
// ---------------------------------------------------------------------------

export const users = pgTable(
  "users",
  {
    id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
    email: text("email").notNull().unique(),
    passwordHash: text("password_hash").notNull(),
    role: text("role").notNull().default("eleve"), // eleve | administrateur | super_administrateur
    nom: text("nom").notNull(),
    niveau: text("niveau"), // code du niveau
    serie: text("serie"), // code de la série
    isActive: boolean("is_active").notNull().default(true),
    emailVerified: boolean("email_verified").notNull().default(false),
    resetToken: text("reset_token"),
    resetExpires: timestamp("reset_expires", { withTimezone: true }),
    lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("users_email_idx").on(t.email), index("users_role_idx").on(t.role)],
);

export const profiles = pgTable(
  "profiles",
  {
    id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
    userId: text("user_id")
      .references(() => users.id, { onDelete: "cascade" })
      .unique()
      .notNull(),
    avatarPath: text("avatar_path"),
    bio: text("bio"),
    preferences: jsonb("preferences").default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
);

// ---------------------------------------------------------------------------
// Matières & contenus pédagogiques
// ---------------------------------------------------------------------------

export const subjects = pgTable(
  "subjects",
  {
    id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
    code: text("code").notNull(),
    name: text("name").notNull(),
    description: text("description"),
    levelId: text("level_id").references(() => levels.id, { onDelete: "cascade" }),
    color: text("color").notNull().default("#1e3a8a"),
    icon: text("icon"),
    position: integer("position").notNull().default(0),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("subjects_level_idx").on(t.levelId), index("subjects_position_idx").on(t.position)],
);

/** Fiches de révision, résumés, corrigés, documents PDF pédagogiques. */
export const resources = pgTable(
  "resources",
  {
    id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
    subjectId: text("subject_id")
      .references(() => subjects.id, { onDelete: "cascade" })
      .notNull(),
    levelId: text("level_id").references(() => levels.id, { onDelete: "cascade" }),
    title: text("title").notNull(),
    summary: text("summary"),
    content: text("content"),
    resourceType: text("resource_type").notNull().default("fiche"), // fiche | resume | correction | pdf
    filePath: text("file_path"),
    published: boolean("published").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("resources_subject_idx").on(t.subjectId), index("resources_published_idx").on(t.published)],
);

// ---------------------------------------------------------------------------
// Bibliothèque d'examens (examens précédents + examens blancs documents)
// ---------------------------------------------------------------------------

export const exams = pgTable(
  "exams",
  {
    id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
    title: text("title").notNull(),
    description: text("description"),
    levelId: text("level_id").references(() => levels.id, { onDelete: "cascade" }),
    serieId: text("serie_id").references(() => series.id, { onDelete: "set null" }),
    subjectId: text("subject_id").references(() => subjects.id, { onDelete: "cascade" }),
    year: integer("year"),
    examType: text("exam_type").notNull().default("precedent"), // precedent | blanc
    hasCorrection: boolean("has_correction").notNull().default(false),
    filePath: text("file_path"),
    correctionFilePath: text("correction_file_path"),
    isOfficial: boolean("is_official").notNull().default(false),
    published: boolean("published").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [
    index("exams_level_idx").on(t.levelId),
    index("exams_subject_idx").on(t.subjectId),
    index("exams_type_idx").on(t.examType),
    index("exams_published_idx").on(t.published),
  ],
);

/** Examens interactifs / blancs à correction automatique. */
export const interactiveExams = pgTable(
  "interactive_exams",
  {
    id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
    title: text("title").notNull(),
    description: text("description"),
    subjectId: text("subject_id").references(() => subjects.id, { onDelete: "cascade" }),
    levelId: text("level_id").references(() => levels.id, { onDelete: "cascade" }),
    serieId: text("serie_id").references(() => series.id, { onDelete: "set null" }),
    durationMinutes: integer("duration_minutes").notNull().default(30),
    maxScore: real("max_score").notNull().default(100),
    passingScore: real("passing_score").notNull().default(50),
    isWhitePaper: boolean("is_white_paper").notNull().default(true),
    published: boolean("published").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("ie_subject_idx").on(t.subjectId), index("ie_published_idx").on(t.published)],
);

export const questions = pgTable(
  "questions",
  {
    id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
    examId: text("exam_id")
      .references(() => interactiveExams.id, { onDelete: "cascade" })
      .notNull(),
    subjectId: text("subject_id").references(() => subjects.id, { onDelete: "set null" }),
    prompt: text("prompt").notNull(),
    questionType: text("question_type").notNull().default("mcq"), // mcq | short | image
    optionsJson: jsonb("options_json").default([] as unknown as object),
    correctIndex: integer("correct_index"),
    correctAnswer: text("correct_answer"),
    explanation: text("explanation"),
    imagePath: text("image_path"),
    points: integer("points").notNull().default(1),
    orderNo: integer("order_no").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("questions_exam_idx").on(t.examId), index("questions_order_idx").on(t.orderNo)],
);

/** Tentative d'examen enregistrée = résultat. */
export const attempts = pgTable(
  "attempts",
  {
    id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
    userId: text("user_id")
      .references(() => users.id, { onDelete: "cascade" })
      .notNull(),
    examId: text("exam_id").notNull(),
    examTitle: text("exam_title").notNull(),
    subjectId: text("subject_id"),
    startedAt: timestamp("started_at", { withTimezone: true }).defaultNow().notNull(),
    submittedAt: timestamp("submitted_at", { withTimezone: true }),
    durationSeconds: integer("duration_seconds"),
    score: real("score").notNull().default(0),
    maxScore: real("max_score").notNull().default(100),
    percent: real("percent").notNull().default(0),
    passed: boolean("passed").notNull().default(false),
    answersJson: jsonb("answers_json").default([] as unknown as object),
    feedback: text("feedback"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [
    index("attempts_user_idx").on(t.userId),
    index("attempts_exam_idx").on(t.examId),
    index("attempts_created_idx").on(t.createdAt),
  ],
);

/** Favorites / examens favoris. */
export const favorites = pgTable(
  "favorites",
  {
    id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
    userId: text("user_id")
      .references(() => users.id, { onDelete: "cascade" })
      .notNull(),
    examId: text("exam_id").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [
    index("favorites_user_idx").on(t.userId),
    index("favorites_exam_idx").on(t.examId),
    index("favorites_unique_idx").on(t.userId, t.examId),
  ],
);

/** Suivi de progression par matière. */
export const progress = pgTable(
  "progress",
  {
    id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
    userId: text("user_id")
      .references(() => users.id, { onDelete: "cascade" })
      .notNull(),
    subjectId: text("subject_id")
      .references(() => subjects.id, { onDelete: "cascade" })
      .notNull(),
    resourcesViewed: integer("resources_viewed").notNull().default(0),
    questionsAnswered: integer("questions_answered").notNull().default(0),
    correctAnswers: integer("correct_answers").notNull().default(0),
    lastActivityAt: timestamp("last_activity_at", { withTimezone: true }).defaultNow().notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [
    index("progress_user_idx").on(t.userId),
    index("progress_subject_idx").on(t.subjectId),
    index("progress_user_subject_idx").on(t.userId, t.subjectId),
  ],
);

// ---------------------------------------------------------------------------
// Annonces, promotions & clics
// ---------------------------------------------------------------------------

export const announcements = pgTable(
  "announcements",
  {
    id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
    title: text("title").notNull(),
    content: text("content").notNull(),
    published: boolean("published").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("announcements_published_idx").on(t.published)],
);

export const promotions = pgTable(
  "promotions",
  {
    id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
    name: text("name").notNull(),
    logoPath: text("logo_path"),
    shortDescription: text("short_description"),
    description: text("description"),
    category: text("category"),
    websiteUrl: text("website_url"),
    downloadUrl: text("download_url"),
    buttonText: text("button_text").default("Visiter"),
    startsAt: timestamp("starts_at", { withTimezone: true }),
    endsAt: timestamp("ends_at", { withTimezone: true }),
    status: text("status").notNull().default("brouillon"), // brouillon | publiee | desactivee
    position: integer("position").notNull().default(0),
    showOnHome: boolean("show_on_home").notNull().default(true),
    showInFooter: boolean("show_in_footer").notNull().default(false),
    showInDashboard: boolean("show_in_dashboard").notNull().default(false),
    clicks: integer("clicks").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("promotions_status_idx").on(t.status), index("promotions_position_idx").on(t.position)],
);

export const promotionClicks = pgTable(
  "promotion_clicks",
  {
    id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
    promotionId: text("promotion_id")
      .references(() => promotions.id, { onDelete: "cascade" })
      .notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("promo_clicks_promo_idx").on(t.promotionId)],
);

// ---------------------------------------------------------------------------
// Paramètres & journaux
// ---------------------------------------------------------------------------

export const settings = pgTable("settings", {
  key: text("key").primaryKey(),
  value: text("value"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const activityLogs = pgTable(
  "activity_logs",
  {
    id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
    userId: text("user_id").references(() => users.id, { onDelete: "set null" }),
    action: text("action").notNull(),
    detail: text("detail"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("logs_user_idx").on(t.userId), index("logs_created_idx").on(t.createdAt)],
);

export const schema = {
  users,
  profiles,
  levels,
  series,
  subjects,
  resources,
  exams,
  interactiveExams,
  questions,
  attempts,
  favorites,
  progress,
  announcements,
  promotions,
  promotionClicks,
  settings,
  activityLogs,
};
