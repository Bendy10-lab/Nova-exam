import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { NextRequest } from "next/server";
import { db } from "@/db";
import { users, settings } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import bcrypt from "bcryptjs";
import { SignJWT, jwtVerify } from "jose";

export const SESSION_COOKIE = "nova_session";
const SESSION_MAX_AGE = 60 * 60 * 24 * 30; // 30 jours

export type Role = "eleve" | "administrateur" | "super_administrateur";

export type SafeUser = {
  id: string;
  email: string;
  role: Role;
  nom: string;
  niveau: string | null;
  serie: string | null;
  isActive: boolean;
  lastLoginAt: Date | null;
  createdAt: Date;
};

const ADMIN_ROLES: Role[] = ["administrateur", "super_administrateur"];

/** Secret de signature JWT : env d'abord, sinon persisté en base. */
export async function getAuthSecret(): Promise<Uint8Array> {
  if (process.env.AUTH_SECRET && process.env.AUTH_SECRET.length > 0) {
    return new TextEncoder().encode(process.env.AUTH_SECRET);
  }
  const row = await db.query.settings.findFirst({ where: eq(settings.key, "auth_secret") });
  if (row?.value) return new TextEncoder().encode(row.value);
  const secret = crypto.randomUUID().repeat(2);
  await db
    .insert(settings)
    .values({ key: "auth_secret", value: secret })
    .onConflictDoNothing();
  return new TextEncoder().encode(secret);
}

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 10);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  try {
    return await bcrypt.compare(password, hash);
  } catch {
    return false;
  }
}

export async function signSessionToken(user: {
  id: string;
  email: string;
  role: Role;
}): Promise<string> {
  const secret = await getAuthSecret();
  return new SignJWT({ sub: user.id, email: user.email, role: user.role })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(`${SESSION_MAX_AGE}s`)
    .sign(secret);
}

export async function verifySessionToken(
  token: string,
): Promise<{ sub: string; email: string; role: Role } | null> {
  try {
    const secret = await getAuthSecret();
    const { payload } = await jwtVerify(token, secret);
    if (!payload.sub) return null;
    return {
      sub: payload.sub,
      email: String(payload.email ?? ""),
      role: (payload.role as Role) ?? "eleve",
    };
  } catch {
    return null;
  }
}

export async function setSessionCookie(token: string) {
  const store = await cookies();
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: SESSION_MAX_AGE,
  });
}

export async function clearSessionCookie() {
  const store = await cookies();
  store.delete(SESSION_COOKIE);
}

export async function getTokenFromRequest(req: NextRequest): Promise<string | null> {
  return req.cookies.get(SESSION_COOKIE)?.value ?? null;
}

/** Récupère la session actuelle (côté serveur). Renvoie null si absente. */
export async function getSession(): Promise<{ user: SafeUser } | null> {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const payload = await verifySessionToken(token);
  if (!payload) return null;
  const [user] = await db
    .select()
    .from(users)
    .where(and(eq(users.id, payload.sub), eq(users.isActive, true)))
    .limit(1);
  if (!user) return null;
  return { user: toSafeUser(user) };
}

export async function getSessionUser(): Promise<SafeUser | null> {
  const session = await getSession();
  return session?.user ?? null;
}

export function isAdminRole(role: string | null | undefined): boolean {
  return role === "administrateur" || role === "super_administrateur";
}

export function toSafeUser(user: {
  id: string;
  email: string;
  role: string;
  nom: string;
  niveau: string | null;
  serie: string | null;
  isActive: boolean;
  lastLoginAt: Date | null;
  createdAt: Date;
}): SafeUser {
  return {
    id: user.id,
    email: user.email,
    role: user.role as Role,
    nom: user.nom,
    niveau: user.niveau,
    serie: user.serie,
    isActive: user.isActive,
    lastLoginAt: user.lastLoginAt,
    createdAt: user.createdAt,
  };
}

/** Vérifie le rôle côté serveur. Déclenche un redirect si non autorisé. */
export async function requireAdmin() {
  const session = await getSession();
  if (!session) {
    redirectToLogin();
    throw new Error("Non connecté : authentification requise.");
  }
  if (!isAdminRole(session.user.role)) {
    throw new Error("Accès refusé : rôle administrateur requis.");
  }
  return session.user;
}

function redirectToLogin() {
  const base = process.env.NEXT_PUBLIC_BASE_URL ?? "http://localhost:3000";
  const url = new URL("/connexion", base);
  url.searchParams.set("next", "/administrateur");
  redirect(url.toString());
}

type AdminApiResult =
  | { ok: true; user: SafeUser }
  | { ok: false; status: number; error: string };

/** Vérifie le rôle côté serveur et renvoie une réponse JSON 401 si besoin. */
export async function requireAdminApi(req: NextRequest): Promise<AdminApiResult> {
  const session = await getSession();
  if (!session || !isAdminRole(session.user.role)) {
    return { ok: false, status: 401, error: "Non autorisé" };
  }
  return { ok: true, user: session.user };
}

export async function logActivity(
  userId: string | null,
  action: string,
  detail?: string,
) {
  try {
    const { activityLogs } = await import("@/db/schema");
    await db.insert(activityLogs).values({ userId, action, detail });
  } catch {
    // les journaux ne doivent jamais casser le flux applicatif
  }
}

export { ADMIN_ROLES };
