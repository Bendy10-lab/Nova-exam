import "server-only";
import { db } from "@/db";
import {
  announcements,
  attempts,
  exams,
  favorites,
  interactiveExams,
  levels,
  progress,
  promotionClicks,
  promotions,
  questions,
  resources,
  series,
  subjects,
  users,
} from "@/db/schema";
import { and, asc, desc, eq, gt, inArray, or, sql } from "drizzle-orm";

// ---------------------------------------------------------------------------
// Niveaux, séries, matières
// ---------------------------------------------------------------------------

export async function getActiveLevels() {
  return db
    .select({
      id: levels.id,
      code: levels.code,
      name: levels.name,
      description: levels.description,
      position: levels.position,
    })
    .from(levels)
    .where(eq(levels.isActive, true))
    .orderBy(asc(levels.position));
}

export async function getLevelByCode(code: string) {
  const [row] = await db.select().from(levels).where(eq(levels.code, code)).limit(1);
  return row ?? null;
}

export async function getActiveSeries(levelId?: string | null) {
  const rows = await db
    .select({
      id: series.id,
      code: series.code,
      name: series.name,
      position: series.position,
      levelId: series.levelId,
    })
    .from(series)
    .where(eq(series.isActive, true));
  if (!levelId) return rows;
  return rows.filter((r) => r.levelId === levelId);
}

export async function getSubjectsForLevel(levelId: string | null) {
  const rows = await db
    .select({
      id: subjects.id,
      code: subjects.code,
      name: subjects.name,
      description: subjects.description,
      color: subjects.color,
      icon: subjects.icon,
      position: subjects.position,
      levelId: subjects.levelId,
    })
    .from(subjects)
    .where(eq(subjects.isActive, true))
    .orderBy(asc(subjects.position));
  return rows.filter((r) => (levelId ? r.levelId === levelId : true));
}

// ---------------------------------------------------------------------------
// Annonces & promotions
// ---------------------------------------------------------------------------

export async function getPublishedAnnouncements(limit = 5) {
  return db
    .select({
      id: announcements.id,
      title: announcements.title,
      content: announcements.content,
      createdAt: announcements.createdAt,
    })
    .from(announcements)
    .where(eq(announcements.published, true))
    .orderBy(desc(announcements.createdAt))
    .limit(limit);
}

function isPromotionActiveNow(row: { status: string; startsAt: Date | null; endsAt: Date | null }) {
  if (row.status !== "publiee") return false;
  const now = new Date();
  if (row.startsAt && now < new Date(row.startsAt)) return false;
  if (row.endsAt && now > new Date(row.endsAt)) return false;
  return true;
}

export type PublicPromotion = {
  id: string;
  name: string;
  logoPath: string | null;
  shortDescription: string | null;
  description: string | null;
  category: string | null;
  websiteUrl: string | null;
  downloadUrl: string | null;
  buttonText: string;
  position: number;
};

export async function getPublicPromotions(section?: "home" | "footer" | "dashboard") {
  const rows = await db.select().from(promotions).orderBy(asc(promotions.position));
  const filtered = rows.filter((r) => {
    if (section === "home" && !r.showOnHome) return false;
    if (section === "footer" && !r.showInFooter) return false;
    if (section === "dashboard" && !r.showInDashboard) return false;
    return isPromotionActiveNow(r);
  });
  return filtered.map((r) => ({
    id: r.id,
    name: r.name,
    logoPath: r.logoPath,
    shortDescription: r.shortDescription,
    description: r.description,
    category: r.category,
    websiteUrl: r.websiteUrl,
    downloadUrl: r.downloadUrl,
    buttonText: r.buttonText ?? "Visiter",
    position: r.position,
  }));
}

export async function countPromotionClicks(promotionId: string) {
  return db
    .select({ c: promotionClicks.id })
    .from(promotionClicks)
    .where(eq(promotionClicks.promotionId, promotionId))
    .then((r) => r.length);
}

export async function recordPromotionClick(promotionId: string) {
  await db.insert(promotionClicks).values({ promotionId });
  await db
    .update(promotions)
    .set({ clicks: sql`${promotions.clicks} + 1` })
    .where(eq(promotions.id, promotionId));
}

// ---------------------------------------------------------------------------
// Examens & ressources
// ---------------------------------------------------------------------------

export type ExamFilters = {
  level?: string | null;
  serie?: string | null;
  subject?: string | null;
  year?: number | null;
  examType?: string | null;
  hasCorrection?: boolean | null;
  q?: string | null;
};

function examSelect() {
  return db
    .select({
      id: exams.id,
      title: exams.title,
      description: exams.description,
      year: exams.year,
      examType: exams.examType,
      hasCorrection: exams.hasCorrection,
      filePath: exams.filePath,
      correctionFilePath: exams.correctionFilePath,
      isOfficial: exams.isOfficial,
      subjectId: exams.subjectId,
      levelId: exams.levelId,
      serieId: exams.serieId,
      createdAt: exams.createdAt,
      subjectName: subjects.name,
      subjectCode: subjects.code,
      levelName: levels.name,
      levelCode: levels.code,
      serieName: series.name,
    })
    .from(exams)
    .leftJoin(subjects, eq(exams.subjectId, subjects.id))
    .leftJoin(levels, eq(exams.levelId, levels.id))
    .leftJoin(series, eq(exams.serieId, series.id));
}

export async function searchExams(filters: ExamFilters) {
  const conditions = [eq(exams.published, true)];
  if (filters.level) conditions.push(eq(exams.levelId, filters.level));
  if (filters.serie) conditions.push(eq(exams.serieId, filters.serie));
  if (filters.subject) conditions.push(eq(exams.subjectId, filters.subject));
  if (filters.examType) conditions.push(eq(exams.examType, filters.examType));
  if (filters.hasCorrection !== null && filters.hasCorrection !== undefined) {
    conditions.push(eq(exams.hasCorrection, filters.hasCorrection));
  }
  if (filters.year) conditions.push(eq(exams.year, filters.year));
  if (filters.q) {
    const term = `%${filters.q}%`;
    conditions.push(or(sql`${exams.title} ILIKE ${term}`, sql`${exams.description} ILIKE ${term}`)!);
  }
  return examSelect().where(and(...conditions)).orderBy(desc(exams.year), desc(exams.createdAt));
}

export async function getExamById(id: string) {
  const [row] = await examSelect().where(eq(exams.id, id)).limit(1);
  return row ?? null;
}

export async function getInteractiveExam(id: string, includeQuestions = false) {
  const [row] = await db
    .select({
      id: interactiveExams.id,
      title: interactiveExams.title,
      description: interactiveExams.description,
      durationMinutes: interactiveExams.durationMinutes,
      maxScore: interactiveExams.maxScore,
      passingScore: interactiveExams.passingScore,
      isWhitePaper: interactiveExams.isWhitePaper,
      subjectId: interactiveExams.subjectId,
      levelId: interactiveExams.levelId,
      serieId: interactiveExams.serieId,
      subjectName: subjects.name,
      subjectCode: subjects.code,
      levelName: levels.name,
      levelCode: levels.code,
      serieName: series.name,
      published: interactiveExams.published,
    })
    .from(interactiveExams)
    .leftJoin(subjects, eq(interactiveExams.subjectId, subjects.id))
    .leftJoin(levels, eq(interactiveExams.levelId, levels.id))
    .leftJoin(series, eq(interactiveExams.serieId, series.id))
    .where(eq(interactiveExams.id, id))
    .limit(1);
  if (!row) return null;
  if (!includeQuestions) return row;
  const questionRows = await db
    .select()
    .from(questions)
    .where(eq(questions.examId, id))
    .orderBy(asc(questions.orderNo));
  return { ...row, questions: questionRows };
}

export async function getPublishedInteractiveExams(levelId?: string | null, subjectId?: string | null) {
  const conditions = [eq(interactiveExams.published, true)];
  if (levelId) conditions.push(eq(interactiveExams.levelId, levelId));
  if (subjectId) conditions.push(eq(interactiveExams.subjectId, subjectId));
  return db
    .select({
      id: interactiveExams.id,
      title: interactiveExams.title,
      description: interactiveExams.description,
      durationMinutes: interactiveExams.durationMinutes,
      maxScore: interactiveExams.maxScore,
      passingScore: interactiveExams.passingScore,
      isWhitePaper: interactiveExams.isWhitePaper,
      subjectId: interactiveExams.subjectId,
      levelId: interactiveExams.levelId,
      subjectName: subjects.name,
      levelName: levels.name,
      createdAt: interactiveExams.createdAt,
    })
    .from(interactiveExams)
    .leftJoin(subjects, eq(interactiveExams.subjectId, subjects.id))
    .leftJoin(levels, eq(interactiveExams.levelId, levels.id))
    .where(and(...conditions))
    .orderBy(desc(interactiveExams.createdAt));
}

export async function getResources(filters: {
  subjectId?: string | null;
  levelId?: string | null;
  q?: string | null;
  type?: string | null;
  limit?: number;
}) {
  const conditions = [eq(resources.published, true)];
  if (filters.subjectId) conditions.push(eq(resources.subjectId, filters.subjectId));
  if (filters.levelId) conditions.push(eq(resources.levelId, filters.levelId));
  if (filters.type) conditions.push(eq(resources.resourceType, filters.type));
  if (filters.q) {
    const term = `%${filters.q}%`;
    conditions.push(or(sql`${resources.title} ILIKE ${term}`, sql`${resources.summary} ILIKE ${term}`)!);
  }
  return db
    .select({
      id: resources.id,
      title: resources.title,
      summary: resources.summary,
      resourceType: resources.resourceType,
      filePath: resources.filePath,
      subjectId: resources.subjectId,
      subjectName: subjects.name,
      subjectCode: subjects.code,
      color: subjects.color,
      createdAt: resources.createdAt,
    })
    .from(resources)
    .leftJoin(subjects, eq(resources.subjectId, subjects.id))
    .where(and(...conditions))
    .orderBy(desc(resources.createdAt))
    .limit(filters.limit ?? 100);
}

// ---------------------------------------------------------------------------
// Données élève
// ---------------------------------------------------------------------------

export async function getStudentStats(userId: string) {
  const [attemptRows, favoriteCount, progressRows, resourceCount, interactiveCount] = await Promise.all([
    db
      .select({
        id: attempts.id,
        examId: attempts.examId,
        examTitle: attempts.examTitle,
        score: attempts.score,
        maxScore: attempts.maxScore,
        percent: attempts.percent,
        passed: attempts.passed,
        submittedAt: attempts.submittedAt,
        subjectId: attempts.subjectId,
        feedback: attempts.feedback,
        createdAt: attempts.createdAt,
      })
      .from(attempts)
      .where(eq(attempts.userId, userId))
      .orderBy(desc(attempts.submittedAt ?? attempts.createdAt))
      .limit(20),
    db
      .select({ c: favorites.id })
      .from(favorites)
      .where(eq(favorites.userId, userId))
      .then((r) => r.length),
    db.select().from(progress).where(eq(progress.userId, userId)),
    db.select({ c: resources.id }).from(resources).where(eq(resources.published, true)).then((r) => r.length),
    db
      .select({ c: interactiveExams.id })
      .from(interactiveExams)
      .where(eq(interactiveExams.published, true))
      .then((r) => r.length),
  ]);

  const totalQuestions = progressRows.reduce((sum, p) => sum + p.questionsAnswered, 0);
  const totalCorrect = progressRows.reduce((sum, p) => sum + p.correctAnswers, 0);
  const lastAttempt = attemptRows[0] ?? null;

  return {
    tentatives: attemptRows.length,
    moyenne:
      attemptRows.length > 0
        ? Math.round(attemptRows.reduce((sum, a) => sum + (a.percent ?? 0), 0) / attemptRows.length)
        : 0,
    meilleurScore: attemptRows.reduce((max, a) => Math.max(max, a.percent ?? 0), 0),
    favoris: favoriteCount,
    questionsRepondues: totalQuestions,
    reponsesCorrectes: totalCorrect,
    exactitude: totalQuestions > 0 ? Math.round((totalCorrect / totalQuestions) * 100) : 0,
    derniers: attemptRows.slice(0, 5),
    dernierExamen: lastAttempt,
    progression: progressRows,
    ressourcesTotales: resourceCount,
    interactivesTotales: interactiveCount,
  };
}

/** Tentatives en cours pour reprendre une révision interrompue. */
export async function getPendingAttempts(userId: string) {
  return db
    .select({
      id: attempts.id,
      examId: attempts.examId,
      examTitle: attempts.examTitle,
      startedAt: attempts.startedAt,
      subjectId: attempts.subjectId,
    })
    .from(attempts)
    .where(and(eq(attempts.userId, userId), sql`${attempts.submittedAt} is null`))
    .orderBy(desc(attempts.startedAt));
}

export async function getStudentFavorites(userId: string) {
  const rows = await db
    .select({ examId: favorites.examId, createdAt: favorites.createdAt })
    .from(favorites)
    .where(eq(favorites.userId, userId))
    .orderBy(desc(favorites.createdAt));
  if (rows.length === 0) return [];
  return examSelect()
    .where(and(inArray(exams.id, rows.map((r) => r.examId)), eq(exams.published, true)))
    .orderBy(desc(exams.year));
}

export async function getRecentExams(limit = 6) {
  return examSelect()
    .where(eq(exams.published, true))
    .orderBy(desc(exams.createdAt))
    .limit(limit);
}

export async function getRecentInteractiveExams(limit = 4) {
  return db
    .select({
      id: interactiveExams.id,
      title: interactiveExams.title,
      description: interactiveExams.description,
      durationMinutes: interactiveExams.durationMinutes,
      maxScore: interactiveExams.maxScore,
      passingScore: interactiveExams.passingScore,
      isWhitePaper: interactiveExams.isWhitePaper,
      subjectId: interactiveExams.subjectId,
      levelId: interactiveExams.levelId,
      subjectName: subjects.name,
      levelName: levels.name,
      createdAt: interactiveExams.createdAt,
    })
    .from(interactiveExams)
    .leftJoin(subjects, eq(interactiveExams.subjectId, subjects.id))
    .leftJoin(levels, eq(interactiveExams.levelId, levels.id))
    .where(eq(interactiveExams.published, true))
    .orderBy(desc(interactiveExams.createdAt))
    .limit(limit);
}

export async function getAdminStats() {
  const [students, attemptsCount, examCount, promotionsCount, clicks, difficulty] = await Promise.all([
    db.select({ c: users.id }).from(users).then((r) => r.length),
    db.select({ c: attempts.id }).from(attempts).then((r) => r.length),
    db.select({ c: exams.id }).from(exams).then((r) => r.length),
    db.select({ c: promotions.id }).from(promotions).then((r) => r.length),
    db.select({ c: promotionClicks.id }).from(promotionClicks).then((r) => r.length),
    getDifficultSubjects(),
  ]);
  return {
    eleves: students,
    tentatives: attemptsCount,
    examens: examCount,
    promotions: promotionsCount,
    clics: clicks,
    matieresDifficiles: difficulty,
  };
}

export async function getDifficultSubjects() {
  const rows = await db
    .select({
      subjectName: subjects.name,
      total: sql<number>`count(*)::int`,
      passed: sql<number>`count(*) filter (where ${attempts.passed})::int`,
    })
    .from(attempts)
    .leftJoin(interactiveExams, eq(attempts.examId, interactiveExams.id))
    .leftJoin(subjects, eq(interactiveExams.subjectId, subjects.id))
    .groupBy(subjects.name)
    .having(sql`count(*) > 0`)
    .orderBy(desc(sql`count(*)`))
    .limit(5);
  return rows.map((r) => ({
    subjectName: r.subjectName ?? "Non spécifié",
    total: r.total,
    passed: r.passed,
    taux: r.total > 0 ? Math.round((r.passed / r.total) * 100) : 0,
  }));
}

export async function getRecentActivity(limit = 15) {
  const { activityLogs } = await import("@/db/schema");
  return db
    .select({
      id: activityLogs.id,
      action: activityLogs.action,
      detail: activityLogs.detail,
      createdAt: activityLogs.createdAt,
      userName: users.nom,
    })
    .from(activityLogs)
    .leftJoin(users, eq(activityLogs.userId, users.id))
    .orderBy(desc(activityLogs.createdAt))
    .limit(limit);
}

// ---------------------------------------------------------------------------
// Administrateur
// ---------------------------------------------------------------------------

export async function getAllSubjectsAdmin() {
  return db.select().from(subjects).orderBy(asc(subjects.position));
}

export async function getAllExamsAdmin() {
  return db
    .select({
      id: exams.id,
      title: exams.title,
      examType: exams.examType,
      hasCorrection: exams.hasCorrection,
      filePath: exams.filePath,
      correctionFilePath: exams.correctionFilePath,
      published: exams.published,
      isOfficial: exams.isOfficial,
      year: exams.year,
      createdAt: exams.createdAt,
      subjectName: subjects.name,
      levelName: levels.name,
    })
    .from(exams)
    .leftJoin(subjects, eq(exams.subjectId, subjects.id))
    .leftJoin(levels, eq(exams.levelId, levels.id))
    .orderBy(desc(exams.createdAt));
}

export async function getAllInteractiveExamsAdmin() {
  return db
    .select({
      id: interactiveExams.id,
      title: interactiveExams.title,
      durationMinutes: interactiveExams.durationMinutes,
      maxScore: interactiveExams.maxScore,
      passingScore: interactiveExams.passingScore,
      isWhitePaper: interactiveExams.isWhitePaper,
      published: interactiveExams.published,
      createdAt: interactiveExams.createdAt,
      subjectName: subjects.name,
      levelName: levels.name,
      questionCount: sql<number>`(select count(*) from ${questions} where ${questions.examId} = ${interactiveExams.id})::int`,
    })
    .from(interactiveExams)
    .leftJoin(subjects, eq(interactiveExams.subjectId, subjects.id))
    .leftJoin(levels, eq(interactiveExams.levelId, levels.id))
    .orderBy(desc(interactiveExams.createdAt));
}

export { users, progress, favorites, attempts, subjects, levels, series, resources, questions, exams, interactiveExams, announcements, promotions, promotionClicks };
