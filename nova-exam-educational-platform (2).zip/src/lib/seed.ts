import "server-only";
import { db } from "@/db";
import {
  announcements,
  interactiveExams,
  levels,
  questions,
  resources,
  series,
  settings,
  subjects,
  users,
} from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { hashPassword, logActivity } from "@/lib/auth";
import { DEFAULT_SETTINGS } from "@/lib/settings";

export const ADMIN_EMAIL = process.env.ADMIN_EMAIL ?? "jurgensbeneche1@gmail.com";
export const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD ?? "Bendy509";

async function ensureAdmin() {
  const [existing] = await db.select().from(users).where(eq(users.email, ADMIN_EMAIL)).limit(1);
  if (existing) {
    await db
      .update(users)
      .set({ role: "super_administrateur", isActive: true })
      .where(eq(users.email, ADMIN_EMAIL));
    console.log(`[seed] administrateur déjà présent : ${ADMIN_EMAIL}`);
    return;
  }
  await db.insert(users).values({
    email: ADMIN_EMAIL,
    passwordHash: await hashPassword(ADMIN_PASSWORD),
    role: "super_administrateur",
    nom: "Beneche Jurgens",
  });
  await logActivity(null, "administrateur_creé", ADMIN_EMAIL);
  console.log(`[seed] compte super administrateur créé : ${ADMIN_EMAIL}`);
}

async function ensureSettings() {
  for (const [key, value] of Object.entries(DEFAULT_SETTINGS)) {
    await db.insert(settings).values({ key, value }).onConflictDoNothing();
  }
}

async function ensureLevelsAndSeries() {
  const [nine, ns4] = await Promise.all([
    db.select().from(levels).where(eq(levels.code, "9em")).limit(1),
    db.select().from(levels).where(eq(levels.code, "ns4")).limit(1),
  ]);
  if (nine.length === 0) {
    await db.insert(levels).values({
      code: "9em",
      name: "9ème année fondamentale",
      description: "Programme de base pour la préparation du CFPE-9.",
      position: 1,
    });
  }
  if (ns4.length === 0) {
    await db.insert(levels).values({
      code: "ns4",
      name: "NS4 (New Secondary)",
      description: "Première année du cycle secondaire supérieur en Haïti.",
      position: 2,
    });
  }

  const [nineRow] = await db.select().from(levels).where(eq(levels.code, "9em")).limit(1);
  const [ns4Row] = await db.select().from(levels).where(eq(levels.code, "ns4")).limit(1);

  if (nineRow) {
    await db
      .insert(series)
      .values({ code: "9em", name: "9ème année fondamentale", levelId: nineRow.id, position: 1 })
      .onConflictDoNothing();
  }
  if (ns4Row) {
    const ns4Series = [
      { code: "sciences", name: "Sciences", position: 1 },
      { code: "lettres", name: "Lettres et sciences humaines", position: 2 },
      { code: "affaire", name: "Affaires et informatique", position: 3 },
    ];
    for (const s of ns4Series) {
      const [row] = await db
        .select()
        .from(series)
        .where(and(eq(series.code, s.code), eq(series.levelId, ns4Row.id)))
        .limit(1);
      if (!row) {
        await db.insert(series).values({ ...s, levelId: ns4Row.id });
      }
    }
  }
}

const SUBJECTS_9EM = [
  { code: "francais", name: "Français", icon: "📚", color: "#1e3a8a" },
  { code: "creole", name: "Créole haïtien", icon: "🗣️", color: "#b45309" },
  { code: "math", name: "Mathématiques", icon: "🔢", color: "#0f766e" },
  { code: "sci-exp", name: "Sciences expérimentales", icon: "🔬", color: "#7c3aed" },
  { code: "sci-soc", name: "Sciences sociales", icon: "🌍", color: "#be123c" },
  { code: "anglais", name: "Anglais", icon: "🇬🇧", color: "#1d4ed8" },
  { code: "espagnol", name: "Espagnol", icon: "🇪🇸", color: "#c2410c" },
];

const SUBJECTS_NS4 = [
  { code: "ns4-francais", name: "Français", icon: "📚", color: "#1e3a8a" },
  { code: "ns4-anglais", name: "Anglais", icon: "🇬🇧", color: "#1d4ed8" },
  { code: "ns4-creole", name: "Créole haïtien", icon: "🗣️", color: "#b45309" },
  { code: "ns4-math", name: "Mathématiques", icon: "🔢", color: "#0f766e" },
  { code: "ns4-physique", name: "Physique", icon: "⚡", color: "#7c3aed" },
  { code: "ns4-chimie", name: "Chimie", icon: "🧪", color: "#0891b2" },
  { code: "ns4-biologie", name: "Biologie", icon: "🧬", color: "#16a34a" },
  { code: "ns4-histoire", name: "Histoire", icon: "🏛️", color: "#a16207" },
  { code: "ns4-geographie", name: "Géographie", icon: "🗺️", color: "#15803d" },
  { code: "ns4-economie", name: "Économie", icon: "💰", color: "#b91c1c" },
  { code: "ns4-philo", name: "Philosophie", icon: "🤔", color: "#6d28d9" },
  { code: "ns4-info", name: "Informatique", icon: "💻", color: "#2563eb" },
];

async function ensureSubjects() {
  const [nineRow, ns4Row] = await Promise.all([
    db.select().from(levels).where(eq(levels.code, "9em")).limit(1).then((r) => r[0]),
    db.select().from(levels).where(eq(levels.code, "ns4")).limit(1).then((r) => r[0]),
  ]);
  const all = await db.select({ id: subjects.id, code: subjects.code, levelId: subjects.levelId }).from(subjects);

  const insertSubject = async (s: (typeof SUBJECTS_9EM)[number], levelId: string, position: number) => {
    if (all.some((x) => x.code === s.code)) return;
    await db.insert(subjects).values({
      code: s.code,
      name: s.name,
      icon: s.icon,
      color: s.color,
      levelId,
      position,
    });
  };

  if (nineRow) {
    let i = 1;
    for (const s of SUBJECTS_9EM) await insertSubject(s, nineRow.id, i++);
  }
  if (ns4Row) {
    let i = 1;
    for (const s of SUBJECTS_NS4) await insertSubject(s, ns4Row.id, i++);
  }
}

async function ensureAnnouncement() {
  const [existing] = await db.select().from(announcements).limit(1);
  if (existing) return;
  await db.insert(announcements).values({
    title: "Bienvenue sur NOVA EXAM",
    content:
      "Toutes les ressources de NOVA EXAM — examens précédents, exercices, corrigés et examens blancs — sont gratuites. Commencez par créer votre compte et choisir votre niveau.",
    published: true,
  });
}

async function ensureSampleWhitePaper() {
  const [existing] = await db.select().from(interactiveExams).limit(1);
  if (existing) return;
  const [nineRow] = await db.select().from(levels).where(eq(levels.code, "9em")).limit(1);
  const [math] = await db.select().from(subjects).where(eq(subjects.code, "math")).limit(1);
  const [exam] = await db.insert(interactiveExams).values({
    title: "Examen blanc de démonstration — Mathématiques (9ème)",
    description:
      "Exemple d'examen blanc interactif. Les réponses et explications apparaissent après la soumission. Il s'agit d'un entraînement, pas d'un résultat officiel.",
    subjectId: math.id,
    levelId: nineRow.id,
    durationMinutes: 15,
    maxScore: 100,
    passingScore: 60,
    isWhitePaper: true,
    published: true,
  }).returning({ id: interactiveExams.id });

  const sampleQuestions = [
    {
      prompt: "Calculez 12 × 8.",
      questionType: "mcq",
      optionsJson: [{ text: "84" }, { text: "96" }, { text: "108" }, { text: "120" }],
      correctIndex: 1,
      explanation: "12 × 8 = 96.",
      points: 20,
    },
    {
      prompt: "Un rectangle a une longueur de 6 cm et une largeur de 4 cm. Quel est son aire ?",
      questionType: "mcq",
      optionsJson: [{ text: "10 cm" }, { text: "24 cm²" }, { text: "24 cm" }, { text: "12 cm²" }],
      correctIndex: 1,
      explanation: "L'aire d'un rectangle = longueur × largeur = 6 × 4 = 24 cm².",
      points: 20,
    },
    {
      prompt: "Simplifiez la fraction 8/12.",
      questionType: "short",
      correctAnswer: "2/3",
      explanation: "On divise le numérateur et le dénominateur par 4 : 8 ÷ 4 = 2 et 12 ÷ 4 = 3.",
      points: 20,
    },
    {
      prompt: "Quelle est la valeur de 3² ?",
      questionType: "mcq",
      optionsJson: [{ text: "6" }, { text: "9" }, { text: "12" }, { text: "81" }],
      correctIndex: 1,
      explanation: "3² = 3 × 3 = 9.",
      points: 20,
    },
    {
      prompt: "Le perimètre d'un carré mesure 20 cm. Quelle est la longueur d'un côté ?",
      questionType: "short",
      correctAnswer: "5 cm",
      explanation: "Le périmètre d'un carré = 4 × côté, donc côté = 20 ÷ 4 = 5 cm.",
      points: 20,
    },
  ];

  for (let i = 0; i < sampleQuestions.length; i++) {
    const q = sampleQuestions[i];
    await db.insert(questions).values({
      examId: exam.id,
      subjectId: math.id,
      prompt: q.prompt,
      questionType: q.questionType,
      optionsJson: q.optionsJson ?? null,
      correctIndex: q.correctIndex ?? null,
      correctAnswer: q.correctAnswer ?? null,
      explanation: q.explanation ?? null,
      points: q.points ?? 20,
      orderNo: i + 1,
    });
  }
}

export async function runSeed() {
  await ensureAdmin();
  await ensureSettings();
  await ensureLevelsAndSeries();
  await ensureSubjects();
  await ensureAnnouncement();
  await ensureSampleWhitePaper();
}

/** Écrase les ressources de démonstration sans toucher aux comptes. */

export async function resetContent() {
  await db.delete(questions);
  await db.delete(interactiveExams);
  await db.delete(resources);
  await db.delete(announcements);
  await ensureAnnouncement();
  await ensureSampleWhitePaper();
}

