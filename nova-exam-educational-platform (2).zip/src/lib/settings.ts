import { db } from "@/db";
import { settings, levels, series, subjects, exams, attempts, users, resources } from "@/db/schema";
import { and, eq, gt } from "drizzle-orm";

export const DEFAULT_SETTINGS: Record<string, string> = {
  site_name: "NOVA EXAM",
  site_slogan: "Prépare ton examen, construis ton avenir.",
  site_description:
    "Plateforme éducative gratuite pour les élèves de 9ème année fondamentale et de NS4 en Haïti : examens précédents, exercices, corrigés et examens blancs.",
  whatsapp_number: "",
  contact_email: "jurgensbeneche1@gmail.com",
  founder_name: "Beneche Jurgens",
  founder_title: "Fondateur de NOVA EXAM",
  founder_bio:
    "NOVA EXAM est une plateforme éducative créée par Beneche Jurgens dans le but d'aider les élèves haïtiens à mieux préparer leurs examens officiels. Son objectif est de faciliter l'accès aux examens précédents, aux exercices, aux corrections et aux ressources pédagogiques dans un environnement simple, moderne et accessible gratuitement.",
  founder_mission:
    "Offrir à chaque élève haïtien un accès gratuit, simple et moderne aux ressources de préparation des examens officiels, afin qu'il puisse construire son avenir sur des bases solides.",
  address: "Haïti",
  facebook_url: "",
  instagram_url: "",
  twitter_url: "",
  youtube_url: "",
};

type SettingsRow = { key: string; value: string | null };

let cache: Promise<Record<string, string>> | null = null;

export async function loadSettings(): Promise<Record<string, string>> {
  const merged: Record<string, string> = { ...DEFAULT_SETTINGS };
  try {
    const rows = await db.select().from(settings);
    for (const row of rows) {
      if (row.value !== null && row.value !== undefined) merged[row.key] = row.value;
    }
  } catch {
    // la base peut être indisponible au boot : on garde les valeurs par défaut
  }
  return merged;
}

/** Cache per-request pour éviter des requêtes répétées sur une même requête HTTP. */
export async function getSettings(): Promise<Record<string, string>> {
  if (!cache) cache = loadSettings();
  return cache;
}

export function resetSettingsCache() {
  cache = null;
}

export async function saveSetting(key: string, value: string) {
  await db
    .insert(settings)
    .values({ key, value })
    .onConflictDoUpdate({ target: settings.key, set: { value, updatedAt: new Date() } });
  resetSettingsCache();
}

export async function saveSettings(values: Record<string, string>) {
  for (const [key, value] of Object.entries(values)) {
    await saveSetting(key, value);
  }
  resetSettingsCache();
}

export function publicSettings(s: Record<string, string>) {
  return {
    siteName: s.site_name ?? "NOVA EXAM",
    slogan: s.site_slogan ?? "",
    description: s.site_description ?? "",
    whatsapp: s.whatsapp_number ?? "",
    contactEmail: s.contact_email ?? "",
    founderName: s.founder_name ?? "",
    founderTitle: s.founder_title ?? "",
    founderBio: s.founder_bio ?? "",
    founderMission: s.founder_mission ?? "",
    address: s.address ?? "",
    social: {
      facebook: s.facebook_url ?? "",
      instagram: s.instagram_url ?? "",
      twitter: s.twitter_url ?? "",
      youtube: s.youtube_url ?? "",
    },
  };
}

/** Statistiques réelles issues de la base de données. */
export async function getRealStats() {
  const since = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
  const [levelsCount, seriesCount, subjectsCount, examsCount, whitePaperCount, resourceCount, studentCount, attemptCount, activeStudents] =
    await Promise.all([
      db.select({ c: levels.id }).from(levels).then((r) => r.length),
      db.select({ c: series.id }).from(series).then((r) => r.length),
      db
        .select({ c: subjects.id })
        .from(subjects)
        .where(eq(subjects.isActive, true))
        .then((r) => r.length),
      db
        .select({ c: exams.id })
        .from(exams)
        .where(eq(exams.published, true))
        .then((r) => r.length),
      db
        .select({ c: exams.id })
        .from(exams)
        .where(eq(exams.examType, "blanc"))
        .then((r) => r.length),
      db
        .select({ c: resources.id })
        .from(resources)
        .where(eq(resources.published, true))
        .then((r) => r.length),
      db
        .select({ c: users.id })
        .from(users)
        .where(eq(users.role, "eleve"))
        .then((r) => r.length),
      db.select({ c: attempts.id }).from(attempts).then((r) => r.length),
      db
        .select({ c: users.id })
        .from(users)
        .where(and(eq(users.role, "eleve"), gt(users.lastLoginAt, since)))
        .then((r) => r.length),
    ]);

  return {
    niveaux: levelsCount,
    series: seriesCount,
    matieres: subjectsCount,
    examens: examsCount,
    examensBlancs: whitePaperCount,
    ressources: resourceCount,
    eleves: studentCount,
    tentatives: attemptCount,
    elevesActifs: activeStudents,
  };
}

export async function getLevelName(code: string | null): Promise<string | null> {
  if (!code) return null;
  const [row] = await db.select({ name: levels.name }).from(levels).where(eq(levels.code, code)).limit(1);
  return row?.name ?? code;
}

export async function getLevelNames(): Promise<{ code: string; name: string }[]> {
  const rows = await db.select({ code: levels.code, name: levels.name }).from(levels);
  return rows;
}

export async function getSeriesForLevel(levelId: string) {
  const rows = await db
    .select({ id: series.id, code: series.code, name: series.name })
    .from(series)
    .where(and(eq(series.levelId, levelId), eq(series.isActive, true)));
  return rows;
}
