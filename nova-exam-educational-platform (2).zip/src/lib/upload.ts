import "server-only";
import fs from "node:fs/promises";
import path from "node:path";

const UPLOAD_DIR = path.join(process.cwd(), "public", "uploads");

async function ensureDir(dir: string) {
  await fs.mkdir(dir, { recursive: true });
}

export type SavedFile = { path: string; url: string; size: number };

/** Enregistre un fichier envoyé (PDF, image) dans public/uploads. */
export async function saveUploadedFile(
  file: File,
  folder = "general",
  prefix = "file",
): Promise<SavedFile> {
  if (!file || typeof file === "string") {
    throw new Error("Aucun fichier fourni.");
  }
  const safeExt = (file.name.match(/\.[A-Za-z0-9]{1,5}$/)?.[0] ?? "").toLowerCase();
  await ensureDir(UPLOAD_DIR);
  const dir = path.join(UPLOAD_DIR, folder);
  await ensureDir(dir);
  const name = `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}${safeExt}`;
  const bytes = Buffer.from(await file.arrayBuffer());
  await fs.writeFile(path.join(dir, name), bytes);
  const url = `/uploads/${folder}/${name}`;
  return { path: url, url, size: bytes.length };
}

export function isImage(file: File) {
  return file.type.startsWith("image/");
}

export function isPdf(file: File) {
  return file.type === "application/pdf" || /\.pdf$/i.test(file.name);
}

export const MAX_FILE_BYTES = 25 * 1024 * 1024; // 25 Mo
